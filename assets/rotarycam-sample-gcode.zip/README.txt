RotaryCAM Verified Sample G-Code Pack
=====================================

All programs in this archive were generated directly by RotaryCAM from real
STEP and DXF parts and passed the RotaryCAM G-code grammar and plasma physics
audit (0 syntax, chirality, IHS, or THC lock defects).

Included Programs
-----------------

1. rotary-1.66in-pipe-simcnc.nc
   - Controller: CSLab SimCNC (G94 4D Euclidean feedrate spoofing)
   - Stock: 1.66" OD (42.2 mm) x 3.56 mm wall round mild steel pipe, 146.7 mm cut length
   - Features: 4-axis fishmouth saddle cope + endcut
   - Notes: Metric (G21), M3 macro IHS/plunge, #1110-#1113 plasma registers, M62/M63 P0 THC lock

2. rotary-1.66in-pipe-linuxcnc-qtplasmac.ngc
   - Controller: LinuxCNC 2.9+ QTPlasmaC
   - Stock: 1.66" OD x 0.140" wall round mild steel pipe, 5.775" cut length
   - Features: 4-axis fishmouth saddle cope + endcut
   - Notes: Inch (G20), G93 inverse-time feed, (o=0...) material header, M52 P1, M62/M63 P2 THC lock

3. rotary-1.66in-pipe-mach4-ess.tap
   - Controller: ArtSoft Mach4 + Warp9 ESS
   - Stock: 42.2 mm OD x 3.56 mm wall round mild steel pipe, 146.7 mm cut length
   - Features: 4-axis fishmouth saddle cope + endcut
   - Notes: Metric (G21), G93 inverse-time feed, G31.0 IHS probe, M62/M63 P2 THC lock

4. rotary-1.5in-square-hss-masso.nc
   - Controller: MASSO G3 + DTHC
   - Stock: 38.1 mm x 38.1 mm x 6.35 mm (1.5" x 1.5" x 0.25") square HSS mild steel tube
   - Features: 4-axis coped tube cuts with synchronized Z corner lift and feed scaling
   - Notes: Metric (G21), G93 inverse-time feed, T112 M6, G200, M666 DTHC sync lock

5. flat-bearing-flange-firecontrol.tap
   - Controller: Langmuir Systems FireControl
   - Stock: 100.0 mm x 136.0 mm x 3.18 mm mild steel flat plate
   - Features: Internal bolt holes and outer bearing flange contour
   - Notes: Metric (G21), G38.2/G38.4 IHS touch-off, H0/H1 THC control

Shop Safety Checklist Before Running
------------------------------------
- Dry-run the program first with torch power disabled and verify rotary chuck
  direction, X/Y/Z/A axis limits, and chuck clearance (65 mm dead zone assumed).
- Confirm amperage, cut speed, kerf width, pierce height, and cut height match
  your plasma power supply and consumables.

Download RotaryCAM (30-Day Free Trial, macOS / Windows / Linux):
https://rotarycam.app/#download
