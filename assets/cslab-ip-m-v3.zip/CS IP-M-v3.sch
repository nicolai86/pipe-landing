<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE eagle SYSTEM "eagle.dtd">
<eagle version="9.7.0">
<drawing>
<settings>
<setting alwaysvectorfont="no"/>
<setting verticaltext="up"/>
</settings>
<grid distance="0.1" unitdist="inch" unit="inch" style="lines" multiple="1" display="no" altdistance="0.01" altunitdist="inch" altunit="inch"/>
<layers>
<layer number="1" name="Top" color="4" fill="1" visible="no" active="no"/>
<layer number="2" name="Route2" color="16" fill="1" visible="no" active="no"/>
<layer number="3" name="Route3" color="17" fill="1" visible="no" active="no"/>
<layer number="4" name="Route4" color="18" fill="1" visible="no" active="no"/>
<layer number="5" name="Route5" color="19" fill="1" visible="no" active="no"/>
<layer number="6" name="Route6" color="25" fill="1" visible="no" active="no"/>
<layer number="7" name="Route7" color="26" fill="1" visible="no" active="no"/>
<layer number="8" name="Route8" color="27" fill="1" visible="no" active="no"/>
<layer number="9" name="Route9" color="28" fill="1" visible="no" active="no"/>
<layer number="10" name="Route10" color="29" fill="1" visible="no" active="no"/>
<layer number="11" name="Route11" color="30" fill="1" visible="no" active="no"/>
<layer number="12" name="Route12" color="20" fill="1" visible="no" active="no"/>
<layer number="13" name="Route13" color="21" fill="1" visible="no" active="no"/>
<layer number="14" name="Route14" color="22" fill="1" visible="no" active="no"/>
<layer number="15" name="Route15" color="23" fill="1" visible="no" active="no"/>
<layer number="16" name="Bottom" color="1" fill="1" visible="no" active="no"/>
<layer number="17" name="Pads" color="2" fill="1" visible="no" active="no"/>
<layer number="18" name="Vias" color="2" fill="1" visible="no" active="no"/>
<layer number="19" name="Unrouted" color="6" fill="1" visible="no" active="no"/>
<layer number="20" name="Dimension" color="24" fill="1" visible="no" active="no"/>
<layer number="21" name="tPlace" color="7" fill="1" visible="no" active="no"/>
<layer number="22" name="bPlace" color="7" fill="1" visible="no" active="no"/>
<layer number="23" name="tOrigins" color="15" fill="1" visible="no" active="no"/>
<layer number="24" name="bOrigins" color="15" fill="1" visible="no" active="no"/>
<layer number="25" name="tNames" color="7" fill="1" visible="no" active="no"/>
<layer number="26" name="bNames" color="7" fill="1" visible="no" active="no"/>
<layer number="27" name="tValues" color="7" fill="1" visible="no" active="no"/>
<layer number="28" name="bValues" color="7" fill="1" visible="no" active="no"/>
<layer number="29" name="tStop" color="7" fill="3" visible="no" active="no"/>
<layer number="30" name="bStop" color="7" fill="6" visible="no" active="no"/>
<layer number="31" name="tCream" color="7" fill="4" visible="no" active="no"/>
<layer number="32" name="bCream" color="7" fill="5" visible="no" active="no"/>
<layer number="33" name="tFinish" color="6" fill="3" visible="no" active="no"/>
<layer number="34" name="bFinish" color="6" fill="6" visible="no" active="no"/>
<layer number="35" name="tGlue" color="7" fill="4" visible="no" active="no"/>
<layer number="36" name="bGlue" color="7" fill="5" visible="no" active="no"/>
<layer number="37" name="tTest" color="7" fill="1" visible="no" active="no"/>
<layer number="38" name="bTest" color="7" fill="1" visible="no" active="no"/>
<layer number="39" name="tKeepout" color="4" fill="11" visible="no" active="no"/>
<layer number="40" name="bKeepout" color="1" fill="11" visible="no" active="no"/>
<layer number="41" name="tRestrict" color="4" fill="10" visible="no" active="no"/>
<layer number="42" name="bRestrict" color="1" fill="10" visible="no" active="no"/>
<layer number="43" name="vRestrict" color="2" fill="10" visible="no" active="no"/>
<layer number="44" name="Drills" color="7" fill="1" visible="no" active="no"/>
<layer number="45" name="Holes" color="7" fill="1" visible="no" active="no"/>
<layer number="46" name="Milling" color="3" fill="1" visible="no" active="no"/>
<layer number="47" name="Measures" color="7" fill="1" visible="no" active="no"/>
<layer number="48" name="Document" color="7" fill="1" visible="no" active="no"/>
<layer number="49" name="Reference" color="7" fill="1" visible="no" active="no"/>
<layer number="50" name="dxf" color="7" fill="1" visible="no" active="no"/>
<layer number="51" name="tDocu" color="7" fill="1" visible="no" active="no"/>
<layer number="52" name="bDocu" color="7" fill="1" visible="no" active="no"/>
<layer number="53" name="tGND_GNDA" color="7" fill="1" visible="no" active="no"/>
<layer number="54" name="bGND_GNDA" color="7" fill="1" visible="no" active="no"/>
<layer number="56" name="wert" color="7" fill="1" visible="no" active="no"/>
<layer number="57" name="tCAD" color="7" fill="1" visible="no" active="no"/>
<layer number="59" name="tCarbon" color="7" fill="1" visible="no" active="no"/>
<layer number="60" name="bCarbon" color="7" fill="1" visible="no" active="no"/>
<layer number="88" name="SimResults" color="9" fill="1" visible="yes" active="yes"/>
<layer number="89" name="SimProbes" color="9" fill="1" visible="yes" active="yes"/>
<layer number="90" name="Modules" color="5" fill="1" visible="yes" active="yes"/>
<layer number="91" name="Nets" color="2" fill="1" visible="yes" active="yes"/>
<layer number="92" name="Busses" color="1" fill="1" visible="yes" active="yes"/>
<layer number="93" name="Pins" color="2" fill="1" visible="yes" active="yes"/>
<layer number="94" name="Symbols" color="4" fill="1" visible="yes" active="yes"/>
<layer number="95" name="Names" color="7" fill="1" visible="yes" active="yes"/>
<layer number="96" name="Values" color="7" fill="1" visible="yes" active="yes"/>
<layer number="97" name="Info" color="7" fill="1" visible="yes" active="yes"/>
<layer number="98" name="Guide" color="6" fill="1" visible="yes" active="yes"/>
<layer number="99" name="SpiceOrder" color="7" fill="1" visible="no" active="no"/>
<layer number="100" name="Muster" color="7" fill="1" visible="no" active="no"/>
<layer number="101" name="Patch_Top" color="7" fill="1" visible="yes" active="yes"/>
<layer number="102" name="Vscore" color="7" fill="1" visible="yes" active="yes"/>
<layer number="103" name="tMap" color="7" fill="1" visible="yes" active="yes"/>
<layer number="104" name="Name" color="7" fill="1" visible="yes" active="yes"/>
<layer number="105" name="tPlate" color="7" fill="1" visible="yes" active="yes"/>
<layer number="106" name="bPlate" color="7" fill="1" visible="yes" active="yes"/>
<layer number="107" name="Crop" color="7" fill="1" visible="yes" active="yes"/>
<layer number="108" name="tplace-old" color="7" fill="1" visible="yes" active="yes"/>
<layer number="109" name="ref-old" color="7" fill="1" visible="yes" active="yes"/>
<layer number="110" name="fp0" color="7" fill="1" visible="yes" active="yes"/>
<layer number="111" name="LPC17xx" color="7" fill="1" visible="yes" active="yes"/>
<layer number="112" name="tSilk" color="7" fill="1" visible="yes" active="yes"/>
<layer number="113" name="IDFDebug" color="7" fill="1" visible="yes" active="yes"/>
<layer number="114" name="Badge_Outline" color="7" fill="1" visible="yes" active="yes"/>
<layer number="115" name="ReferenceISLANDS" color="7" fill="1" visible="yes" active="yes"/>
<layer number="116" name="Patch_BOT" color="7" fill="1" visible="yes" active="yes"/>
<layer number="117" name="BACKMAAT1" color="7" fill="1" visible="yes" active="yes"/>
<layer number="118" name="Rect_Pads" color="7" fill="1" visible="yes" active="yes"/>
<layer number="119" name="KAP_TEKEN" color="7" fill="1" visible="yes" active="yes"/>
<layer number="120" name="KAP_MAAT1" color="7" fill="1" visible="yes" active="yes"/>
<layer number="121" name="_tsilk" color="7" fill="1" visible="yes" active="yes"/>
<layer number="122" name="_bsilk" color="7" fill="1" visible="yes" active="yes"/>
<layer number="123" name="tTestmark" color="7" fill="1" visible="yes" active="yes"/>
<layer number="124" name="bTestmark" color="7" fill="1" visible="yes" active="yes"/>
<layer number="125" name="_tNames" color="7" fill="1" visible="yes" active="yes"/>
<layer number="126" name="_bNames" color="7" fill="1" visible="yes" active="yes"/>
<layer number="127" name="_tValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="128" name="_bValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="129" name="Mask" color="7" fill="1" visible="yes" active="yes"/>
<layer number="130" name="SMDSTROOK" color="7" fill="1" visible="yes" active="yes"/>
<layer number="131" name="tAdjust" color="7" fill="1" visible="yes" active="yes"/>
<layer number="132" name="bAdjust" color="7" fill="1" visible="yes" active="yes"/>
<layer number="133" name="bottom_silk" color="7" fill="1" visible="yes" active="yes"/>
<layer number="144" name="Drill_legend" color="7" fill="1" visible="yes" active="yes"/>
<layer number="150" name="Notes" color="7" fill="1" visible="yes" active="yes"/>
<layer number="151" name="HeatSink" color="7" fill="1" visible="yes" active="yes"/>
<layer number="152" name="_bDocu" color="7" fill="1" visible="yes" active="yes"/>
<layer number="153" name="FabDoc1" color="7" fill="1" visible="yes" active="yes"/>
<layer number="154" name="FabDoc2" color="7" fill="1" visible="yes" active="yes"/>
<layer number="155" name="FabDoc3" color="7" fill="15" visible="yes" active="yes"/>
<layer number="199" name="Contour" color="7" fill="1" visible="yes" active="yes"/>
<layer number="200" name="200bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="201" name="201bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="202" name="202bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="203" name="203bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="204" name="204bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="205" name="205bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="206" name="206bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="207" name="207bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="208" name="208bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="209" name="209bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="210" name="210bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="211" name="211bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="212" name="212bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="213" name="213bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="214" name="214bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="215" name="215bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="216" name="216bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="217" name="217bmp" color="7" fill="1" visible="no" active="no"/>
<layer number="218" name="218bmp" color="7" fill="1" visible="no" active="no"/>
<layer number="219" name="219bmp" color="7" fill="1" visible="no" active="no"/>
<layer number="220" name="220bmp" color="7" fill="1" visible="no" active="no"/>
<layer number="221" name="221bmp" color="7" fill="1" visible="no" active="no"/>
<layer number="222" name="222bmp" color="7" fill="1" visible="no" active="no"/>
<layer number="223" name="223bmp" color="7" fill="1" visible="no" active="no"/>
<layer number="224" name="224bmp" color="7" fill="1" visible="no" active="no"/>
<layer number="225" name="225bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="226" name="226bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="227" name="227bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="228" name="228bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="229" name="229bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="230" name="230bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="231" name="231bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="232" name="Eagle3D_PG2" color="7" fill="1" visible="yes" active="yes"/>
<layer number="233" name="Eagle3D_PG3" color="7" fill="1" visible="yes" active="yes"/>
<layer number="248" name="Housing" color="7" fill="1" visible="yes" active="yes"/>
<layer number="249" name="Edge" color="7" fill="1" visible="yes" active="yes"/>
<layer number="250" name="Descript" color="7" fill="1" visible="no" active="no"/>
<layer number="251" name="SMDround" color="7" fill="11" visible="no" active="no"/>
<layer number="254" name="cooling" color="7" fill="1" visible="yes" active="yes"/>
<layer number="255" name="routoute" color="7" fill="1" visible="yes" active="yes"/>
</layers>
<schematic xreflabel="%F%N/%S.%C%R" xrefpart="/%S.%C%R">
<libraries>
<library name="supply1" urn="urn:adsk.eagle:library:371">
<description>&lt;b&gt;Supply Symbols&lt;/b&gt;&lt;p&gt;
 GND, VCC, 0V, +5V, -5V, etc.&lt;p&gt;
 Please keep in mind, that these devices are necessary for the
 automatic wiring of the supply signals.&lt;p&gt;
 The pin name defined in the symbol is identical to the net which is to be wired automatically.&lt;p&gt;
 In this library the device names are the same as the pin names of the symbols, therefore the correct signal names appear next to the supply symbols in the schematic.&lt;p&gt;
 &lt;author&gt;Created by librarian@cadsoft.de&lt;/author&gt;</description>
<packages>
</packages>
<symbols>
<symbol name="+24V" urn="urn:adsk.eagle:symbol:26935/1" library_version="1">
<wire x1="1.27" y1="-0.635" x2="0" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="-1.27" y2="-0.635" width="0.254" layer="94"/>
<wire x1="1.27" y1="-0.635" x2="0" y2="1.27" width="0.254" layer="94"/>
<wire x1="0" y1="1.27" x2="-1.27" y2="-0.635" width="0.254" layer="94"/>
<text x="-2.54" y="-5.08" size="1.778" layer="96" rot="R90">&gt;VALUE</text>
<pin name="+24V" x="0" y="-2.54" visible="off" length="short" direction="sup" rot="R90"/>
</symbol>
<symbol name="0V" urn="urn:adsk.eagle:symbol:26927/1" library_version="1">
<wire x1="-1.905" y1="0" x2="1.905" y2="0" width="0.254" layer="94"/>
<text x="-1.905" y="-2.54" size="1.778" layer="96">&gt;VALUE</text>
<pin name="0V" x="0" y="2.54" visible="off" length="short" direction="sup" rot="R270"/>
</symbol>
<symbol name="VSS" urn="urn:adsk.eagle:symbol:26944/1" library_version="1">
<wire x1="-1.27" y1="1.905" x2="0" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="1.27" y2="1.905" width="0.254" layer="94"/>
<wire x1="0" y1="-1.27" x2="1.27" y2="1.905" width="0.254" layer="94"/>
<wire x1="-1.27" y1="1.905" x2="0" y2="-1.27" width="0.254" layer="94"/>
<text x="-2.54" y="-5.08" size="1.778" layer="96" rot="R90">&gt;VALUE</text>
<pin name="VSS" x="0" y="2.54" visible="off" length="short" direction="sup" rot="R270"/>
</symbol>
<symbol name="GND" urn="urn:adsk.eagle:symbol:26925/1" library_version="1">
<wire x1="-1.905" y1="0" x2="1.905" y2="0" width="0.254" layer="94"/>
<text x="-2.54" y="-2.54" size="1.778" layer="96">&gt;VALUE</text>
<pin name="GND" x="0" y="2.54" visible="off" length="short" direction="sup" rot="R270"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="+24V" urn="urn:adsk.eagle:component:26964/1" prefix="P+" library_version="1">
<description>&lt;b&gt;SUPPLY SYMBOL&lt;/b&gt;</description>
<gates>
<gate name="1" symbol="+24V" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="0V" urn="urn:adsk.eagle:component:26956/1" prefix="GND" library_version="1">
<description>&lt;b&gt;SUPPLY SYMBOL&lt;/b&gt;</description>
<gates>
<gate name="1" symbol="0V" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="VSS" urn="urn:adsk.eagle:component:26973/1" prefix="VSS" library_version="1">
<description>&lt;b&gt;SUPPLY SYMBOL&lt;/b&gt;</description>
<gates>
<gate name="G$1" symbol="VSS" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="GND" urn="urn:adsk.eagle:component:26954/1" prefix="GND" library_version="1">
<description>&lt;b&gt;SUPPLY SYMBOL&lt;/b&gt;</description>
<gates>
<gate name="1" symbol="GND" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="molex 0039290083" urn="urn:adsk.wipprod:fs.file:vf.LM2bSIezQECa3ZpQ7Zadyg">
<packages>
<package name="CONN_SD-5566-002_08_MOL" library_version="3">
<pad name="1" x="0" y="0" drill="1.4478" diameter="1.9558"/>
<pad name="2" x="4.2" y="0" drill="1.4478" diameter="1.9558"/>
<pad name="3" x="8.4" y="0" drill="1.4478" diameter="1.9558"/>
<pad name="4" x="12.6" y="0" drill="1.4478" diameter="1.9558"/>
<pad name="5" x="0" y="-5.5" drill="1.4478" diameter="1.9558"/>
<pad name="6" x="4.2" y="-5.5" drill="1.4478" diameter="1.9558"/>
<pad name="7" x="8.4" y="-5.5" drill="1.4478" diameter="1.9558"/>
<pad name="8" x="12.6" y="-5.5" drill="1.4478" diameter="1.9558"/>
<wire x1="0" y1="0" x2="0" y2="7.33" width="0.1524" layer="48"/>
<wire x1="4.2" y1="0" x2="4.2" y2="7.33" width="0.1524" layer="48"/>
<wire x1="0" y1="6.949" x2="4.2" y2="6.949" width="0.1524" layer="48"/>
<wire x1="0" y1="6.949" x2="0.254" y2="7.076" width="0.1524" layer="48"/>
<wire x1="0" y1="6.949" x2="0.254" y2="6.822" width="0.1524" layer="48"/>
<wire x1="0.254" y1="7.076" x2="0.254" y2="6.822" width="0.1524" layer="48"/>
<wire x1="4.2" y1="6.949" x2="3.946" y2="7.076" width="0.1524" layer="48"/>
<wire x1="4.2" y1="6.949" x2="3.946" y2="6.822" width="0.1524" layer="48"/>
<wire x1="3.946" y1="7.076" x2="3.946" y2="6.822" width="0.1524" layer="48"/>
<wire x1="-3.098" y1="2.25" x2="-3.098" y2="13.045" width="0.1524" layer="48"/>
<wire x1="15.698" y1="2.25" x2="15.698" y2="13.045" width="0.1524" layer="48"/>
<wire x1="-3.098" y1="12.664" x2="15.698" y2="12.664" width="0.1524" layer="48"/>
<wire x1="-3.098" y1="12.664" x2="-2.844" y2="12.791" width="0.1524" layer="48"/>
<wire x1="-3.098" y1="12.664" x2="-2.844" y2="12.537" width="0.1524" layer="48"/>
<wire x1="-2.844" y1="12.791" x2="-2.844" y2="12.537" width="0.1524" layer="48"/>
<wire x1="15.698" y1="12.664" x2="15.444" y2="12.791" width="0.1524" layer="48"/>
<wire x1="15.698" y1="12.664" x2="15.444" y2="12.537" width="0.1524" layer="48"/>
<wire x1="15.444" y1="12.791" x2="15.444" y2="12.537" width="0.1524" layer="48"/>
<wire x1="0" y1="0" x2="18.619" y2="0" width="0.1524" layer="48"/>
<wire x1="0" y1="-5.5" x2="18.619" y2="-5.5" width="0.1524" layer="48"/>
<wire x1="18.238" y1="0" x2="18.238" y2="-5.5" width="0.1524" layer="48"/>
<wire x1="18.238" y1="0" x2="18.111" y2="-0.254" width="0.1524" layer="48"/>
<wire x1="18.238" y1="0" x2="18.365" y2="-0.254" width="0.1524" layer="48"/>
<wire x1="18.111" y1="-0.254" x2="18.365" y2="-0.254" width="0.1524" layer="48"/>
<wire x1="18.238" y1="-5.5" x2="18.111" y2="-5.246" width="0.1524" layer="48"/>
<wire x1="18.238" y1="-5.5" x2="18.365" y2="-5.246" width="0.1524" layer="48"/>
<wire x1="18.111" y1="-5.246" x2="18.365" y2="-5.246" width="0.1524" layer="48"/>
<wire x1="-3.098" y1="2.25" x2="-13.893" y2="2.25" width="0.1524" layer="48"/>
<wire x1="6.3" y1="-2.75" x2="-13.893" y2="-2.75" width="0.1524" layer="48"/>
<wire x1="-13.512" y1="2.25" x2="-13.512" y2="-2.75" width="0.1524" layer="48"/>
<wire x1="-13.512" y1="2.25" x2="-13.639" y2="1.996" width="0.1524" layer="48"/>
<wire x1="-13.512" y1="2.25" x2="-13.385" y2="1.996" width="0.1524" layer="48"/>
<wire x1="-13.639" y1="1.996" x2="-13.385" y2="1.996" width="0.1524" layer="48"/>
<wire x1="-13.512" y1="-2.75" x2="-13.639" y2="-2.496" width="0.1524" layer="48"/>
<wire x1="-13.512" y1="-2.75" x2="-13.385" y2="-2.496" width="0.1524" layer="48"/>
<wire x1="-13.639" y1="-2.496" x2="-13.385" y2="-2.496" width="0.1524" layer="48"/>
<wire x1="-3.098" y1="2.25" x2="-12.623" y2="2.25" width="0.1524" layer="48"/>
<wire x1="-3.098" y1="-8.7482" x2="-12.623" y2="-8.7482" width="0.1524" layer="48"/>
<wire x1="-12.242" y1="2.25" x2="-12.242" y2="-8.7482" width="0.1524" layer="48"/>
<wire x1="-12.242" y1="2.25" x2="-12.369" y2="1.996" width="0.1524" layer="48"/>
<wire x1="-12.242" y1="2.25" x2="-12.115" y2="1.996" width="0.1524" layer="48"/>
<wire x1="-12.369" y1="1.996" x2="-12.115" y2="1.996" width="0.1524" layer="48"/>
<wire x1="-12.242" y1="-8.7482" x2="-12.369" y2="-8.4942" width="0.1524" layer="48"/>
<wire x1="-12.242" y1="-8.7482" x2="-12.115" y2="-8.4942" width="0.1524" layer="48"/>
<wire x1="-12.369" y1="-8.4942" x2="-12.115" y2="-8.4942" width="0.1524" layer="48"/>
<text x="-9.4798" y="-12.8122" size="1.27" layer="48" ratio="6">Default Padstyle: EX77Y77D57P</text>
<text x="-10.2424" y="-14.7172" size="1.27" layer="48" ratio="6">1st Mtg Padstyle: RX80Y110D50P</text>
<text x="-10.4288" y="-16.6222" size="1.27" layer="48" ratio="6">2nd Mtg Padstyle: RX50Y100D40P</text>
<text x="-10.4288" y="-18.5272" size="1.27" layer="48" ratio="6">3rd Mtg Padstyle: RX100Y50D40P</text>
<text x="-10.6323" y="-20.4322" size="1.27" layer="48" ratio="6">Left Mtg Padstyle: RX50Y100D30P</text>
<text x="-11.2085" y="-22.3372" size="1.27" layer="48" ratio="6">Right Mtg Padstyle: RX50Y100D30P</text>
<text x="-8.5136" y="-24.2422" size="1.27" layer="48" ratio="6">Alt Padstyle 1: OX60Y90D30P</text>
<text x="-8.5136" y="-26.1472" size="1.27" layer="48" ratio="6">Alt Padstyle 2: OX90Y60D30P</text>
<text x="-1.3661" y="7.457" size="0.635" layer="48" ratio="4">0.165in/4.2mm</text>
<text x="2.2576" y="13.172" size="0.635" layer="48" ratio="4">0.74in/18.796mm</text>
<text x="18.746" y="-3.0675" size="0.635" layer="48" ratio="4">0.217in/5.5mm</text>
<text x="-19.9861" y="-0.5675" size="0.635" layer="48" ratio="4">0.197in/5mm</text>
<text x="-21.4111" y="-3.5666" size="0.635" layer="48" ratio="4">0.433in/10.998mm</text>
<wire x1="-3.225" y1="-8.8752" x2="15.825" y2="-8.8752" width="0.1524" layer="21"/>
<wire x1="15.825" y1="-8.8752" x2="15.825" y2="2.377" width="0.1524" layer="21"/>
<wire x1="15.825" y1="2.377" x2="-3.225" y2="2.377" width="0.1524" layer="21"/>
<wire x1="-3.225" y1="2.377" x2="-3.225" y2="-8.8752" width="0.1524" layer="21"/>
<wire x1="-3.098" y1="-8.7482" x2="15.698" y2="-8.7482" width="0.1524" layer="51"/>
<wire x1="15.698" y1="-8.7482" x2="15.698" y2="2.25" width="0.1524" layer="51"/>
<wire x1="15.698" y1="2.25" x2="-3.098" y2="2.25" width="0.1524" layer="51"/>
<wire x1="-3.098" y1="2.25" x2="-3.098" y2="-8.7482" width="0.1524" layer="51"/>
<wire x1="0.381" y1="0" x2="-0.381" y2="0" width="0.508" layer="51" curve="-180"/>
<wire x1="-0.381" y1="0" x2="0.381" y2="0" width="0.508" layer="51" curve="-180"/>
<wire x1="-4.876" y1="0" x2="-5.638" y2="0" width="0.508" layer="22" curve="-180"/>
<wire x1="-5.638" y1="0" x2="-4.876" y2="0" width="0.508" layer="22" curve="-180"/>
<text x="3.0288" y="-3.385" size="1.27" layer="27" ratio="6">&gt;Name</text>
<text x="4.5712" y="-3.385" size="1.27" layer="27" ratio="6">&gt;Value</text>
</package>
</packages>
<symbols>
<symbol name="CONN_008P_000C_1" library_version="1">
<pin name="1" x="0" y="0" visible="pad" length="middle" direction="pas"/>
<pin name="2" x="0" y="-2.54" visible="pad" length="middle" direction="pas"/>
<pin name="3" x="0" y="-5.08" visible="pad" length="middle" direction="pas"/>
<pin name="4" x="0" y="-7.62" visible="pad" length="middle" direction="pas"/>
<pin name="5" x="0" y="-10.16" visible="pad" length="middle" direction="pas"/>
<pin name="6" x="0" y="-12.7" visible="pad" length="middle" direction="pas"/>
<pin name="7" x="0" y="-15.24" visible="pad" length="middle" direction="pas"/>
<pin name="8" x="0" y="-17.78" visible="pad" length="middle" direction="pas"/>
<wire x1="10.16" y1="0" x2="5.08" y2="0" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-2.54" x2="5.08" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-5.08" x2="5.08" y2="-5.08" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-7.62" x2="5.08" y2="-7.62" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-10.16" x2="5.08" y2="-10.16" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-12.7" x2="5.08" y2="-12.7" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-15.24" x2="5.08" y2="-15.24" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-17.78" x2="5.08" y2="-17.78" width="0.1524" layer="94"/>
<wire x1="10.16" y1="0" x2="8.89" y2="0.8467" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-2.54" x2="8.89" y2="-1.6933" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-5.08" x2="8.89" y2="-4.2333" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-7.62" x2="8.89" y2="-6.7733" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-10.16" x2="8.89" y2="-9.3133" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-12.7" x2="8.89" y2="-11.8533" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-15.24" x2="8.89" y2="-14.3933" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-17.78" x2="8.89" y2="-16.9333" width="0.1524" layer="94"/>
<wire x1="10.16" y1="0" x2="8.89" y2="-0.8467" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-2.54" x2="8.89" y2="-3.3867" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-5.08" x2="8.89" y2="-5.9267" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-7.62" x2="8.89" y2="-8.4667" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-10.16" x2="8.89" y2="-11.0067" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-12.7" x2="8.89" y2="-13.5467" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-15.24" x2="8.89" y2="-16.0867" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-17.78" x2="8.89" y2="-18.6267" width="0.1524" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-20.32" width="0.1524" layer="94"/>
<wire x1="5.08" y1="-20.32" x2="12.7" y2="-20.32" width="0.1524" layer="94"/>
<wire x1="12.7" y1="-20.32" x2="12.7" y2="2.54" width="0.1524" layer="94"/>
<wire x1="12.7" y1="2.54" x2="5.08" y2="2.54" width="0.1524" layer="94"/>
<text x="4.1646" y="5.3086" size="2.083" layer="95" ratio="6">&gt;Name</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="39290083" prefix="J" library_version="3">
<gates>
<gate name="A" symbol="CONN_008P_000C_1" x="0" y="0"/>
</gates>
<devices>
<device name="CONN_SD-5566-002_08_MOL" package="CONN_SD-5566-002_08_MOL">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
<connect gate="A" pin="7" pad="7"/>
<connect gate="A" pin="8" pad="8"/>
</connects>
<technologies>
<technology name="">
<attribute name="COPYRIGHT" value="Copyright (C) 2025 Ultra Librarian. All rights reserved." constant="no"/>
<attribute name="DATASHEET" value="https://www.molex.com/en-us/products/part-detail-pdf/39290083?display=pdf" constant="no"/>
<attribute name="DESCRIPTION" value="Mini-Fit Jr. Vertical Header, 4.20mm Pitch, Dual Row, 8 Circuits, without Snap-in Plastic Peg PCB Lock, Gold, Natural" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Molex Connector Corporation" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="39290083" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Resistor" urn="urn:adsk.eagle:library:16378527">
<description>Resistors, Potentiometers, TrimPot</description>
<packages>
<package name="RESC1005X40" urn="urn:adsk.eagle:footprint:16378540/6" library_version="26">
<description>Chip, 1.05 X 0.54 X 0.40 mm body
&lt;p&gt;Chip package with body size 1.05 X 0.54 X 0.40 mm&lt;/p&gt;</description>
<wire x1="0.55" y1="0.636" x2="-0.55" y2="0.636" width="0.127" layer="21"/>
<wire x1="0.55" y1="-0.636" x2="-0.55" y2="-0.636" width="0.127" layer="21"/>
<wire x1="0.55" y1="-0.3" x2="-0.55" y2="-0.3" width="0.12" layer="51"/>
<wire x1="-0.55" y1="-0.3" x2="-0.55" y2="0.3" width="0.12" layer="51"/>
<wire x1="-0.55" y1="0.3" x2="0.55" y2="0.3" width="0.12" layer="51"/>
<wire x1="0.55" y1="0.3" x2="0.55" y2="-0.3" width="0.12" layer="51"/>
<smd name="1" x="-0.5075" y="0" dx="0.5351" dy="0.644" layer="1"/>
<smd name="2" x="0.5075" y="0" dx="0.5351" dy="0.644" layer="1"/>
<text x="0" y="2.54" size="1.27" layer="25" align="top-center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="bottom-center">&gt;VALUE</text>
</package>
<package name="RESC1608X60" urn="urn:adsk.eagle:footprint:16378537/6" library_version="26">
<description>Chip, 1.60 X 0.82 X 0.60 mm body
&lt;p&gt;Chip package with body size 1.60 X 0.82 X 0.60 mm&lt;/p&gt;</description>
<wire x1="0.85" y1="0.8009" x2="-0.85" y2="0.8009" width="0.127" layer="21"/>
<wire x1="0.85" y1="-0.8009" x2="-0.85" y2="-0.8009" width="0.127" layer="21"/>
<wire x1="0.85" y1="-0.475" x2="-0.85" y2="-0.475" width="0.12" layer="51"/>
<wire x1="-0.85" y1="-0.475" x2="-0.85" y2="0.475" width="0.12" layer="51"/>
<wire x1="-0.85" y1="0.475" x2="0.85" y2="0.475" width="0.12" layer="51"/>
<wire x1="0.85" y1="0.475" x2="0.85" y2="-0.475" width="0.12" layer="51"/>
<smd name="1" x="-0.8152" y="0" dx="0.7987" dy="0.9739" layer="1"/>
<smd name="2" x="0.8152" y="0" dx="0.7987" dy="0.9739" layer="1"/>
<text x="0" y="2.54" size="1.27" layer="25" align="top-center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="bottom-center">&gt;VALUE</text>
</package>
<package name="RESC2012X65" urn="urn:adsk.eagle:footprint:16378532/6" library_version="26">
<description>Chip, 2.00 X 1.25 X 0.65 mm body
&lt;p&gt;Chip package with body size 2.00 X 1.25 X 0.65 mm&lt;/p&gt;</description>
<wire x1="1.075" y1="1.0241" x2="-1.075" y2="1.0241" width="0.127" layer="21"/>
<wire x1="1.075" y1="-1.0241" x2="-1.075" y2="-1.0241" width="0.127" layer="21"/>
<wire x1="1.075" y1="-0.7" x2="-1.075" y2="-0.7" width="0.12" layer="51"/>
<wire x1="-1.075" y1="-0.7" x2="-1.075" y2="0.7" width="0.12" layer="51"/>
<wire x1="-1.075" y1="0.7" x2="1.075" y2="0.7" width="0.12" layer="51"/>
<wire x1="1.075" y1="0.7" x2="1.075" y2="-0.7" width="0.12" layer="51"/>
<smd name="1" x="-0.9195" y="0" dx="1.0312" dy="1.4202" layer="1"/>
<smd name="2" x="0.9195" y="0" dx="1.0312" dy="1.4202" layer="1"/>
<text x="0" y="2.54" size="1.27" layer="25" align="top-center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="bottom-center">&gt;VALUE</text>
</package>
<package name="RESC3216X70" urn="urn:adsk.eagle:footprint:16378539/6" library_version="26">
<description>Chip, 3.20 X 1.60 X 0.70 mm body
&lt;p&gt;Chip package with body size 3.20 X 1.60 X 0.70 mm&lt;/p&gt;</description>
<wire x1="1.7" y1="1.2217" x2="-1.7" y2="1.2217" width="0.127" layer="21"/>
<wire x1="1.7" y1="-1.2217" x2="-1.7" y2="-1.2217" width="0.127" layer="21"/>
<wire x1="1.7" y1="-0.9" x2="-1.7" y2="-0.9" width="0.12" layer="51"/>
<wire x1="-1.7" y1="-0.9" x2="-1.7" y2="0.9" width="0.12" layer="51"/>
<wire x1="-1.7" y1="0.9" x2="1.7" y2="0.9" width="0.12" layer="51"/>
<wire x1="1.7" y1="0.9" x2="1.7" y2="-0.9" width="0.12" layer="51"/>
<smd name="1" x="-1.4754" y="0" dx="1.1646" dy="1.8153" layer="1"/>
<smd name="2" x="1.4754" y="0" dx="1.1646" dy="1.8153" layer="1"/>
<text x="0" y="2.54" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="center">&gt;VALUE</text>
</package>
<package name="RESC3224X71" urn="urn:adsk.eagle:footprint:16378536/6" library_version="26">
<description>Chip, 3.20 X 2.49 X 0.71 mm body
&lt;p&gt;Chip package with body size 3.20 X 2.49 X 0.71 mm&lt;/p&gt;</description>
<wire x1="1.675" y1="1.6441" x2="-1.675" y2="1.6441" width="0.127" layer="21"/>
<wire x1="1.675" y1="-1.6441" x2="-1.675" y2="-1.6441" width="0.127" layer="21"/>
<wire x1="1.675" y1="-1.32" x2="-1.675" y2="-1.32" width="0.12" layer="51"/>
<wire x1="-1.675" y1="-1.32" x2="-1.675" y2="1.32" width="0.12" layer="51"/>
<wire x1="-1.675" y1="1.32" x2="1.675" y2="1.32" width="0.12" layer="51"/>
<wire x1="1.675" y1="1.32" x2="1.675" y2="-1.32" width="0.12" layer="51"/>
<smd name="1" x="-1.4695" y="0" dx="1.1312" dy="2.6602" layer="1"/>
<smd name="2" x="1.4695" y="0" dx="1.1312" dy="2.6602" layer="1"/>
<text x="0" y="2.54" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="center">&gt;VALUE</text>
</package>
<package name="RESC5025X71" urn="urn:adsk.eagle:footprint:16378538/6" library_version="26">
<description>Chip, 5.00 X 2.50 X 0.71 mm body
&lt;p&gt;Chip package with body size 5.00 X 2.50 X 0.71 mm&lt;/p&gt;</description>
<wire x1="2.575" y1="1.6491" x2="-2.575" y2="1.6491" width="0.127" layer="21"/>
<wire x1="2.575" y1="-1.6491" x2="-2.575" y2="-1.6491" width="0.127" layer="21"/>
<wire x1="2.575" y1="-1.325" x2="-2.575" y2="-1.325" width="0.12" layer="51"/>
<wire x1="-2.575" y1="-1.325" x2="-2.575" y2="1.325" width="0.12" layer="51"/>
<wire x1="-2.575" y1="1.325" x2="2.575" y2="1.325" width="0.12" layer="51"/>
<wire x1="2.575" y1="1.325" x2="2.575" y2="-1.325" width="0.12" layer="51"/>
<smd name="1" x="-2.3195" y="0" dx="1.2312" dy="2.6702" layer="1"/>
<smd name="2" x="2.3195" y="0" dx="1.2312" dy="2.6702" layer="1"/>
<text x="0" y="2.54" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="center">&gt;VALUE</text>
</package>
<package name="RESC6332X71" urn="urn:adsk.eagle:footprint:16378533/6" library_version="26">
<description>Chip, 6.30 X 3.20 X 0.71 mm body
&lt;p&gt;Chip package with body size 6.30 X 3.20 X 0.71 mm&lt;/p&gt;</description>
<wire x1="3.225" y1="1.9991" x2="-3.225" y2="1.9991" width="0.127" layer="21"/>
<wire x1="3.225" y1="-1.9991" x2="-3.225" y2="-1.9991" width="0.127" layer="21"/>
<wire x1="3.225" y1="-1.675" x2="-3.225" y2="-1.675" width="0.12" layer="51"/>
<wire x1="-3.225" y1="-1.675" x2="-3.225" y2="1.675" width="0.12" layer="51"/>
<wire x1="-3.225" y1="1.675" x2="3.225" y2="1.675" width="0.12" layer="51"/>
<wire x1="3.225" y1="1.675" x2="3.225" y2="-1.675" width="0.12" layer="51"/>
<smd name="1" x="-2.9695" y="0" dx="1.2312" dy="3.3702" layer="1"/>
<smd name="2" x="2.9695" y="0" dx="1.2312" dy="3.3702" layer="1"/>
<text x="0" y="3.81" size="1.27" layer="25" align="top-center">&gt;NAME</text>
<text x="0" y="-3.81" size="1.27" layer="27" align="bottom-center">&gt;VALUE</text>
</package>
<package name="RESAD1176W63L850D250B" urn="urn:adsk.eagle:footprint:16378542/6" library_version="26">
<description>AXIAL Resistor, 11.76 mm pitch, 8.5 mm body length, 2.5 mm body diameter
&lt;p&gt;AXIAL Resistor package with 11.76 mm pitch, 0.63 mm lead diameter, 8.5 mm body length and 2.5 mm body diameter&lt;/p&gt;</description>
<wire x1="-4.25" y1="1.25" x2="-4.25" y2="-1.25" width="0.127" layer="21"/>
<wire x1="-4.25" y1="-1.25" x2="4.25" y2="-1.25" width="0.127" layer="21"/>
<wire x1="4.25" y1="-1.25" x2="4.25" y2="1.25" width="0.127" layer="21"/>
<wire x1="4.25" y1="1.25" x2="-4.25" y2="1.25" width="0.127" layer="21"/>
<wire x1="-4.25" y1="0" x2="-4.911" y2="0" width="0.127" layer="21"/>
<wire x1="4.25" y1="0" x2="4.911" y2="0" width="0.127" layer="21"/>
<wire x1="4.25" y1="-1.25" x2="-4.25" y2="-1.25" width="0.12" layer="51"/>
<wire x1="-4.25" y1="-1.25" x2="-4.25" y2="1.25" width="0.12" layer="51"/>
<wire x1="-4.25" y1="1.25" x2="4.25" y2="1.25" width="0.12" layer="51"/>
<wire x1="4.25" y1="1.25" x2="4.25" y2="-1.25" width="0.12" layer="51"/>
<pad name="1" x="-5.88" y="0" drill="0.83" diameter="1.43"/>
<pad name="2" x="5.88" y="0" drill="0.83" diameter="1.43"/>
<text x="0" y="2.54" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="center">&gt;VALUE</text>
</package>
<package name="RESMELF3515" urn="urn:adsk.eagle:footprint:16378534/6" library_version="26">
<description>MELF, 3.50 mm length, 1.52 mm diameter
&lt;p&gt;MELF Resistor package with 3.50 mm length and 1.52 mm diameter&lt;/p&gt;</description>
<wire x1="1.105" y1="1.1825" x2="-1.105" y2="1.1825" width="0.127" layer="21"/>
<wire x1="-1.105" y1="-1.1825" x2="1.105" y2="-1.1825" width="0.127" layer="21"/>
<wire x1="1.85" y1="-0.8" x2="-1.85" y2="-0.8" width="0.12" layer="51"/>
<wire x1="-1.85" y1="-0.8" x2="-1.85" y2="0.8" width="0.12" layer="51"/>
<wire x1="-1.85" y1="0.8" x2="1.85" y2="0.8" width="0.12" layer="51"/>
<wire x1="1.85" y1="0.8" x2="1.85" y2="-0.8" width="0.12" layer="51"/>
<smd name="1" x="-1.6813" y="0" dx="1.1527" dy="1.7371" layer="1"/>
<smd name="2" x="1.6813" y="0" dx="1.1527" dy="1.7371" layer="1"/>
<text x="0" y="2.54" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="center">&gt;VALUE</text>
</package>
<package name="RESMELF2014" urn="urn:adsk.eagle:footprint:16378535/6" library_version="26">
<description>MELF, 2.00 mm length, 1.40 mm diameter
&lt;p&gt;MELF Resistor package with 2.00 mm length and 1.40 mm diameter&lt;/p&gt;</description>
<wire x1="0.5189" y1="1.114" x2="-0.5189" y2="1.114" width="0.127" layer="21"/>
<wire x1="-0.5189" y1="-1.114" x2="0.5189" y2="-1.114" width="0.127" layer="21"/>
<wire x1="1.05" y1="-0.725" x2="-1.05" y2="-0.725" width="0.12" layer="51"/>
<wire x1="-1.05" y1="-0.725" x2="-1.05" y2="0.725" width="0.12" layer="51"/>
<wire x1="-1.05" y1="0.725" x2="1.05" y2="0.725" width="0.12" layer="51"/>
<wire x1="1.05" y1="0.725" x2="1.05" y2="-0.725" width="0.12" layer="51"/>
<smd name="1" x="-0.9918" y="0" dx="0.9456" dy="1.6" layer="1"/>
<smd name="2" x="0.9918" y="0" dx="0.9456" dy="1.6" layer="1"/>
<text x="0" y="2.54" size="1.27" layer="25" align="top-center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="bottom-center">&gt;VALUE</text>
</package>
<package name="RESMELF5924" urn="urn:adsk.eagle:footprint:16378541/6" library_version="26">
<description>MELF, 5.90 mm length, 2.45 mm diameter
&lt;p&gt;MELF Resistor package with 5.90 mm length and 2.45 mm diameter&lt;/p&gt;</description>
<wire x1="2.1315" y1="1.639" x2="-2.1315" y2="1.639" width="0.127" layer="21"/>
<wire x1="-2.1315" y1="-1.639" x2="2.1315" y2="-1.639" width="0.127" layer="21"/>
<wire x1="3.05" y1="-1.25" x2="-3.05" y2="-1.25" width="0.12" layer="51"/>
<wire x1="-3.05" y1="-1.25" x2="-3.05" y2="1.25" width="0.12" layer="51"/>
<wire x1="-3.05" y1="1.25" x2="3.05" y2="1.25" width="0.12" layer="51"/>
<wire x1="3.05" y1="1.25" x2="3.05" y2="-1.25" width="0.12" layer="51"/>
<smd name="1" x="-2.7946" y="0" dx="1.3261" dy="2.65" layer="1"/>
<smd name="2" x="2.7946" y="0" dx="1.3261" dy="2.65" layer="1"/>
<text x="0" y="2.54" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="center">&gt;VALUE</text>
</package>
<package name="RESMELF3218" urn="urn:adsk.eagle:footprint:16378531/6" library_version="26">
<description>MELF, 3.20 mm length, 1.80 mm diameter
&lt;p&gt;MELF Resistor package with 3.20 mm length and 1.80 mm diameter&lt;/p&gt;</description>
<wire x1="0.8815" y1="1.314" x2="-0.8815" y2="1.314" width="0.127" layer="21"/>
<wire x1="-0.8815" y1="-1.314" x2="0.8815" y2="-1.314" width="0.127" layer="21"/>
<wire x1="1.7" y1="-0.925" x2="-1.7" y2="-0.925" width="0.12" layer="51"/>
<wire x1="-1.7" y1="-0.925" x2="-1.7" y2="0.925" width="0.12" layer="51"/>
<wire x1="-1.7" y1="0.925" x2="1.7" y2="0.925" width="0.12" layer="51"/>
<wire x1="1.7" y1="0.925" x2="1.7" y2="-0.925" width="0.12" layer="51"/>
<smd name="1" x="-1.4946" y="0" dx="1.2261" dy="2" layer="1"/>
<smd name="2" x="1.4946" y="0" dx="1.2261" dy="2" layer="1"/>
<text x="0" y="2.54" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="center">&gt;VALUE</text>
</package>
<package name="RESAD724W46L381D178B" urn="urn:adsk.eagle:footprint:16378530/6" library_version="26">
<description>Axial Resistor, 7.24 mm pitch, 3.81 mm body length, 1.78 mm body diameter
&lt;p&gt;Axial Resistor package with 7.24 mm pitch (lead spacing), 0.46 mm lead diameter, 3.81 mm body length and 1.78 mm body diameter&lt;/p&gt;</description>
<wire x1="-2.16" y1="1.015" x2="-2.16" y2="-1.015" width="0.127" layer="21"/>
<wire x1="-2.16" y1="-1.015" x2="2.16" y2="-1.015" width="0.127" layer="21"/>
<wire x1="2.16" y1="-1.015" x2="2.16" y2="1.015" width="0.127" layer="21"/>
<wire x1="2.16" y1="1.015" x2="-2.16" y2="1.015" width="0.127" layer="21"/>
<wire x1="-2.16" y1="0" x2="-2.736" y2="0" width="0.127" layer="21"/>
<wire x1="2.16" y1="0" x2="2.736" y2="0" width="0.127" layer="21"/>
<wire x1="2.16" y1="-1.015" x2="-2.16" y2="-1.015" width="0.12" layer="51"/>
<wire x1="-2.16" y1="-1.015" x2="-2.16" y2="1.015" width="0.12" layer="51"/>
<wire x1="-2.16" y1="1.015" x2="2.16" y2="1.015" width="0.12" layer="51"/>
<wire x1="2.16" y1="1.015" x2="2.16" y2="-1.015" width="0.12" layer="51"/>
<pad name="1" x="-3.62" y="0" drill="0.66" diameter="1.26"/>
<pad name="2" x="3.62" y="0" drill="0.66" diameter="1.26"/>
<text x="0" y="2.54" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="center">&gt;VALUE</text>
</package>
</packages>
<packages3d>
<package3d name="RESC1005X40" urn="urn:adsk.eagle:package:16378568/7" type="model">
<description>Chip, 1.05 X 0.54 X 0.40 mm body
&lt;p&gt;Chip package with body size 1.05 X 0.54 X 0.40 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="RESC1005X40"/>
</packageinstances>
</package3d>
<package3d name="RESC1608X60" urn="urn:adsk.eagle:package:16378565/7" type="model">
<description>Chip, 1.60 X 0.82 X 0.60 mm body
&lt;p&gt;Chip package with body size 1.60 X 0.82 X 0.60 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="RESC1608X60"/>
</packageinstances>
</package3d>
<package3d name="RESC2012X65" urn="urn:adsk.eagle:package:16378559/7" type="model">
<description>Chip, 2.00 X 1.25 X 0.65 mm body
&lt;p&gt;Chip package with body size 2.00 X 1.25 X 0.65 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="RESC2012X65"/>
</packageinstances>
</package3d>
<package3d name="RESC3216X70" urn="urn:adsk.eagle:package:16378566/7" type="model">
<description>Chip, 3.20 X 1.60 X 0.70 mm body
&lt;p&gt;Chip package with body size 3.20 X 1.60 X 0.70 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="RESC3216X70"/>
</packageinstances>
</package3d>
<package3d name="RESC3224X71" urn="urn:adsk.eagle:package:16378563/8" type="model">
<description>Chip, 3.20 X 2.49 X 0.71 mm body
&lt;p&gt;Chip package with body size 3.20 X 2.49 X 0.71 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="RESC3224X71"/>
</packageinstances>
</package3d>
<package3d name="RESC5025X71" urn="urn:adsk.eagle:package:16378564/7" type="model">
<description>Chip, 5.00 X 2.50 X 0.71 mm body
&lt;p&gt;Chip package with body size 5.00 X 2.50 X 0.71 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="RESC5025X71"/>
</packageinstances>
</package3d>
<package3d name="RESC6332X71L" urn="urn:adsk.eagle:package:16378557/8" type="model">
<description>Chip, 6.30 X 3.20 X 0.71 mm body
&lt;p&gt;Chip package with body size 6.30 X 3.20 X 0.71 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="RESC6332X71"/>
</packageinstances>
</package3d>
<package3d name="RESAD1176W63L850D250B" urn="urn:adsk.eagle:package:16378560/7" type="model">
<description>AXIAL Resistor, 11.76 mm pitch, 8.5 mm body length, 2.5 mm body diameter
&lt;p&gt;AXIAL Resistor package with 11.76 mm pitch, 0.63 mm lead diameter, 8.5 mm body length and 2.5 mm body diameter&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="RESAD1176W63L850D250B"/>
</packageinstances>
</package3d>
<package3d name="RESMELF3515" urn="urn:adsk.eagle:package:16378562/7" type="model">
<description>MELF, 3.50 mm length, 1.52 mm diameter
&lt;p&gt;MELF Resistor package with 3.50 mm length and 1.52 mm diameter&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="RESMELF3515"/>
</packageinstances>
</package3d>
<package3d name="RESMELF2014" urn="urn:adsk.eagle:package:16378558/7" type="model">
<description>MELF, 2.00 mm length, 1.40 mm diameter
&lt;p&gt;MELF Resistor package with 2.00 mm length and 1.40 mm diameter&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="RESMELF2014"/>
</packageinstances>
</package3d>
<package3d name="RESMELF5924" urn="urn:adsk.eagle:package:16378567/8" type="model">
<description>MELF, 5.90 mm length, 2.45 mm diameter
&lt;p&gt;MELF Resistor package with 5.90 mm length and 2.45 mm diameter&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="RESMELF5924"/>
</packageinstances>
</package3d>
<package3d name="RESMELF3218" urn="urn:adsk.eagle:package:16378556/7" type="model">
<description>MELF, 3.20 mm length, 1.80 mm diameter
&lt;p&gt;MELF Resistor package with 3.20 mm length and 1.80 mm diameter&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="RESMELF3218"/>
</packageinstances>
</package3d>
<package3d name="RESAD724W46L381D178B" urn="urn:adsk.eagle:package:16378561/7" type="model">
<description>Axial Resistor, 7.24 mm pitch, 3.81 mm body length, 1.78 mm body diameter
&lt;p&gt;Axial Resistor package with 7.24 mm pitch (lead spacing), 0.46 mm lead diameter, 3.81 mm body length and 1.78 mm body diameter&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="RESAD724W46L381D178B"/>
</packageinstances>
</package3d>
</packages3d>
<symbols>
<symbol name="R" urn="urn:adsk.eagle:symbol:16378529/8" library_version="26">
<description>IEC‑style: Resistor</description>
<wire x1="-2.54" y1="-0.889" x2="2.54" y2="-0.889" width="0.1524" layer="94"/>
<wire x1="2.54" y1="0.889" x2="-2.54" y2="0.889" width="0.1524" layer="94"/>
<wire x1="2.54" y1="-0.889" x2="2.54" y2="0.889" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-0.889" x2="-2.54" y2="0.889" width="0.1524" layer="94"/>
<pin name="1" x="-5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1"/>
<pin name="2" x="5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1" rot="R180"/>
<text x="0" y="-5.08" size="1.778" layer="95" align="top-center">&gt;SPICEMODEL</text>
<text x="0" y="-7.62" size="1.778" layer="95" align="top-center">&gt;SPICEEXTRA</text>
<text x="0" y="2.54" size="1.778" layer="95" align="bottom-center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.778" layer="96" align="top-center">&gt;VALUE</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="R" urn="urn:adsk.eagle:component:16378570/15" prefix="R" uservalue="yes" library_version="26">
<description>Resistor Fixed - Generic</description>
<gates>
<gate name="G$1" symbol="R" x="0" y="0"/>
</gates>
<devices>
<device name="CHIP-0402(1005-METRIC)" package="RESC1005X40">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378568/7"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Resistors" constant="no"/>
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Chip Resistor 1.05 X 0.54 X 0.40 mm body 0402(1005-METRIC) Package" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PACKAGE_SIZE" value="0402" constant="no"/>
<attribute name="PACKAGE_TYPE" value="Surface Mount" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUBCATEGORY" value="" constant="no"/>
<attribute name="TEMPERATURE_COEFFICIENT" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TOLERANCE" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="CHIP-0603(1608-METRIC)" package="RESC1608X60">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378565/7"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Resistors" constant="no"/>
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Chip Resistor 1.60 X 0.82 X 0.60 mm body 0603(1608-METRIC) Package" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PACKAGE_SIZE" value="0603" constant="no"/>
<attribute name="PACKAGE_TYPE" value="Surface Mount" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUBCATEGORY" value="" constant="no"/>
<attribute name="TEMPERATURE_COEFFICIENT" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TOLERANCE" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="CHIP-0805(2012-METRIC)" package="RESC2012X65">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378559/7"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Resistors" constant="no"/>
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Chip Resistor 2.00 X 1.25 X 0.65 mm body 0805(2012-METRIC) Package" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PACKAGE_SIZE" value="0805" constant="no"/>
<attribute name="PACKAGE_TYPE" value="Surface Mount" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUBCATEGORY" value="" constant="no"/>
<attribute name="TEMPERATURE_COEFFICIENT" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TOLERANCE" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="CHIP-1206(3216-METRIC)" package="RESC3216X70">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378566/7"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Resistors" constant="no"/>
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Chip Resistor 3.20 X 1.60 X 0.70 mm body 1206(3216-METRIC) Package" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PACKAGE_SIZE" value="1206" constant="no"/>
<attribute name="PACKAGE_TYPE" value="Surface Mount" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUBCATEGORY" value="" constant="no"/>
<attribute name="TEMPERATURE_COEFFICIENT" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TOLERANCE" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="CHIP-1210(3225-METRIC)" package="RESC3224X71">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378563/8"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Resistors" constant="no"/>
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Chip Resistor 3.20 X 2.49 X 0.71 mm body 1210(3225-METRIC) Package" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PACKAGE_SIZE" value="1210" constant="no"/>
<attribute name="PACKAGE_TYPE" value="Surface Mount" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUBCATEGORY" value="" constant="no"/>
<attribute name="TEMPERATURE_COEFFICIENT" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TOLERANCE" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="CHIP-2010(5025-METRIC)" package="RESC5025X71">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378564/7"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Resistors" constant="no"/>
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Chip Resistor 5.00 X 2.50 X 0.71 mm body 2010(5025-METRIC) Package" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PACKAGE_SIZE" value="2010" constant="no"/>
<attribute name="PACKAGE_TYPE" value="Surface Mount" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUBCATEGORY" value="" constant="no"/>
<attribute name="TEMPERATURE_COEFFICIENT" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TOLERANCE" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="CHIP-2512(6332-METRIC)" package="RESC6332X71">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378557/8"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Resistors" constant="no"/>
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Chip Resistor 6.30 X 3.20 X 0.71 mm body 2512(6332-METRIC) Package" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PACKAGE_SIZE" value="2512" constant="no"/>
<attribute name="PACKAGE_TYPE" value="Surface Mount" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUBCATEGORY" value="" constant="no"/>
<attribute name="TEMPERATURE_COEFFICIENT" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TOLERANCE" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="AXIAL-11.7MM-PITCH" package="RESAD1176W63L850D250B">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378560/7"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Resistors" constant="no"/>
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Axial Resistor 11.76 mm pitch 8.5 mm body length 2.5 mm body diameter" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PACKAGE_SIZE" value="Axial" constant="no"/>
<attribute name="PACKAGE_TYPE" value="Through Hole" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUBCATEGORY" value="" constant="no"/>
<attribute name="TEMPERATURE_COEFFICIENT" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TOLERANCE" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="MELF(3515-METRIC)" package="RESMELF3515">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378562/7"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Resistors" constant="no"/>
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="MELF Resistor 3.50 mm length Resistor 1.52 mm diameter 3515-METRIC Package" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PACKAGE_SIZE" value="MELF" constant="no"/>
<attribute name="PACKAGE_TYPE" value="Surface Mount" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUBCATEGORY" value="" constant="no"/>
<attribute name="TEMPERATURE_COEFFICIENT" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TOLERANCE" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="MELF(2014-METRIC)" package="RESMELF2014">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378558/7"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Resistors" constant="no"/>
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="MELF Resistor 2.00 mm length Resistor 1.40 mm diameter 2014-METRIC Package" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PACKAGE_SIZE" value="MELF" constant="no"/>
<attribute name="PACKAGE_TYPE" value="Surface Mount" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUBCATEGORY" value="" constant="no"/>
<attribute name="TEMPERATURE_COEFFICIENT" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TOLERANCE" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="MELF(5924-METRIC)" package="RESMELF5924">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378567/8"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Resistors" constant="no"/>
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="MELF Resistor 5.90 mm length Resistor 2.45 mm diameter 5924-METRIC Package" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PACKAGE_SIZE" value="MELF" constant="no"/>
<attribute name="PACKAGE_TYPE" value="Surface Mount" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUBCATEGORY" value="" constant="no"/>
<attribute name="TEMPERATURE_COEFFICIENT" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TOLERANCE" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="MELF(3218-METRIC)" package="RESMELF3218">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378556/7"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Resistors" constant="no"/>
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="MELF Resistor 3.20 mm length Resistor 1.80 mm diameter 3218-METRIC Package" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PACKAGE_SIZE" value="MELF" constant="no"/>
<attribute name="PACKAGE_TYPE" value="Surface Mount" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUBCATEGORY" value="" constant="no"/>
<attribute name="TEMPERATURE_COEFFICIENT" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TOLERANCE" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="AXIAL-7.2MM-PITCH" package="RESAD724W46L381D178B">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378561/7"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Resistors" constant="no"/>
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Axial Resistor 7.24 mm pitch 3.81 mm body length 1.78 mm body diameter" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PACKAGE_SIZE" value="Axial" constant="no"/>
<attribute name="PACKAGE_TYPE" value="Through Hole" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUBCATEGORY" value="" constant="no"/>
<attribute name="TEMPERATURE_COEFFICIENT" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TOLERANCE" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
</technology>
</technologies>
</device>
</devices>
<spice>
<pinmapping spiceprefix="R">
<pinmap gate="G$1" pin="1" pinorder="1"/>
<pinmap gate="G$1" pin="2" pinorder="2"/>
</pinmapping>
</spice>
</deviceset>
</devicesets>
</library>
<library name="belfuse" urn="urn:adsk.wipprod:fs.file:vf.KZ5jnwlsSbOFGirIR93spw">
<packages>
<package name="0ZCJ" library_version="6">
<smd name="1" x="-1.7272" y="0" dx="1.778" dy="3.5052" layer="1"/>
<smd name="2" x="1.6002" y="0" dx="1.778" dy="3.5052" layer="1"/>
<wire x1="-1.4033" y1="-1.8288" x2="1.4033" y2="-1.8288" width="0.1524" layer="21"/>
<wire x1="1.4033" y1="1.8288" x2="-1.4033" y2="1.8288" width="0.1524" layer="21"/>
<wire x1="-2.3622" y1="-1.7018" x2="2.3622" y2="-1.7018" width="0.1524" layer="51"/>
<wire x1="2.3622" y1="-1.7018" x2="2.3622" y2="1.7018" width="0.1524" layer="51"/>
<wire x1="2.3622" y1="1.7018" x2="-2.3622" y2="1.7018" width="0.1524" layer="51"/>
<wire x1="-2.3622" y1="1.7018" x2="-2.3622" y2="-1.7018" width="0.1524" layer="51"/>
<text x="-3.2712" y="-0.635" size="1.27" layer="27" ratio="6">&gt;Name</text>
<text x="-1.0938" y="-0.635" size="1.27" layer="27" ratio="6">&gt;Value</text>
</package>
<package name="0ZCG_BEL" library_version="6">
<smd name="1" x="-2.3622" y="0" dx="1.778" dy="3.5052" layer="1"/>
<smd name="2" x="2.3622" y="0" dx="1.778" dy="3.5052" layer="1"/>
<wire x1="-3.5052" y1="-2.0066" x2="-3.5052" y2="-4.6228" width="0.1524" layer="48"/>
<wire x1="3.5052" y1="-2.0066" x2="3.5052" y2="-4.6228" width="0.1524" layer="48"/>
<wire x1="-3.5052" y1="-4.2418" x2="3.5052" y2="-4.2418" width="0.1524" layer="48"/>
<wire x1="-3.5052" y1="-4.2418" x2="-3.2512" y2="-4.1148" width="0.1524" layer="48"/>
<wire x1="-3.5052" y1="-4.2418" x2="-3.2512" y2="-4.3688" width="0.1524" layer="48"/>
<wire x1="-3.2512" y1="-4.1148" x2="-3.2512" y2="-4.3688" width="0.1524" layer="48"/>
<wire x1="3.5052" y1="-4.2418" x2="3.2512" y2="-4.1148" width="0.1524" layer="48"/>
<wire x1="3.5052" y1="-4.2418" x2="3.2512" y2="-4.3688" width="0.1524" layer="48"/>
<wire x1="3.2512" y1="-4.1148" x2="3.2512" y2="-4.3688" width="0.1524" layer="48"/>
<wire x1="-1.7272" y1="2.0066" x2="-1.7272" y2="4.6228" width="0.1524" layer="48"/>
<wire x1="1.7272" y1="2.0066" x2="1.7272" y2="4.6228" width="0.1524" layer="48"/>
<wire x1="-1.7272" y1="4.2418" x2="-2.9972" y2="4.2418" width="0.1524" layer="48"/>
<wire x1="1.7272" y1="4.2418" x2="2.9972" y2="4.2418" width="0.1524" layer="48"/>
<wire x1="-1.7272" y1="4.2418" x2="-1.9812" y2="4.3688" width="0.1524" layer="48"/>
<wire x1="-1.7272" y1="4.2418" x2="-1.9812" y2="4.1148" width="0.1524" layer="48"/>
<wire x1="-1.9812" y1="4.3688" x2="-1.9812" y2="4.1148" width="0.1524" layer="48"/>
<wire x1="1.7272" y1="4.2418" x2="1.9812" y2="4.3688" width="0.1524" layer="48"/>
<wire x1="1.7272" y1="4.2418" x2="1.9812" y2="4.1148" width="0.1524" layer="48"/>
<wire x1="1.9812" y1="4.3688" x2="1.9812" y2="4.1148" width="0.1524" layer="48"/>
<wire x1="-2.3622" y1="2.0066" x2="-2.3622" y2="7.1628" width="0.1524" layer="48"/>
<wire x1="2.3622" y1="2.0066" x2="2.3622" y2="7.1628" width="0.1524" layer="48"/>
<wire x1="-2.3622" y1="6.7818" x2="2.3622" y2="6.7818" width="0.1524" layer="48"/>
<wire x1="-2.3622" y1="6.7818" x2="-2.1082" y2="6.9088" width="0.1524" layer="48"/>
<wire x1="-2.3622" y1="6.7818" x2="-2.1082" y2="6.6548" width="0.1524" layer="48"/>
<wire x1="-2.1082" y1="6.9088" x2="-2.1082" y2="6.6548" width="0.1524" layer="48"/>
<wire x1="2.3622" y1="6.7818" x2="2.1082" y2="6.9088" width="0.1524" layer="48"/>
<wire x1="2.3622" y1="6.7818" x2="2.1082" y2="6.6548" width="0.1524" layer="48"/>
<wire x1="2.1082" y1="6.9088" x2="2.1082" y2="6.6548" width="0.1524" layer="48"/>
<wire x1="2.6162" y1="1.7018" x2="-4.6736" y2="1.7018" width="0.1524" layer="48"/>
<wire x1="2.6162" y1="-1.7018" x2="-4.6736" y2="-1.7018" width="0.1524" layer="48"/>
<wire x1="-4.2926" y1="1.7018" x2="-4.2926" y2="2.9718" width="0.1524" layer="48"/>
<wire x1="-4.2926" y1="-1.7018" x2="-4.2926" y2="-2.9718" width="0.1524" layer="48"/>
<wire x1="-4.2926" y1="1.7018" x2="-4.4196" y2="1.9558" width="0.1524" layer="48"/>
<wire x1="-4.2926" y1="1.7018" x2="-4.1656" y2="1.9558" width="0.1524" layer="48"/>
<wire x1="-4.4196" y1="1.9558" x2="-4.1656" y2="1.9558" width="0.1524" layer="48"/>
<wire x1="-4.2926" y1="-1.7018" x2="-4.4196" y2="-1.9558" width="0.1524" layer="48"/>
<wire x1="-4.2926" y1="-1.7018" x2="-4.1656" y2="-1.9558" width="0.1524" layer="48"/>
<wire x1="-4.4196" y1="-1.9558" x2="-4.1656" y2="-1.9558" width="0.1524" layer="48"/>
<text x="-16.356" y="-7.0866" size="1.27" layer="48" ratio="6">Default Pad Style: RX70Y138D0T</text>
<text x="-18.6611" y="-9.6266" size="1.27" layer="48" ratio="6">Alternate 1 Pad Style: OX60Y90D30P</text>
<text x="-18.6611" y="-12.1666" size="1.27" layer="48" ratio="6">Alternate 2 Pad Style: OX90Y60D30P</text>
<text x="-3.7543" y="-5.3848" size="0.635" layer="48" ratio="4">0.276in/7.01mm</text>
<text x="-4.0424" y="4.7498" size="0.635" layer="48" ratio="4">0.136in/3.454mm</text>
<text x="-4.0424" y="7.2898" size="0.635" layer="48" ratio="4">0.186in/4.724mm</text>
<text x="-12.8854" y="-0.3175" size="0.635" layer="48" ratio="4">0.134in/3.404mm</text>
<wire x1="-1.4033" y1="-1.8288" x2="1.4033" y2="-1.8288" width="0.1524" layer="21"/>
<wire x1="1.4033" y1="1.8288" x2="-1.4033" y2="1.8288" width="0.1524" layer="21"/>
<wire x1="-2.3622" y1="-1.7018" x2="2.3622" y2="-1.7018" width="0.1524" layer="51"/>
<wire x1="2.3622" y1="-1.7018" x2="2.3622" y2="1.7018" width="0.1524" layer="51"/>
<wire x1="2.3622" y1="1.7018" x2="-2.3622" y2="1.7018" width="0.1524" layer="51"/>
<wire x1="-2.3622" y1="1.7018" x2="-2.3622" y2="-1.7018" width="0.1524" layer="51"/>
<polygon width="0.0254" layer="41" pour="solid">
<vertex x="-1.6764" y="-1.7018"/>
<vertex x="1.6764" y="-1.7018"/>
<vertex x="1.6764" y="1.7018"/>
<vertex x="-1.6764" y="1.7018"/>
</polygon>
<text x="-3.2712" y="-0.635" size="1.27" layer="27" ratio="6">&gt;Name</text>
<text x="-1.7288" y="-0.635" size="1.27" layer="27" ratio="6">&gt;Value</text>
</package>
</packages>
<symbols>
<symbol name="FUSE" library_version="1">
<pin name="1" x="0" y="0" visible="off" length="short" direction="pas"/>
<pin name="2" x="10.16" y="0" visible="off" length="short" direction="pas" rot="R180"/>
<wire x1="2.54" y1="0" x2="5.08" y2="0" width="0.1524" layer="94" curve="-180"/>
<wire x1="7.62" y1="0" x2="5.08" y2="0" width="0.1524" layer="94" curve="-180"/>
<text x="-3.8831" y="-4.9149" size="3.48" layer="96" ratio="10">&gt;Value</text>
<text x="-2.8148" y="1.4351" size="3.48" layer="95" ratio="10">&gt;Name</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="0ZCJ0010FF2E" prefix="F" library_version="6">
<gates>
<gate name="A" symbol="FUSE" x="0" y="0"/>
</gates>
<devices>
<device name="" package="0ZCJ">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="0ZCG0050AF2C" prefix="F" library_version="6">
<gates>
<gate name="A" symbol="FUSE" x="0" y="0"/>
</gates>
<devices>
<device name="0ZCG_BEL" package="0ZCG_BEL">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="COPYRIGHT" value="Copyright (C) 2025 Ultra Librarian. All rights reserved." constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Belfuse" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="0ZCG0050AF2C" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Wurth_Signal &amp; Communications_WE-D-SUB" urn="urn:adsk.eagle:library:14284102">
<description>&lt;BR&gt;Wurth Elektronik - Signal &amp; Communications - Filtered Connectors - WE-D-SUB&lt;br&gt;&lt;Hr&gt;

&lt;BR&gt;
&lt;TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0&gt;
&lt;TR&gt;   
&lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;&lt;BR&gt;&lt;br&gt;
      &amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;&lt;BR&gt;
       &lt;BR&gt;
       &lt;BR&gt;
       &lt;BR&gt;&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
&lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;&lt;br&gt;
      -----&lt;BR&gt;
      -----&lt;BR&gt;
      -----&lt;BR&gt;
      -----&lt;BR&gt;
      -----&lt;BR&gt;&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt; &lt;FONT FACE=ARIAL SIZE=3&gt;&lt;br&gt;
      ---------------------------&lt;BR&gt;
&lt;B&gt;&lt;I&gt;&lt;span style='font-size:26pt;
  color:#FF6600;'&gt;WE &lt;/span&gt;&lt;/i&gt;&lt;/b&gt;
&lt;BR&gt;
      ---------------------------&lt;BR&gt;&lt;b&gt;Würth Elektronik&lt;/b&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;&lt;br&gt;
      ---------O---&lt;BR&gt;
      ----O--------&lt;BR&gt;
      ---------O---&lt;BR&gt;
      ----O--------&lt;BR&gt;
      ---------O---&lt;BR&gt;&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
   
&lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;&lt;BR&gt;
      &amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;&lt;BR&gt;
       &lt;BR&gt;
       &lt;BR&gt;
       &lt;BR&gt;
       &lt;BR&gt;&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;

  &lt;TR&gt;
    &lt;TD COLSPAN=7&gt;&amp;nbsp;
    &lt;/TD&gt;
  &lt;/TR&gt;
  
&lt;/TABLE&gt;
&lt;B&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;More than you expect&lt;BR&gt;&lt;BR&gt;&lt;BR&gt;&lt;/B&gt;

&lt;HR&gt;&lt;BR&gt;
&lt;b&gt;Würth Elektronik eiSos GmbH &amp; Co. KG&lt;/b&gt;&lt;br&gt;
EMC &amp; Inductive Solutions&lt;br&gt;

Max-Eyth-Str.1&lt;br&gt;
D-74638 Waldenburg&lt;br&gt;
&lt;br&gt;
Tel: +49 (0)7942-945-0&lt;br&gt;
Fax:+49 (0)7942-945-5000&lt;br&gt;
&lt;br&gt;
&lt;a href="http://www.we-online.com/web/en/electronic_components/produkte_pb/bauteilebibliotheken/eagle_4.php"&gt;www.we-online.com/eagle&lt;/a&gt;&lt;br&gt;
&lt;a href="mailto:libraries@we-online.com"&gt;libraries@we-online.com&lt;/a&gt; &lt;BR&gt;&lt;BR&gt;
&lt;br&gt;&lt;HR&gt;&lt;BR&gt;
Neither Autodesk nor Würth Elektronik eiSos does warrant that this library is error-free or &lt;br&gt;
that it meets your specific requirements.&lt;br&gt;&lt;BR&gt;
Please contact us for more information.&lt;br&gt;
&lt;HR&gt;
&lt;br&gt;Eagle Version 9, Library Revision 2019a, 2019-09-26&lt;br&gt;
&lt;HR&gt;
Copyright: Würth Elektronik</description>
<packages>
<package name="WE-D-SUB_THT_UNC4/40_210111023" urn="urn:adsk.eagle:footprint:13184392/1" locally_modified="yes" library_version="1">
<description>&lt;b&gt;WE-D-SUB Filter Solder Pin Straight
&lt;br&gt;&lt;/b&gt;9 Poles , Male
&lt;BR&gt;UNC 4/40  means Size UNC 4/40</description>
<pad name="1" x="-5.49" y="1.42" drill="1"/>
<pad name="2" x="-2.74" y="1.42" drill="1"/>
<pad name="3" x="0" y="1.42" drill="1"/>
<pad name="4" x="2.74" y="1.42" drill="1"/>
<pad name="5" x="5.49" y="1.42" drill="1"/>
<pad name="6" x="-4.11" y="-1.42" drill="1"/>
<pad name="7" x="-1.37" y="-1.42" drill="1"/>
<pad name="8" x="1.37" y="-1.42" drill="1"/>
<pad name="9" x="4.11" y="-1.42" drill="1"/>
<pad name="Z1" x="-12.5" y="0" drill="3"/>
<pad name="Z2" x="12.5" y="0" drill="3"/>
<text x="-8" y="2" size="1.27" layer="51">1</text>
<text x="7" y="2" size="1.27" layer="51">5</text>
<text x="-7" y="-2" size="1.27" layer="51">6</text>
<text x="6" y="-2" size="1.27" layer="51">9</text>
<text x="-0.11" y="6.97" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="-3.71" y="-8.44" size="1.27" layer="27">&gt;VALUE</text>
<circle x="-7.1" y="1.4" radius="0.2" width="0.4" layer="21"/>
<wire x1="-15.4" y1="-6.2" x2="15.4" y2="-6.2" width="0.1" layer="51"/>
<wire x1="-15.4" y1="6.2" x2="-15.4" y2="-6.2" width="0.1" layer="51"/>
<wire x1="15.4" y1="6.2" x2="15.4" y2="-6.2" width="0.1" layer="51"/>
<wire x1="-15.4" y1="6.2" x2="15.4" y2="6.2" width="0.1" layer="51"/>
<wire x1="-15.5" y1="6.3" x2="15.5" y2="6.3" width="0.2" layer="21"/>
<wire x1="15.5" y1="6.3" x2="15.5" y2="-6.3" width="0.2" layer="21"/>
<wire x1="15.5" y1="-6.3" x2="-15.5" y2="-6.3" width="0.2" layer="21"/>
<wire x1="-15.5" y1="-6.3" x2="-15.5" y2="6.3" width="0.2" layer="21"/>
<polygon width="0.1" layer="39" pour="solid">
<vertex x="-15.7" y="-6.5"/>
<vertex x="15.67" y="-6.5"/>
<vertex x="15.7" y="6.5"/>
<vertex x="-15.7" y="6.5"/>
</polygon>
</package>
<package name="WE-D-SUB_THT_UNC4/40_214111023" urn="urn:adsk.eagle:footprint:13184399/1" locally_modified="yes" library_version="1">
<description>&lt;b&gt;WE-D-SUB Filter Solder Pin Straight
&lt;br&gt;&lt;/b&gt;25 Poles , Male
&lt;BR&gt;UNC 4/40  means Size UNC 4/40</description>
<pad name="3" x="-11.05" y="1.42" drill="1"/>
<pad name="1" x="-16.56" y="1.42" drill="1"/>
<pad name="2" x="-13.82" y="1.42" drill="1"/>
<pad name="4" x="-8.28" y="1.42" drill="1"/>
<pad name="5" x="-5.54" y="1.42" drill="1"/>
<pad name="6" x="-2.77" y="1.42" drill="1"/>
<pad name="7" x="0" y="1.42" drill="1"/>
<pad name="8" x="2.77" y="1.42" drill="1"/>
<pad name="9" x="5.54" y="1.42" drill="1"/>
<pad name="10" x="8.28" y="1.42" drill="1"/>
<pad name="11" x="11.05" y="1.42" drill="1"/>
<pad name="12" x="13.82" y="1.42" drill="1"/>
<pad name="13" x="16.56" y="1.42" drill="1"/>
<pad name="14" x="-15.19" y="-1.42" drill="1"/>
<pad name="15" x="-12.42" y="-1.42" drill="1"/>
<pad name="16" x="-9.68" y="-1.42" drill="1"/>
<pad name="17" x="-6.91" y="-1.42" drill="1"/>
<pad name="18" x="-4.14" y="-1.42" drill="1"/>
<pad name="19" x="-1.38" y="-1.42" drill="1"/>
<pad name="20" x="1.38" y="-1.42" drill="1"/>
<pad name="21" x="4.14" y="-1.42" drill="1"/>
<pad name="22" x="6.91" y="-1.42" drill="1"/>
<pad name="23" x="9.68" y="-1.42" drill="1"/>
<pad name="24" x="12.42" y="-1.42" drill="1"/>
<pad name="25" x="15.19" y="-1.42" drill="1"/>
<pad name="Z1" x="-23.5" y="0" drill="3"/>
<pad name="Z2" x="23.5" y="0" drill="3"/>
<text x="-19" y="1" size="1.27" layer="51">1</text>
<text x="-19" y="-2" size="1.27" layer="51">14</text>
<text x="17" y="-2" size="1.27" layer="51">25</text>
<text x="18" y="1" size="1.27" layer="51">13</text>
<text x="0" y="7" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="-3.81" y="-8.74" size="1.27" layer="27">&gt;VALUE</text>
<circle x="-18.2" y="3.3" radius="0.2" width="0.4" layer="21"/>
<wire x1="-26.55" y1="-6.2" x2="26.55" y2="-6.2" width="0.1" layer="51"/>
<wire x1="-26.55" y1="6.2" x2="26.55" y2="6.2" width="0.1" layer="51"/>
<wire x1="-26.55" y1="6.2" x2="-26.55" y2="-6.2" width="0.1" layer="51"/>
<wire x1="26.55" y1="6.2" x2="26.55" y2="-6.2" width="0.1" layer="51"/>
<wire x1="-26.65" y1="6.3" x2="26.65" y2="6.3" width="0.2" layer="21"/>
<wire x1="26.65" y1="6.3" x2="26.65" y2="-6.3" width="0.2" layer="21"/>
<wire x1="26.65" y1="-6.3" x2="-26.65" y2="-6.3" width="0.2" layer="21"/>
<wire x1="-26.65" y1="-6.3" x2="-26.65" y2="6.3" width="0.2" layer="21"/>
<polygon width="0.1" layer="39" pour="solid">
<vertex x="-26.85" y="-6.5"/>
<vertex x="26.85" y="-6.5"/>
<vertex x="26.85" y="6.5"/>
<vertex x="-26.85" y="6.5"/>
</polygon>
</package>
</packages>
<packages3d>
<package3d name="WE-D-SUB_THT_UNC4/40_210111023" urn="urn:adsk.eagle:package:13184429/2" type="model">
<description>&lt;b&gt;WE-D-SUB Filter Solder Pin Straight
&lt;br&gt;&lt;/b&gt;9 Poles , Male
&lt;BR&gt;UNC 4/40  means Size UNC 4/40</description>
<packageinstances>
<packageinstance name="WE-D-SUB_THT_UNC4/40_210111023"/>
</packageinstances>
</package3d>
<package3d name="WE-D-SUB_THT_UNC4/40_214111023" urn="urn:adsk.eagle:package:13184422/2" type="model">
<description>&lt;b&gt;WE-D-SUB Filter Solder Pin Straight
&lt;br&gt;&lt;/b&gt;25 Poles , Male
&lt;BR&gt;UNC 4/40  means Size UNC 4/40</description>
<packageinstances>
<packageinstance name="WE-D-SUB_THT_UNC4/40_214111023"/>
</packageinstances>
</package3d>
</packages3d>
<symbols>
<symbol name="THT_9PIN_MALE" urn="urn:adsk.eagle:symbol:14284108/1" library_version="1">
<pin name="1" x="-10.16" y="12.7" visible="pad" length="middle" direction="pas" rot="R270"/>
<pin name="2" x="-5.08" y="12.7" visible="pad" length="middle" direction="pas" rot="R270"/>
<pin name="3" x="0" y="12.7" visible="pad" length="middle" direction="pas" rot="R270"/>
<pin name="4" x="5.08" y="12.7" visible="pad" length="middle" direction="pas" rot="R270"/>
<pin name="5" x="10.16" y="12.7" visible="pad" length="middle" direction="pas" rot="R270"/>
<pin name="6" x="-7.62" y="-12.7" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="7" x="-2.54" y="-12.7" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="8" x="2.54" y="-12.7" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="9" x="7.62" y="-12.7" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="GND" x="22.86" y="0" visible="off" length="middle" direction="pwr" rot="R180"/>
<wire x1="-14.3" y1="6.35" x2="14.3" y2="6.35" width="0.4064" layer="94"/>
<wire x1="12.7" y1="-6.35" x2="-12.7" y2="-6.35" width="0.4064" layer="94"/>
<wire x1="12.7018" y1="-6.354" x2="14.0694" y2="-5.2354" width="0.4064" layer="94" curve="77.657889"/>
<wire x1="16.0758" y1="4.2196" x2="14.0694" y2="-5.2354" width="0.4064" layer="94"/>
<wire x1="16.0669" y1="4.1706" x2="14.1242" y2="6.348" width="0.4064" layer="94" curve="102.337599" cap="flat"/>
<wire x1="-12.7018" y1="-6.354" x2="-14.0694" y2="-5.2354" width="0.4064" layer="94" curve="-77.657889"/>
<wire x1="-16.0758" y1="4.2196" x2="-14.0694" y2="-5.2354" width="0.4064" layer="94"/>
<wire x1="-16.0669" y1="4.1706" x2="-14.1242" y2="6.348" width="0.4064" layer="94" curve="-102.337599" cap="flat"/>
<wire x1="10.16" y1="2.54" x2="10.16" y2="7.62" width="0.1524" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="7.62" width="0.1524" layer="94"/>
<wire x1="0" y1="2.54" x2="0" y2="7.62" width="0.1524" layer="94"/>
<wire x1="-5.08" y1="2.54" x2="-5.08" y2="7.62" width="0.1524" layer="94"/>
<wire x1="-10.16" y1="2.54" x2="-10.16" y2="7.62" width="0.1524" layer="94"/>
<wire x1="7.62" y1="-7.66" x2="7.62" y2="-2.04" width="0.1524" layer="94"/>
<wire x1="2.54" y1="-7.66" x2="2.54" y2="-2.04" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-7.66" x2="-2.54" y2="-2.04" width="0.1524" layer="94"/>
<wire x1="-7.62" y1="-7.66" x2="-7.62" y2="-2.04" width="0.1524" layer="94"/>
<wire x1="15.24" y1="0" x2="17.78" y2="0" width="0.254" layer="94"/>
<text x="-25.038" y="0.638" size="1.778" layer="95">&gt;NAME</text>
<text x="-25.392" y="-2.464" size="1.778" layer="96">&gt;VALUE</text>
<text x="17.78" y="0.9" size="1.27" layer="94">GND</text>
<circle x="10.16" y="2.54" radius="0.762" width="0.254" layer="94"/>
<circle x="5.08" y="2.54" radius="0.762" width="0.254" layer="94"/>
<circle x="0" y="2.54" radius="0.762" width="0.254" layer="94"/>
<circle x="-5.08" y="2.54" radius="0.762" width="0.254" layer="94"/>
<circle x="-10.16" y="2.54" radius="0.762" width="0.254" layer="94"/>
<circle x="7.62" y="-2.54" radius="0.762" width="0.254" layer="94"/>
<circle x="2.54" y="-2.54" radius="0.762" width="0.254" layer="94"/>
<circle x="-2.54" y="-2.54" radius="0.762" width="0.254" layer="94"/>
<circle x="-7.62" y="-2.54" radius="0.762" width="0.254" layer="94"/>
<circle x="10.16" y="2.54" radius="0.4318" width="0.9144" layer="94"/>
<circle x="5.08" y="2.54" radius="0.4318" width="0.9144" layer="94"/>
<circle x="0" y="2.54" radius="0.4318" width="0.9144" layer="94"/>
<circle x="-5.08" y="2.54" radius="0.4318" width="0.9144" layer="94"/>
<circle x="-10.16" y="2.54" radius="0.4318" width="0.9144" layer="94"/>
<circle x="-7.62" y="-2.54" radius="0.4318" width="0.9144" layer="94"/>
<circle x="-2.54" y="-2.54" radius="0.4318" width="0.9144" layer="94"/>
<circle x="2.54" y="-2.54" radius="0.4318" width="0.9144" layer="94"/>
<circle x="7.62" y="-2.54" radius="0.4318" width="0.9144" layer="94"/>
</symbol>
<symbol name="THT_25PIN_MALE" urn="urn:adsk.eagle:symbol:14284113/1" library_version="1">
<circle x="0" y="2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="-5.08" y="2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="-10.16" y="2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="-15.24" y="2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="-20.32" y="2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="-25.4" y="2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="-30.48" y="2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="-27.94" y="-2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="-22.86" y="-2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="-17.78" y="-2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="-12.7" y="-2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="-7.62" y="-2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="-2.54" y="-2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="2.54" y="-2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="7.62" y="-2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="5.08" y="2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="10.16" y="2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="15.24" y="2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="20.32" y="2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="25.4" y="2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="30.48" y="2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="27.94" y="-2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="22.86" y="-2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="17.78" y="-2.54" radius="0.4" width="0.9144" layer="94"/>
<circle x="12.7" y="-2.54" radius="0.4" width="0.9144" layer="94"/>
<pin name="1" x="-30.48" y="10.16" visible="pad" length="middle" direction="pas" rot="R270"/>
<pin name="2" x="-25.4" y="10.16" visible="pad" length="middle" direction="pas" rot="R270"/>
<pin name="3" x="-20.32" y="10.16" visible="pad" length="middle" direction="pas" rot="R270"/>
<pin name="4" x="-15.24" y="10.16" visible="pad" length="middle" direction="pas" rot="R270"/>
<pin name="5" x="-10.16" y="10.16" visible="pad" length="middle" direction="pas" rot="R270"/>
<pin name="6" x="-5.08" y="10.16" visible="pad" length="middle" direction="pas" rot="R270"/>
<pin name="7" x="0" y="10.16" visible="pad" length="middle" direction="pas" rot="R270"/>
<pin name="8" x="5.08" y="10.16" visible="pad" length="middle" direction="pas" rot="R270"/>
<pin name="9" x="10.16" y="10.16" visible="pad" length="middle" direction="pas" rot="R270"/>
<pin name="10" x="15.24" y="10.16" visible="pad" length="middle" direction="pas" rot="R270"/>
<pin name="11" x="20.32" y="10.16" visible="pad" length="middle" direction="pas" rot="R270"/>
<pin name="12" x="25.4" y="10.16" visible="pad" length="middle" direction="pas" rot="R270"/>
<pin name="13" x="30.48" y="10.16" visible="pad" length="middle" direction="pas" rot="R270"/>
<pin name="14" x="-27.94" y="-10.16" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="15" x="-22.86" y="-10.16" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="16" x="-17.78" y="-10.16" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="17" x="-12.7" y="-10.16" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="18" x="-7.62" y="-10.16" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="19" x="-2.54" y="-10.16" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="20" x="2.54" y="-10.16" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="21" x="7.62" y="-10.16" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="22" x="12.7" y="-10.16" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="23" x="17.78" y="-10.16" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="24" x="22.86" y="-10.16" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="25" x="27.94" y="-10.16" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="GND" x="40.64" y="0" visible="off" length="short" direction="pwr" rot="R180"/>
<text x="-1.57" y="14.52" size="1.27" layer="95">&gt;NAME</text>
<text x="-3.55" y="-16.18" size="1.27" layer="96">&gt;VALUE</text>
<text x="35.56" y="0.74" size="1.27" layer="94">GND</text>
<wire x1="-31.43" y1="6.35" x2="31.16" y2="6.35" width="0.254" layer="94"/>
<wire x1="30.2" y1="-5.81" x2="-30.1" y2="-5.8" width="0.254" layer="94"/>
<wire x1="-30.1" y1="-5.8" x2="-30.32" y2="-5.79" width="0.254" layer="94"/>
<wire x1="32.004" y1="0" x2="38.1" y2="0" width="0.254" layer="94"/>
<wire x1="-32.78" y1="4.76" x2="-31.18" y2="-4.94" width="0.254" layer="94"/>
<wire x1="32.77" y1="4.84" x2="31.18" y2="-5.05" width="0.254" layer="94"/>
<wire x1="-31.18" y1="6.37" x2="-32.77" y2="4.78" width="0.254" layer="94" curve="90"/>
<wire x1="-32.77" y1="4.78" x2="-32.77" y2="4.73" width="0.254" layer="94"/>
<wire x1="-31.2" y1="-4.7" x2="-30.1" y2="-5.8" width="0.254" layer="94" curve="90"/>
<wire x1="32.75" y1="4.76" x2="31.16" y2="6.35" width="0.254" layer="94" curve="90"/>
<wire x1="30.12" y1="-5.81" x2="31.22" y2="-4.71" width="0.254" layer="94" curve="90"/>
<wire x1="-30.48" y1="2.54" x2="-30.48" y2="5.08" width="0.1524" layer="94"/>
<wire x1="-25.4" y1="2.54" x2="-25.4" y2="5.08" width="0.1524" layer="94"/>
<wire x1="-20.32" y1="2.54" x2="-20.32" y2="5.08" width="0.1524" layer="94"/>
<wire x1="-15.24" y1="2.54" x2="-15.24" y2="5.08" width="0.1524" layer="94"/>
<wire x1="-10.16" y1="2.54" x2="-10.16" y2="5.08" width="0.1524" layer="94"/>
<wire x1="-5.08" y1="2.54" x2="-5.08" y2="5.08" width="0.1524" layer="94"/>
<wire x1="0" y1="2.54" x2="0" y2="5.08" width="0.1524" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="5.08" width="0.1524" layer="94"/>
<wire x1="10.16" y1="2.54" x2="10.16" y2="5.08" width="0.1524" layer="94"/>
<wire x1="15.24" y1="2.54" x2="15.24" y2="5.08" width="0.1524" layer="94"/>
<wire x1="20.32" y1="2.54" x2="20.32" y2="5.08" width="0.1524" layer="94"/>
<wire x1="17.78" y1="-5.08" x2="17.78" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="22.86" y1="-5.08" x2="22.86" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="27.94" y1="-5.08" x2="27.94" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="2.54" y1="-5.08" x2="2.54" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="7.62" y1="-5.08" x2="7.62" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="12.7" y1="-5.08" x2="12.7" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="-12.7" y1="-5.08" x2="-12.7" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="-7.62" y1="-5.08" x2="-7.62" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-5.08" x2="-2.54" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="-27.94" y1="-5.08" x2="-27.94" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="-22.86" y1="-5.08" x2="-22.86" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="-17.78" y1="-5.08" x2="-17.78" y2="-2.54" width="0.1524" layer="94"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="WE-D-SUB_THT_UNC4/40_210111023" urn="urn:adsk.eagle:component:14284190/1" prefix="J" uservalue="yes" library_version="1">
<description>&lt;b&gt; WE-D-SUB Filter Solder Pin Straight
&lt;br&gt;
&lt;br&gt;&lt;b&gt; Characteristics 
&lt;br&gt;
&lt;br&gt;&lt;/b&gt;&lt;/b&gt;Standard type filtered with 1000 pF
&lt;br&gt;High attenuation: max. ≥ 40 dB @ 180 MHz
&lt;br&gt;Choice of UNC 4/40 or through hole
&lt;br&gt;Rated voltage: 100 VDC
&lt;br&gt;Rated current @ 20 ºC: 5 A
&lt;br&gt;Withstand voltage: 250 VRMS
&lt;br&gt;Insulation resistance: min. 1000 MΩ
&lt;br&gt;Operating temperature: –55 ºC to +125 ºC

&lt;br&gt;
&lt;br&gt;&lt;b&gt; Applications
&lt;br&gt;
&lt;br&gt;&lt;/b&gt; Filtering of interfaces 
&lt;br&gt;
&lt;br&gt; External connection to 
&lt;br&gt;  -printer
&lt;br&gt;  -sensor
&lt;br&gt;  -display
&lt;br&gt;
&lt;br&gt;
&lt;b&gt;Device and Package Name Note:
&lt;br&gt;
&lt;br&gt;&lt;/b&gt;UNC 4/40  means Size UNC 4/40 
&lt;br&gt;&lt;br&gt;&lt;br&gt;
&lt;br&gt;&lt;a href="https://katalog.we-online.de/media/images/v2/o14707v209%20Family_D-SUB-Filter_mit_geradem_Loetstift.jpg"&gt;
&lt;img src="https://katalog.we-online.de/media/images/v2/o14707v209%20Family_D-SUB-Filter_mit_geradem_Loetstift.jpg" width="320"&gt;&lt;/a&gt;&lt;p&gt;
Details see: &lt;a href="https://katalog.we-online.de/en/pbs/D-SUB-FILTER-STRAIGHT"&gt;https://katalog.we-online.de/en/pbs/D-SUB-FILTER-STRAIGHT&lt;/a&gt;&lt;p&gt;

&lt;/b&gt;Updated by Ella Wu  2019-09-10&lt;br&gt;
&lt;/b&gt;2019(C) Wurth Elektronik</description>
<gates>
<gate name="G$1" symbol="THT_9PIN_MALE" x="0" y="0"/>
</gates>
<devices>
<device name="" package="WE-D-SUB_THT_UNC4/40_210111023">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
<connect gate="G$1" pin="7" pad="7"/>
<connect gate="G$1" pin="8" pad="8"/>
<connect gate="G$1" pin="9" pad="9"/>
<connect gate="G$1" pin="GND" pad="Z1 Z2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:13184429/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="DATASHEET-URL" value="https://katalog.we-online.de/pbs/datasheet/210111023.pdf" constant="no"/>
<attribute name="MOUNT" value="THT" constant="no"/>
<attribute name="PART-NUMBER" value=" 210111023 " constant="no"/>
<attribute name="POLES" value=" 9 " constant="no"/>
<attribute name="TYPE" value="Male" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="WE-D-SUB_THT_UNC4/40_214111023" urn="urn:adsk.eagle:component:14284153/1" prefix="J" uservalue="yes" library_version="1">
<description>&lt;b&gt; WE-D-SUB Filter Solder Pin Straight
&lt;br&gt;
&lt;br&gt;&lt;b&gt; Characteristics 
&lt;br&gt;
&lt;br&gt;&lt;/b&gt;&lt;/b&gt;Standard type filtered with 1000 pF
&lt;br&gt;High attenuation: max. ≥ 40 dB @ 180 MHz
&lt;br&gt;Choice of UNC 4/40 or through hole
&lt;br&gt;Rated voltage: 100 VDC
&lt;br&gt;Rated current @ 20 ºC: 5 A
&lt;br&gt;Withstand voltage: 250 VRMS
&lt;br&gt;Insulation resistance: min. 1000 MΩ
&lt;br&gt;Operating temperature: –55 ºC to +125 ºC

&lt;br&gt;
&lt;br&gt;&lt;b&gt; Applications
&lt;br&gt;
&lt;br&gt;&lt;/b&gt; Filtering of interfaces 
&lt;br&gt;
&lt;br&gt; External connection to 
&lt;br&gt;  -printer
&lt;br&gt;  -sensor
&lt;br&gt;  -display
&lt;br&gt;
&lt;br&gt;
&lt;b&gt;Device and Package Name Note:
&lt;br&gt;
&lt;br&gt;&lt;/b&gt;UNC 4/40  means Size UNC 4/40 
&lt;br&gt;&lt;br&gt;&lt;br&gt;
&lt;br&gt;&lt;a href="https://katalog.we-online.de/media/images/v2/o14707v209%20Family_D-SUB-Filter_mit_geradem_Loetstift.jpg"&gt;
&lt;img src="https://katalog.we-online.de/media/images/v2/o14707v209%20Family_D-SUB-Filter_mit_geradem_Loetstift.jpg" width="320"&gt;&lt;/a&gt;&lt;p&gt;
Details see: &lt;a href="https://katalog.we-online.de/en/pbs/D-SUB-FILTER-STRAIGHT"&gt;https://katalog.we-online.de/en/pbs/D-SUB-FILTER-STRAIGHT&lt;/a&gt;&lt;p&gt;

&lt;/b&gt;Updated by Ella Wu  2019-09-10&lt;br&gt;
&lt;/b&gt;2019(C) Wurth Elektronik</description>
<gates>
<gate name="G$1" symbol="THT_25PIN_MALE" x="0" y="0"/>
</gates>
<devices>
<device name="" package="WE-D-SUB_THT_UNC4/40_214111023">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="10" pad="10"/>
<connect gate="G$1" pin="11" pad="11"/>
<connect gate="G$1" pin="12" pad="12"/>
<connect gate="G$1" pin="13" pad="13"/>
<connect gate="G$1" pin="14" pad="14"/>
<connect gate="G$1" pin="15" pad="15"/>
<connect gate="G$1" pin="16" pad="16"/>
<connect gate="G$1" pin="17" pad="17"/>
<connect gate="G$1" pin="18" pad="18"/>
<connect gate="G$1" pin="19" pad="19"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="20" pad="20"/>
<connect gate="G$1" pin="21" pad="21"/>
<connect gate="G$1" pin="22" pad="22"/>
<connect gate="G$1" pin="23" pad="23"/>
<connect gate="G$1" pin="24" pad="24"/>
<connect gate="G$1" pin="25" pad="25"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
<connect gate="G$1" pin="7" pad="7"/>
<connect gate="G$1" pin="8" pad="8"/>
<connect gate="G$1" pin="9" pad="9"/>
<connect gate="G$1" pin="GND" pad="Z1 Z2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:13184422/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="DATASHEET-URL" value="https://katalog.we-online.de/pbs/datasheet/214111023.pdf" constant="no"/>
<attribute name="MOUNT" value="THT" constant="no"/>
<attribute name="PART-NUMBER" value=" 214111023 " constant="no"/>
<attribute name="POLES" value=" 25 " constant="no"/>
<attribute name="TYPE" value="Male" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="OPA2192ID" urn="urn:adsk.wipprod:fs.file:vf.TJj7-PTeQnuMcJFsNH9qDw">
<packages>
<package name="SOIC127P599X175-8N" library_version="3">
<circle x="-4.04" y="2.305" radius="0.1" width="0.2" layer="21"/>
<circle x="-4.04" y="2.305" radius="0.1" width="0.2" layer="51"/>
<wire x1="-1.95" y1="2.4525" x2="1.95" y2="2.4525" width="0.127" layer="51"/>
<wire x1="-1.95" y1="-2.4525" x2="1.95" y2="-2.4525" width="0.127" layer="51"/>
<wire x1="-1.95" y1="2.525" x2="1.95" y2="2.525" width="0.127" layer="21"/>
<wire x1="-1.95" y1="-2.525" x2="1.95" y2="-2.525" width="0.127" layer="21"/>
<wire x1="-1.95" y1="2.4525" x2="-1.95" y2="-2.4525" width="0.127" layer="51"/>
<wire x1="1.95" y1="2.4525" x2="1.95" y2="-2.4525" width="0.127" layer="51"/>
<wire x1="-3.705" y1="2.7025" x2="3.705" y2="2.7025" width="0.05" layer="39"/>
<wire x1="-3.705" y1="-2.7025" x2="3.705" y2="-2.7025" width="0.05" layer="39"/>
<wire x1="-3.705" y1="2.7025" x2="-3.705" y2="-2.7025" width="0.05" layer="39"/>
<wire x1="3.705" y1="2.7025" x2="3.705" y2="-2.7025" width="0.05" layer="39"/>
<text x="-3.56" y="-2.902" size="1.27" layer="27" align="top-left">&gt;VALUE</text>
<text x="-3.56" y="2.902" size="1.27" layer="25">&gt;NAME</text>
<smd name="1" x="-2.47" y="1.905" dx="1.97" dy="0.6" layer="1" roundness="25"/>
<smd name="2" x="-2.47" y="0.635" dx="1.97" dy="0.6" layer="1" roundness="25"/>
<smd name="3" x="-2.47" y="-0.635" dx="1.97" dy="0.6" layer="1" roundness="25"/>
<smd name="4" x="-2.47" y="-1.905" dx="1.97" dy="0.6" layer="1" roundness="25"/>
<smd name="5" x="2.47" y="-1.905" dx="1.97" dy="0.6" layer="1" roundness="25"/>
<smd name="6" x="2.47" y="-0.635" dx="1.97" dy="0.6" layer="1" roundness="25"/>
<smd name="7" x="2.47" y="0.635" dx="1.97" dy="0.6" layer="1" roundness="25"/>
<smd name="8" x="2.47" y="1.905" dx="1.97" dy="0.6" layer="1" roundness="25"/>
</package>
</packages>
<symbols>
<symbol name="OPA2192ID" library_version="3">
<wire x1="-12.7" y1="12.7" x2="12.7" y2="12.7" width="0.41" layer="94"/>
<wire x1="12.7" y1="12.7" x2="12.7" y2="5.08" width="0.41" layer="94"/>
<wire x1="12.7" y1="5.08" x2="12.7" y2="-5.08075" width="0.41" layer="94"/>
<wire x1="12.7" y1="-5.08075" x2="12.7" y2="-7.62" width="0.41" layer="94"/>
<wire x1="12.7" y1="-7.62" x2="12.7" y2="-12.7" width="0.41" layer="94"/>
<wire x1="12.7" y1="-12.7" x2="-12.7" y2="-12.7" width="0.41" layer="94"/>
<wire x1="-12.7" y1="-12.7" x2="-12.7" y2="-2.54" width="0.41" layer="94"/>
<text x="-12.7" y="13.7" size="2.0828" layer="95" ratio="10" rot="SR0">&gt;NAME</text>
<text x="-12.7" y="-16.7" size="2.0828" layer="96" ratio="10" rot="SR0">&gt;VALUE</text>
<pin name="+INA" x="-17.78" y="-2.54" length="middle" direction="in"/>
<pin name="+INB" x="17.78" y="-7.62" length="middle" direction="in" rot="R180"/>
<pin name="-INA" x="-17.78" y="0" length="middle" direction="in"/>
<pin name="-INB" x="17.78" y="-5.08" length="middle" direction="in" rot="R180"/>
<pin name="V+" x="17.78" y="10.16" length="middle" direction="pwr" rot="R180"/>
<pin name="OUTA" x="-17.78" y="10.16" length="middle" direction="out"/>
<pin name="OUTB" x="17.78" y="5.08" length="middle" direction="out" rot="R180"/>
<pin name="V-" x="-17.78" y="-7.62" length="middle" direction="pwr"/>
<wire x1="-12.7" y1="-2.54" x2="-12.7" y2="0" width="0.41" layer="94"/>
<wire x1="-12.7" y1="0" x2="-12.7" y2="10.16" width="0.41" layer="94"/>
<wire x1="-12.7" y1="10.16" x2="-12.7" y2="12.7" width="0.41" layer="94"/>
<wire x1="-5.08" y1="8.382" x2="-9.01906875" y2="2.540715625" width="0.254" layer="94"/>
<wire x1="-9.01906875" y1="2.540715625" x2="-6.112925" y2="2.540715625" width="0.254" layer="94"/>
<wire x1="-6.112925" y1="2.540715625" x2="-3.590925" y2="2.540715625" width="0.254" layer="94"/>
<wire x1="-3.590925" y1="2.540715625" x2="-1.068925" y2="2.540715625" width="0.254" layer="94"/>
<wire x1="-1.068925" y1="2.540715625" x2="-5.08" y2="8.382" width="0.254" layer="94"/>
<wire x1="-4.241003125" y1="3.84376875" x2="-3.10526875" y2="3.84376875" width="0.254" layer="94"/>
<wire x1="-3.6731375" y1="4.578825" x2="-3.6731375" y2="3.20895" width="0.254" layer="94"/>
<wire x1="-5.08" y1="8.382" x2="-5.08" y2="10.16" width="0.127" layer="94"/>
<wire x1="-5.08" y1="10.16" x2="-12.7" y2="10.16" width="0.127" layer="94"/>
<wire x1="-5.44484375" y1="3.942571875" x2="-6.7476" y2="3.942571875" width="0.254" layer="94"/>
<wire x1="-6.112925" y1="2.540715625" x2="-6.112925" y2="0" width="0.127" layer="94"/>
<wire x1="-6.112925" y1="0" x2="-12.7" y2="0" width="0.127" layer="94"/>
<wire x1="-3.590925" y1="2.540715625" x2="-3.590925" y2="-2.54" width="0.127" layer="94"/>
<wire x1="-3.590925" y1="-2.54" x2="-12.7" y2="-2.54" width="0.127" layer="94"/>
<wire x1="7.62" y1="3.302" x2="3.68093125" y2="-2.539284375" width="0.254" layer="94"/>
<wire x1="3.68093125" y1="-2.539284375" x2="6.445390625" y2="-2.539284375" width="0.254" layer="94"/>
<wire x1="6.445390625" y1="-2.539284375" x2="9.03823125" y2="-2.539284375" width="0.254" layer="94"/>
<wire x1="9.03823125" y1="-2.539284375" x2="11.631075" y2="-2.539284375" width="0.254" layer="94"/>
<wire x1="11.631075" y1="-2.539284375" x2="7.62" y2="3.302" width="0.254" layer="94"/>
<wire x1="8.458996875" y1="-1.23623125" x2="9.59473125" y2="-1.23623125" width="0.254" layer="94"/>
<wire x1="6.4868625" y1="-0.501175" x2="6.4868625" y2="-1.87105" width="0.254" layer="94"/>
<wire x1="7.25515625" y1="-1.137428125" x2="5.9524" y2="-1.137428125" width="0.254" layer="94"/>
<wire x1="6.445390625" y1="-2.539284375" x2="6.445390625" y2="-7.62" width="0.127" layer="94"/>
<wire x1="6.445390625" y1="-7.62" x2="12.7" y2="-7.62" width="0.127" layer="94"/>
<wire x1="9.03823125" y1="-2.539284375" x2="9.03823125" y2="-5.08075" width="0.127" layer="94"/>
<wire x1="9.03823125" y1="-5.08075" x2="12.7" y2="-5.08075" width="0.127" layer="94"/>
<wire x1="7.62" y1="3.302" x2="7.62" y2="5.08" width="0.127" layer="94"/>
<wire x1="7.62" y1="5.08" x2="12.7" y2="5.08" width="0.127" layer="94"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="OPA2192ID" prefix="U" library_version="3">
<gates>
<gate name="G$1" symbol="OPA2192ID" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SOIC127P599X175-8N">
<connects>
<connect gate="G$1" pin="+INA" pad="3"/>
<connect gate="G$1" pin="+INB" pad="5"/>
<connect gate="G$1" pin="-INA" pad="2"/>
<connect gate="G$1" pin="-INB" pad="6"/>
<connect gate="G$1" pin="OUTA" pad="1"/>
<connect gate="G$1" pin="OUTB" pad="7"/>
<connect gate="G$1" pin="V+" pad="8"/>
<connect gate="G$1" pin="V-" pad="4"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="rcl" urn="urn:adsk.eagle:library:334">
<description>&lt;b&gt;Resistors, Capacitors, Inductors&lt;/b&gt;&lt;p&gt;
Based on the previous libraries:
&lt;ul&gt;
&lt;li&gt;r.lbr
&lt;li&gt;cap.lbr 
&lt;li&gt;cap-fe.lbr
&lt;li&gt;captant.lbr
&lt;li&gt;polcap.lbr
&lt;li&gt;ipc-smd.lbr
&lt;/ul&gt;
All SMD packages are defined according to the IPC specifications and  CECC&lt;p&gt;
&lt;author&gt;Created by librarian@cadsoft.de&lt;/author&gt;&lt;p&gt;
&lt;p&gt;
for Electrolyt Capacitors see also :&lt;p&gt;
www.bccomponents.com &lt;p&gt;
www.panasonic.com&lt;p&gt;
www.kemet.com&lt;p&gt;
http://www.secc.co.jp/pdf/os_e/2004/e_os_all.pdf &lt;b&gt;(SANYO)&lt;/b&gt;
&lt;p&gt;
for trimmer refence see : &lt;u&gt;www.electrospec-inc.com/cross_references/trimpotcrossref.asp&lt;/u&gt;&lt;p&gt;

&lt;table border=0 cellspacing=0 cellpadding=0 width="100%" cellpaddding=0&gt;
&lt;tr valign="top"&gt;

&lt;! &lt;td width="10"&gt;&amp;nbsp;&lt;/td&gt;
&lt;td width="90%"&gt;

&lt;b&gt;&lt;font color="#0000FF" size="4"&gt;TRIM-POT CROSS REFERENCE&lt;/font&gt;&lt;/b&gt;
&lt;P&gt;
&lt;TABLE BORDER=0 CELLSPACING=1 CELLPADDING=2&gt;
  &lt;TR&gt;
    &lt;TD COLSPAN=8&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;RECTANGULAR MULTI-TURN&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;B&gt;
      &lt;FONT SIZE=3 FACE=ARIAL color="#FF0000"&gt;BOURNS&lt;/FONT&gt;
      &lt;/B&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;B&gt;
      &lt;FONT SIZE=3 FACE=ARIAL color="#FF0000"&gt;BI&amp;nbsp;TECH&lt;/FONT&gt;
      &lt;/B&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;B&gt;
      &lt;FONT SIZE=3 FACE=ARIAL color="#FF0000"&gt;DALE-VISHAY&lt;/FONT&gt;
      &lt;/B&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;B&gt;
      &lt;FONT SIZE=3 FACE=ARIAL color="#FF0000"&gt;PHILIPS/MEPCO&lt;/FONT&gt;
      &lt;/B&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;B&gt;
      &lt;FONT SIZE=3 FACE=ARIAL color="#FF0000"&gt;MURATA&lt;/FONT&gt;
      &lt;/B&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;B&gt;
      &lt;FONT SIZE=3 FACE=ARIAL color="#FF0000"&gt;PANASONIC&lt;/FONT&gt;
      &lt;/B&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;B&gt;
      &lt;FONT SIZE=3 FACE=ARIAL color="#FF0000"&gt;SPECTROL&lt;/FONT&gt;
      &lt;/B&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;B&gt;
      &lt;FONT SIZE=3 FACE=ARIAL color="#FF0000"&gt;MILSPEC&lt;/FONT&gt;
      &lt;/B&gt;
    &lt;/TD&gt;&lt;TD&gt;&amp;nbsp;&lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3 &gt;
      3005P&lt;BR&gt;
      3006P&lt;BR&gt;
      3006W&lt;BR&gt;
      3006Y&lt;BR&gt;
      3009P&lt;BR&gt;
      3009W&lt;BR&gt;
      3009Y&lt;BR&gt;
      3057J&lt;BR&gt;
      3057L&lt;BR&gt;
      3057P&lt;BR&gt;
      3057Y&lt;BR&gt;
      3059J&lt;BR&gt;
      3059L&lt;BR&gt;
      3059P&lt;BR&gt;
      3059Y&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      89P&lt;BR&gt;
      89W&lt;BR&gt;
      89X&lt;BR&gt;
      89PH&lt;BR&gt;
      76P&lt;BR&gt;
      89XH&lt;BR&gt;
      78SLT&lt;BR&gt;
      78L&amp;nbsp;ALT&lt;BR&gt;
      56P&amp;nbsp;ALT&lt;BR&gt;
      78P&amp;nbsp;ALT&lt;BR&gt;
      T8S&lt;BR&gt;
      78L&lt;BR&gt;
      56P&lt;BR&gt;
      78P&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      T18/784&lt;BR&gt;
      783&lt;BR&gt;
      781&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      2199&lt;BR&gt;
      1697/1897&lt;BR&gt;
      1680/1880&lt;BR&gt;
      2187&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      8035EKP/CT20/RJ-20P&lt;BR&gt;
      -&lt;BR&gt;
      RJ-20X&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      1211L&lt;BR&gt;
      8012EKQ&amp;nbsp;ALT&lt;BR&gt;
      8012EKR&amp;nbsp;ALT&lt;BR&gt;
      1211P&lt;BR&gt;
      8012EKJ&lt;BR&gt;
      8012EKL&lt;BR&gt;
      8012EKQ&lt;BR&gt;
      8012EKR&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      2101P&lt;BR&gt;
      2101W&lt;BR&gt;
      2101Y&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      2102L&lt;BR&gt;
      2102S&lt;BR&gt;
      2102Y&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      EVMCOG&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      43P&lt;BR&gt;
      43W&lt;BR&gt;
      43Y&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      40L&lt;BR&gt;
      40P&lt;BR&gt;
      40Y&lt;BR&gt;
      70Y-T602&lt;BR&gt;
      70L&lt;BR&gt;
      70P&lt;BR&gt;
      70Y&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      RT/RTR12&lt;BR&gt;
      RT/RTR12&lt;BR&gt;
      RT/RTR12&lt;BR&gt;
      -&lt;BR&gt;
      RJ/RJR12&lt;BR&gt;
      RJ/RJR12&lt;BR&gt;
      RJ/RJR12&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD COLSPAN=8&gt;&amp;nbsp;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD COLSPAN=8&gt;
      &lt;FONT SIZE=4 FACE=ARIAL&gt;&lt;B&gt;SQUARE MULTI-TURN&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
   &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;BOURN&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;BI&amp;nbsp;TECH&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;DALE-VISHAY&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;PHILIPS/MEPCO&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;MURATA&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;PANASONIC&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;SPECTROL&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;MILSPEC&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      3250L&lt;BR&gt;
      3250P&lt;BR&gt;
      3250W&lt;BR&gt;
      3250X&lt;BR&gt;
      3252P&lt;BR&gt;
      3252W&lt;BR&gt;
      3252X&lt;BR&gt;
      3260P&lt;BR&gt;
      3260W&lt;BR&gt;
      3260X&lt;BR&gt;
      3262P&lt;BR&gt;
      3262W&lt;BR&gt;
      3262X&lt;BR&gt;
      3266P&lt;BR&gt;
      3266W&lt;BR&gt;
      3266X&lt;BR&gt;
      3290H&lt;BR&gt;
      3290P&lt;BR&gt;
      3290W&lt;BR&gt;
      3292P&lt;BR&gt;
      3292W&lt;BR&gt;
      3292X&lt;BR&gt;
      3296P&lt;BR&gt;
      3296W&lt;BR&gt;
      3296X&lt;BR&gt;
      3296Y&lt;BR&gt;
      3296Z&lt;BR&gt;
      3299P&lt;BR&gt;
      3299W&lt;BR&gt;
      3299X&lt;BR&gt;
      3299Y&lt;BR&gt;
      3299Z&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      66P&amp;nbsp;ALT&lt;BR&gt;
      66W&amp;nbsp;ALT&lt;BR&gt;
      66X&amp;nbsp;ALT&lt;BR&gt;
      66P&amp;nbsp;ALT&lt;BR&gt;
      66W&amp;nbsp;ALT&lt;BR&gt;
      66X&amp;nbsp;ALT&lt;BR&gt;
      -&lt;BR&gt;
      64W&amp;nbsp;ALT&lt;BR&gt;
      -&lt;BR&gt;
      64P&amp;nbsp;ALT&lt;BR&gt;
      64W&amp;nbsp;ALT&lt;BR&gt;
      64X&amp;nbsp;ALT&lt;BR&gt;
      64P&lt;BR&gt;
      64W&lt;BR&gt;
      64X&lt;BR&gt;
      66X&amp;nbsp;ALT&lt;BR&gt;
      66P&amp;nbsp;ALT&lt;BR&gt;
      66W&amp;nbsp;ALT&lt;BR&gt;
      66P&lt;BR&gt;
      66W&lt;BR&gt;
      66X&lt;BR&gt;
      67P&lt;BR&gt;
      67W&lt;BR&gt;
      67X&lt;BR&gt;
      67Y&lt;BR&gt;
      67Z&lt;BR&gt;
      68P&lt;BR&gt;
      68W&lt;BR&gt;
      68X&lt;BR&gt;
      67Y&amp;nbsp;ALT&lt;BR&gt;
      67Z&amp;nbsp;ALT&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      5050&lt;BR&gt;
      5091&lt;BR&gt;
      5080&lt;BR&gt;
      5087&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      T63YB&lt;BR&gt;
      T63XB&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      5887&lt;BR&gt;
      5891&lt;BR&gt;
      5880&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      T93Z&lt;BR&gt;
      T93YA&lt;BR&gt;
      T93XA&lt;BR&gt;
      T93YB&lt;BR&gt;
      T93XB&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      8026EKP&lt;BR&gt;
      8026EKW&lt;BR&gt;
      8026EKM&lt;BR&gt;
      8026EKP&lt;BR&gt;
      8026EKB&lt;BR&gt;
      8026EKM&lt;BR&gt;
      1309X&lt;BR&gt;
      1309P&lt;BR&gt;
      1309W&lt;BR&gt;
      8024EKP&lt;BR&gt;
      8024EKW&lt;BR&gt;
      8024EKN&lt;BR&gt;
      RJ-9P/CT9P&lt;BR&gt;
      RJ-9W&lt;BR&gt;
      RJ-9X&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      3103P&lt;BR&gt;
      3103Y&lt;BR&gt;
      3103Z&lt;BR&gt;
      3103P&lt;BR&gt;
      3103Y&lt;BR&gt;
      3103Z&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      3105P/3106P&lt;BR&gt;
      3105W/3106W&lt;BR&gt;
      3105X/3106X&lt;BR&gt;
      3105Y/3106Y&lt;BR&gt;
      3105Z/3105Z&lt;BR&gt;
      3102P&lt;BR&gt;
      3102W&lt;BR&gt;
      3102X&lt;BR&gt;
      3102Y&lt;BR&gt;
      3102Z&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      EVMCBG&lt;BR&gt;
      EVMCCG&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      55-1-X&lt;BR&gt;
      55-4-X&lt;BR&gt;
      55-3-X&lt;BR&gt;
      55-2-X&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      50-2-X&lt;BR&gt;
      50-4-X&lt;BR&gt;
      50-3-X&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      64P&lt;BR&gt;
      64W&lt;BR&gt;
      64X&lt;BR&gt;
      64Y&lt;BR&gt;
      64Z&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      RT/RTR22&lt;BR&gt;
      RT/RTR22&lt;BR&gt;
      RT/RTR22&lt;BR&gt;
      RT/RTR22&lt;BR&gt;
      RJ/RJR22&lt;BR&gt;
      RJ/RJR22&lt;BR&gt;
      RJ/RJR22&lt;BR&gt;
      RT/RTR26&lt;BR&gt;
      RT/RTR26&lt;BR&gt;
      RT/RTR26&lt;BR&gt;
      RJ/RJR26&lt;BR&gt;
      RJ/RJR26&lt;BR&gt;
      RJ/RJR26&lt;BR&gt;
      RJ/RJR26&lt;BR&gt;
      RJ/RJR26&lt;BR&gt;
      RJ/RJR26&lt;BR&gt;
      RT/RTR24&lt;BR&gt;
      RT/RTR24&lt;BR&gt;
      RT/RTR24&lt;BR&gt;
      RJ/RJR24&lt;BR&gt;
      RJ/RJR24&lt;BR&gt;
      RJ/RJR24&lt;BR&gt;
      RJ/RJR24&lt;BR&gt;
      RJ/RJR24&lt;BR&gt;
      RJ/RJR24&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD COLSPAN=8&gt;&amp;nbsp;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD COLSPAN=8&gt;
      &lt;FONT SIZE=4 FACE=ARIAL&gt;&lt;B&gt;SINGLE TURN&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;BOURN&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;BI&amp;nbsp;TECH&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;DALE-VISHAY&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;PHILIPS/MEPCO&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;MURATA&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;PANASONIC&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;SPECTROL&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;MILSPEC&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      3323P&lt;BR&gt;
      3323S&lt;BR&gt;
      3323W&lt;BR&gt;
      3329H&lt;BR&gt;
      3329P&lt;BR&gt;
      3329W&lt;BR&gt;
      3339H&lt;BR&gt;
      3339P&lt;BR&gt;
      3339W&lt;BR&gt;
      3352E&lt;BR&gt;
      3352H&lt;BR&gt;
      3352K&lt;BR&gt;
      3352P&lt;BR&gt;
      3352T&lt;BR&gt;
      3352V&lt;BR&gt;
      3352W&lt;BR&gt;
      3362H&lt;BR&gt;
      3362M&lt;BR&gt;
      3362P&lt;BR&gt;
      3362R&lt;BR&gt;
      3362S&lt;BR&gt;
      3362U&lt;BR&gt;
      3362W&lt;BR&gt;
      3362X&lt;BR&gt;
      3386B&lt;BR&gt;
      3386C&lt;BR&gt;
      3386F&lt;BR&gt;
      3386H&lt;BR&gt;
      3386K&lt;BR&gt;
      3386M&lt;BR&gt;
      3386P&lt;BR&gt;
      3386S&lt;BR&gt;
      3386W&lt;BR&gt;
      3386X&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      25P&lt;BR&gt;
      25S&lt;BR&gt;
      25RX&lt;BR&gt;
      82P&lt;BR&gt;
      82M&lt;BR&gt;
      82PA&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      91E&lt;BR&gt;
      91X&lt;BR&gt;
      91T&lt;BR&gt;
      91B&lt;BR&gt;
      91A&lt;BR&gt;
      91V&lt;BR&gt;
      91W&lt;BR&gt;
      25W&lt;BR&gt;
      25V&lt;BR&gt;
      25P&lt;BR&gt;
      -&lt;BR&gt;
      25S&lt;BR&gt;
      25U&lt;BR&gt;
      25RX&lt;BR&gt;
      25X&lt;BR&gt;
      72XW&lt;BR&gt;
      72XL&lt;BR&gt;
      72PM&lt;BR&gt;
      72RX&lt;BR&gt;
      -&lt;BR&gt;
      72PX&lt;BR&gt;
      72P&lt;BR&gt;
      72RXW&lt;BR&gt;
      72RXL&lt;BR&gt;
      72X&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      T7YB&lt;BR&gt;
      T7YA&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      TXD&lt;BR&gt;
      TYA&lt;BR&gt;
      TYP&lt;BR&gt;
      -&lt;BR&gt;
      TYD&lt;BR&gt;
      TX&lt;BR&gt;
      -&lt;BR&gt;
      150SX&lt;BR&gt;
      100SX&lt;BR&gt;
      102T&lt;BR&gt;
      101S&lt;BR&gt;
      190T&lt;BR&gt;
      150TX&lt;BR&gt;
      101&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      101SX&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      ET6P&lt;BR&gt;
      ET6S&lt;BR&gt;
      ET6X&lt;BR&gt;
      RJ-6W/8014EMW&lt;BR&gt;
      RJ-6P/8014EMP&lt;BR&gt;
      RJ-6X/8014EMX&lt;BR&gt;
      TM7W&lt;BR&gt;
      TM7P&lt;BR&gt;
      TM7X&lt;BR&gt;
      -&lt;BR&gt;
      8017SMS&lt;BR&gt;
      -&lt;BR&gt;
      8017SMB&lt;BR&gt;
      8017SMA&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      CT-6W&lt;BR&gt;
      CT-6H&lt;BR&gt;
      CT-6P&lt;BR&gt;
      CT-6R&lt;BR&gt;
      -&lt;BR&gt;
      CT-6V&lt;BR&gt;
      CT-6X&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      8038EKV&lt;BR&gt;
      -&lt;BR&gt;
      8038EKX&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      8038EKP&lt;BR&gt;
      8038EKZ&lt;BR&gt;
      8038EKW&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      3321H&lt;BR&gt;
      3321P&lt;BR&gt;
      3321N&lt;BR&gt;
      1102H&lt;BR&gt;
      1102P&lt;BR&gt;
      1102T&lt;BR&gt;
      RVA0911V304A&lt;BR&gt;
      -&lt;BR&gt;
      RVA0911H413A&lt;BR&gt;
      RVG0707V100A&lt;BR&gt;
      RVA0607V(H)306A&lt;BR&gt;
      RVA1214H213A&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      3104B&lt;BR&gt;
      3104C&lt;BR&gt;
      3104F&lt;BR&gt;
      3104H&lt;BR&gt;
      -&lt;BR&gt;
      3104M&lt;BR&gt;
      3104P&lt;BR&gt;
      3104S&lt;BR&gt;
      3104W&lt;BR&gt;
      3104X&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      EVMQ0G&lt;BR&gt;
      EVMQIG&lt;BR&gt;
      EVMQ3G&lt;BR&gt;
      EVMS0G&lt;BR&gt;
      EVMQ0G&lt;BR&gt;
      EVMG0G&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      EVMK4GA00B&lt;BR&gt;
      EVM30GA00B&lt;BR&gt;
      EVMK0GA00B&lt;BR&gt;
      EVM38GA00B&lt;BR&gt;
      EVMB6&lt;BR&gt;
      EVLQ0&lt;BR&gt;
      -&lt;BR&gt;
      EVMMSG&lt;BR&gt;
      EVMMBG&lt;BR&gt;
      EVMMAG&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      EVMMCS&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      EVMM1&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      EVMM0&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      EVMM3&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      62-3-1&lt;BR&gt;
      62-1-2&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      67R&lt;BR&gt;
      -&lt;BR&gt;
      67P&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      67X&lt;BR&gt;
      63V&lt;BR&gt;
      63S&lt;BR&gt;
      63M&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      63H&lt;BR&gt;
      63P&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      63X&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      RJ/RJR50&lt;BR&gt;
      RJ/RJR50&lt;BR&gt;
      RJ/RJR50&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
&lt;/TABLE&gt;
&lt;P&gt;&amp;nbsp;&lt;P&gt;
&lt;TABLE BORDER=0 CELLSPACING=1 CELLPADDING=3&gt;
  &lt;TR&gt;
    &lt;TD COLSPAN=7&gt;
      &lt;FONT color="#0000FF" SIZE=4 FACE=ARIAL&gt;&lt;B&gt;SMD TRIM-POT CROSS REFERENCE&lt;/B&gt;&lt;/FONT&gt;
      &lt;P&gt;
      &lt;FONT SIZE=4 FACE=ARIAL&gt;&lt;B&gt;MULTI-TURN&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;BOURNS&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;BI&amp;nbsp;TECH&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;DALE-VISHAY&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;PHILIPS/MEPCO&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;PANASONIC&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;TOCOS&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;AUX/KYOCERA&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      3224G&lt;BR&gt;
      3224J&lt;BR&gt;
      3224W&lt;BR&gt;
      3269P&lt;BR&gt;
      3269W&lt;BR&gt;
      3269X&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      44G&lt;BR&gt;
      44J&lt;BR&gt;
      44W&lt;BR&gt;
      84P&lt;BR&gt;
      84W&lt;BR&gt;
      84X&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      ST63Z&lt;BR&gt;
      ST63Y&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      ST5P&lt;BR&gt;
      ST5W&lt;BR&gt;
      ST5X&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD COLSPAN=7&gt;&amp;nbsp;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD COLSPAN=7&gt;
      &lt;FONT SIZE=4 FACE=ARIAL&gt;&lt;B&gt;SINGLE TURN&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;BOURNS&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;BI&amp;nbsp;TECH&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;DALE-VISHAY&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;PHILIPS/MEPCO&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;PANASONIC&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;TOCOS&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;AUX/KYOCERA&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      3314G&lt;BR&gt;
      3314J&lt;BR&gt;
      3364A/B&lt;BR&gt;
      3364C/D&lt;BR&gt;
      3364W/X&lt;BR&gt;
      3313G&lt;BR&gt;
      3313J&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      23B&lt;BR&gt;
      23A&lt;BR&gt;
      21X&lt;BR&gt;
      21W&lt;BR&gt;
      -&lt;BR&gt;
      22B&lt;BR&gt;
      22A&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      ST5YL/ST53YL&lt;BR&gt;
      ST5YJ/5T53YJ&lt;BR&gt;
      ST-23A&lt;BR&gt;
      ST-22B&lt;BR&gt;
      ST-22&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      ST-4B&lt;BR&gt;
      ST-4A&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      ST-3B&lt;BR&gt;
      ST-3A&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      EVM-6YS&lt;BR&gt;
      EVM-1E&lt;BR&gt;
      EVM-1G&lt;BR&gt;
      EVM-1D&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      G4B&lt;BR&gt;
      G4A&lt;BR&gt;
      TR04-3S1&lt;BR&gt;
      TRG04-2S1&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      DVR-43A&lt;BR&gt;
      CVR-42C&lt;BR&gt;
      CVR-42A/C&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
&lt;/TABLE&gt;
&lt;P&gt;
&lt;FONT SIZE=4 FACE=ARIAL&gt;&lt;B&gt;ALT =&amp;nbsp;ALTERNATE&lt;/B&gt;&lt;/FONT&gt;
&lt;P&gt;

&amp;nbsp;
&lt;P&gt;
&lt;/td&gt;
&lt;/tr&gt;
&lt;/table&gt;</description>
<packages>
<package name="C0402" urn="urn:adsk.eagle:footprint:23121/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-0.245" y1="0.224" x2="0.245" y2="0.224" width="0.1524" layer="51"/>
<wire x1="0.245" y1="-0.224" x2="-0.245" y2="-0.224" width="0.1524" layer="51"/>
<wire x1="-1.473" y1="0.483" x2="1.473" y2="0.483" width="0.0508" layer="39"/>
<wire x1="1.473" y1="0.483" x2="1.473" y2="-0.483" width="0.0508" layer="39"/>
<wire x1="1.473" y1="-0.483" x2="-1.473" y2="-0.483" width="0.0508" layer="39"/>
<wire x1="-1.473" y1="-0.483" x2="-1.473" y2="0.483" width="0.0508" layer="39"/>
<smd name="1" x="-0.65" y="0" dx="0.7" dy="0.9" layer="1"/>
<smd name="2" x="0.65" y="0" dx="0.7" dy="0.9" layer="1"/>
<text x="-0.635" y="0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-1.905" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.554" y1="-0.3048" x2="-0.254" y2="0.2951" layer="51"/>
<rectangle x1="0.2588" y1="-0.3048" x2="0.5588" y2="0.2951" layer="51"/>
<rectangle x1="-0.1999" y1="-0.3" x2="0.1999" y2="0.3" layer="35"/>
</package>
<package name="C0504" urn="urn:adsk.eagle:footprint:23122/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-1.473" y1="0.983" x2="1.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="1.473" y1="0.983" x2="1.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="1.473" y1="-0.983" x2="-1.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-1.473" y1="-0.983" x2="-1.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="-0.294" y1="0.559" x2="0.294" y2="0.559" width="0.1016" layer="51"/>
<wire x1="-0.294" y1="-0.559" x2="0.294" y2="-0.559" width="0.1016" layer="51"/>
<smd name="1" x="-0.7" y="0" dx="1" dy="1.3" layer="1"/>
<smd name="2" x="0.7" y="0" dx="1" dy="1.3" layer="1"/>
<text x="-0.635" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.6604" y1="-0.6223" x2="-0.2804" y2="0.6276" layer="51"/>
<rectangle x1="0.2794" y1="-0.6223" x2="0.6594" y2="0.6276" layer="51"/>
<rectangle x1="-0.1001" y1="-0.4001" x2="0.1001" y2="0.4001" layer="35"/>
</package>
<package name="C0603" urn="urn:adsk.eagle:footprint:23123/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-1.473" y1="0.983" x2="1.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="1.473" y1="0.983" x2="1.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="1.473" y1="-0.983" x2="-1.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-1.473" y1="-0.983" x2="-1.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="-0.356" y1="0.432" x2="0.356" y2="0.432" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.419" x2="0.356" y2="-0.419" width="0.1016" layer="51"/>
<smd name="1" x="-0.85" y="0" dx="1.1" dy="1" layer="1"/>
<smd name="2" x="0.85" y="0" dx="1.1" dy="1" layer="1"/>
<text x="-0.635" y="0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-1.905" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.8382" y1="-0.4699" x2="-0.3381" y2="0.4801" layer="51"/>
<rectangle x1="0.3302" y1="-0.4699" x2="0.8303" y2="0.4801" layer="51"/>
<rectangle x1="-0.1999" y1="-0.3" x2="0.1999" y2="0.3" layer="35"/>
</package>
<package name="C0805" urn="urn:adsk.eagle:footprint:23124/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;</description>
<wire x1="-1.973" y1="0.983" x2="1.973" y2="0.983" width="0.0508" layer="39"/>
<wire x1="1.973" y1="-0.983" x2="-1.973" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-1.973" y1="-0.983" x2="-1.973" y2="0.983" width="0.0508" layer="39"/>
<wire x1="-0.381" y1="0.66" x2="0.381" y2="0.66" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.66" x2="0.381" y2="-0.66" width="0.1016" layer="51"/>
<wire x1="1.973" y1="0.983" x2="1.973" y2="-0.983" width="0.0508" layer="39"/>
<smd name="1" x="-0.95" y="0" dx="1.3" dy="1.5" layer="1"/>
<smd name="2" x="0.95" y="0" dx="1.3" dy="1.5" layer="1"/>
<text x="-1.27" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.0922" y1="-0.7239" x2="-0.3421" y2="0.7262" layer="51"/>
<rectangle x1="0.3556" y1="-0.7239" x2="1.1057" y2="0.7262" layer="51"/>
<rectangle x1="-0.1001" y1="-0.4001" x2="0.1001" y2="0.4001" layer="35"/>
</package>
<package name="C1206" urn="urn:adsk.eagle:footprint:23125/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.473" y1="0.983" x2="2.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="2.473" y1="-0.983" x2="-2.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-2.473" y1="-0.983" x2="-2.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="2.473" y1="0.983" x2="2.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-0.965" y1="0.787" x2="0.965" y2="0.787" width="0.1016" layer="51"/>
<wire x1="-0.965" y1="-0.787" x2="0.965" y2="-0.787" width="0.1016" layer="51"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<text x="-1.27" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.7018" y1="-0.8509" x2="-0.9517" y2="0.8491" layer="51"/>
<rectangle x1="0.9517" y1="-0.8491" x2="1.7018" y2="0.8509" layer="51"/>
<rectangle x1="-0.1999" y1="-0.4001" x2="0.1999" y2="0.4001" layer="35"/>
</package>
<package name="C1210" urn="urn:adsk.eagle:footprint:23126/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.473" y1="1.483" x2="2.473" y2="1.483" width="0.0508" layer="39"/>
<wire x1="2.473" y1="-1.483" x2="-2.473" y2="-1.483" width="0.0508" layer="39"/>
<wire x1="-2.473" y1="-1.483" x2="-2.473" y2="1.483" width="0.0508" layer="39"/>
<wire x1="-0.9652" y1="1.2446" x2="0.9652" y2="1.2446" width="0.1016" layer="51"/>
<wire x1="-0.9652" y1="-1.2446" x2="0.9652" y2="-1.2446" width="0.1016" layer="51"/>
<wire x1="2.473" y1="1.483" x2="2.473" y2="-1.483" width="0.0508" layer="39"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="2.7" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="2.7" layer="1"/>
<text x="-1.905" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.7018" y1="-1.2954" x2="-0.9517" y2="1.3045" layer="51"/>
<rectangle x1="0.9517" y1="-1.3045" x2="1.7018" y2="1.2954" layer="51"/>
<rectangle x1="-0.1999" y1="-0.4001" x2="0.1999" y2="0.4001" layer="35"/>
</package>
<package name="C1310" urn="urn:adsk.eagle:footprint:23127/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-1.473" y1="0.983" x2="1.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="1.473" y1="0.983" x2="1.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="1.473" y1="-0.983" x2="-1.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-1.473" y1="-0.983" x2="-1.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="-0.294" y1="0.559" x2="0.294" y2="0.559" width="0.1016" layer="51"/>
<wire x1="-0.294" y1="-0.559" x2="0.294" y2="-0.559" width="0.1016" layer="51"/>
<smd name="1" x="-0.7" y="0" dx="1" dy="1.3" layer="1"/>
<smd name="2" x="0.7" y="0" dx="1" dy="1.3" layer="1"/>
<text x="-0.635" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.6604" y1="-0.6223" x2="-0.2804" y2="0.6276" layer="51"/>
<rectangle x1="0.2794" y1="-0.6223" x2="0.6594" y2="0.6276" layer="51"/>
<rectangle x1="-0.1001" y1="-0.3" x2="0.1001" y2="0.3" layer="35"/>
</package>
<package name="C1608" urn="urn:adsk.eagle:footprint:23128/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-1.473" y1="0.983" x2="1.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="1.473" y1="0.983" x2="1.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="1.473" y1="-0.983" x2="-1.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-1.473" y1="-0.983" x2="-1.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="-0.356" y1="0.432" x2="0.356" y2="0.432" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.419" x2="0.356" y2="-0.419" width="0.1016" layer="51"/>
<smd name="1" x="-0.85" y="0" dx="1.1" dy="1" layer="1"/>
<smd name="2" x="0.85" y="0" dx="1.1" dy="1" layer="1"/>
<text x="-0.635" y="0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-1.905" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.8382" y1="-0.4699" x2="-0.3381" y2="0.4801" layer="51"/>
<rectangle x1="0.3302" y1="-0.4699" x2="0.8303" y2="0.4801" layer="51"/>
<rectangle x1="-0.1999" y1="-0.3" x2="0.1999" y2="0.3" layer="35"/>
</package>
<package name="C1812" urn="urn:adsk.eagle:footprint:23129/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.973" y1="1.983" x2="2.973" y2="1.983" width="0.0508" layer="39"/>
<wire x1="2.973" y1="-1.983" x2="-2.973" y2="-1.983" width="0.0508" layer="39"/>
<wire x1="-2.973" y1="-1.983" x2="-2.973" y2="1.983" width="0.0508" layer="39"/>
<wire x1="-1.4732" y1="1.6002" x2="1.4732" y2="1.6002" width="0.1016" layer="51"/>
<wire x1="-1.4478" y1="-1.6002" x2="1.4732" y2="-1.6002" width="0.1016" layer="51"/>
<wire x1="2.973" y1="1.983" x2="2.973" y2="-1.983" width="0.0508" layer="39"/>
<smd name="1" x="-1.95" y="0" dx="1.9" dy="3.4" layer="1"/>
<smd name="2" x="1.95" y="0" dx="1.9" dy="3.4" layer="1"/>
<text x="-1.905" y="2.54" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-3.81" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.3876" y1="-1.651" x2="-1.4376" y2="1.649" layer="51"/>
<rectangle x1="1.4478" y1="-1.651" x2="2.3978" y2="1.649" layer="51"/>
<rectangle x1="-0.3" y1="-0.4001" x2="0.3" y2="0.4001" layer="35"/>
</package>
<package name="C1825" urn="urn:adsk.eagle:footprint:23130/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.973" y1="3.483" x2="2.973" y2="3.483" width="0.0508" layer="39"/>
<wire x1="2.973" y1="-3.483" x2="-2.973" y2="-3.483" width="0.0508" layer="39"/>
<wire x1="-2.973" y1="-3.483" x2="-2.973" y2="3.483" width="0.0508" layer="39"/>
<wire x1="-1.4986" y1="3.2766" x2="1.4732" y2="3.2766" width="0.1016" layer="51"/>
<wire x1="-1.4732" y1="-3.2766" x2="1.4986" y2="-3.2766" width="0.1016" layer="51"/>
<wire x1="2.973" y1="3.483" x2="2.973" y2="-3.483" width="0.0508" layer="39"/>
<smd name="1" x="-1.95" y="0" dx="1.9" dy="6.8" layer="1"/>
<smd name="2" x="1.95" y="0" dx="1.9" dy="6.8" layer="1"/>
<text x="-1.905" y="3.81" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-5.08" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.413" y1="-3.3528" x2="-1.463" y2="3.3472" layer="51"/>
<rectangle x1="1.4478" y1="-3.3528" x2="2.3978" y2="3.3472" layer="51"/>
<rectangle x1="-0.7" y1="-0.7" x2="0.7" y2="0.7" layer="35"/>
</package>
<package name="C2012" urn="urn:adsk.eagle:footprint:23131/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-1.973" y1="0.983" x2="1.973" y2="0.983" width="0.0508" layer="39"/>
<wire x1="1.973" y1="0.983" x2="1.973" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="1.973" y1="-0.983" x2="-1.973" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-1.973" y1="-0.983" x2="-1.973" y2="0.983" width="0.0508" layer="39"/>
<wire x1="-0.381" y1="0.66" x2="0.381" y2="0.66" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.66" x2="0.381" y2="-0.66" width="0.1016" layer="51"/>
<smd name="1" x="-0.85" y="0" dx="1.3" dy="1.5" layer="1"/>
<smd name="2" x="0.85" y="0" dx="1.3" dy="1.5" layer="1"/>
<text x="-1.27" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.0922" y1="-0.7239" x2="-0.3421" y2="0.7262" layer="51"/>
<rectangle x1="0.3556" y1="-0.7239" x2="1.1057" y2="0.7262" layer="51"/>
<rectangle x1="-0.1001" y1="-0.4001" x2="0.1001" y2="0.4001" layer="35"/>
</package>
<package name="C3216" urn="urn:adsk.eagle:footprint:23132/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.473" y1="0.983" x2="2.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="2.473" y1="-0.983" x2="-2.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-2.473" y1="-0.983" x2="-2.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="2.473" y1="0.983" x2="2.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-0.965" y1="0.787" x2="0.965" y2="0.787" width="0.1016" layer="51"/>
<wire x1="-0.965" y1="-0.787" x2="0.965" y2="-0.787" width="0.1016" layer="51"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<text x="-1.27" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.7018" y1="-0.8509" x2="-0.9517" y2="0.8491" layer="51"/>
<rectangle x1="0.9517" y1="-0.8491" x2="1.7018" y2="0.8509" layer="51"/>
<rectangle x1="-0.3" y1="-0.5001" x2="0.3" y2="0.5001" layer="35"/>
</package>
<package name="C3225" urn="urn:adsk.eagle:footprint:23133/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.473" y1="1.483" x2="2.473" y2="1.483" width="0.0508" layer="39"/>
<wire x1="2.473" y1="-1.483" x2="-2.473" y2="-1.483" width="0.0508" layer="39"/>
<wire x1="-2.473" y1="-1.483" x2="-2.473" y2="1.483" width="0.0508" layer="39"/>
<wire x1="-0.9652" y1="1.2446" x2="0.9652" y2="1.2446" width="0.1016" layer="51"/>
<wire x1="-0.9652" y1="-1.2446" x2="0.9652" y2="-1.2446" width="0.1016" layer="51"/>
<wire x1="2.473" y1="1.483" x2="2.473" y2="-1.483" width="0.0508" layer="39"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="2.7" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="2.7" layer="1"/>
<text x="-1.905" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.7018" y1="-1.2954" x2="-0.9517" y2="1.3045" layer="51"/>
<rectangle x1="0.9517" y1="-1.3045" x2="1.7018" y2="1.2954" layer="51"/>
<rectangle x1="-0.1999" y1="-0.5001" x2="0.1999" y2="0.5001" layer="35"/>
</package>
<package name="C4532" urn="urn:adsk.eagle:footprint:23134/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.973" y1="1.983" x2="2.973" y2="1.983" width="0.0508" layer="39"/>
<wire x1="2.973" y1="-1.983" x2="-2.973" y2="-1.983" width="0.0508" layer="39"/>
<wire x1="-2.973" y1="-1.983" x2="-2.973" y2="1.983" width="0.0508" layer="39"/>
<wire x1="-1.4732" y1="1.6002" x2="1.4732" y2="1.6002" width="0.1016" layer="51"/>
<wire x1="-1.4478" y1="-1.6002" x2="1.4732" y2="-1.6002" width="0.1016" layer="51"/>
<wire x1="2.973" y1="1.983" x2="2.973" y2="-1.983" width="0.0508" layer="39"/>
<smd name="1" x="-1.95" y="0" dx="1.9" dy="3.4" layer="1"/>
<smd name="2" x="1.95" y="0" dx="1.9" dy="3.4" layer="1"/>
<text x="-1.905" y="2.54" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-3.81" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.3876" y1="-1.651" x2="-1.4376" y2="1.649" layer="51"/>
<rectangle x1="1.4478" y1="-1.651" x2="2.3978" y2="1.649" layer="51"/>
<rectangle x1="-0.4001" y1="-0.7" x2="0.4001" y2="0.7" layer="35"/>
</package>
<package name="C4564" urn="urn:adsk.eagle:footprint:23135/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.973" y1="3.483" x2="2.973" y2="3.483" width="0.0508" layer="39"/>
<wire x1="2.973" y1="-3.483" x2="-2.973" y2="-3.483" width="0.0508" layer="39"/>
<wire x1="-2.973" y1="-3.483" x2="-2.973" y2="3.483" width="0.0508" layer="39"/>
<wire x1="-1.4986" y1="3.2766" x2="1.4732" y2="3.2766" width="0.1016" layer="51"/>
<wire x1="-1.4732" y1="-3.2766" x2="1.4986" y2="-3.2766" width="0.1016" layer="51"/>
<wire x1="2.973" y1="3.483" x2="2.973" y2="-3.483" width="0.0508" layer="39"/>
<smd name="1" x="-1.95" y="0" dx="1.9" dy="6.8" layer="1"/>
<smd name="2" x="1.95" y="0" dx="1.9" dy="6.8" layer="1"/>
<text x="-1.905" y="3.81" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-5.08" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.413" y1="-3.3528" x2="-1.463" y2="3.3472" layer="51"/>
<rectangle x1="1.4478" y1="-3.3528" x2="2.3978" y2="3.3472" layer="51"/>
<rectangle x1="-0.5001" y1="-1" x2="0.5001" y2="1" layer="35"/>
</package>
<package name="C025-024X044" urn="urn:adsk.eagle:footprint:23136/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 2.5 mm, outline 2.4 x 4.4 mm</description>
<wire x1="-2.159" y1="-0.635" x2="-2.159" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-2.159" y1="0.635" x2="-1.651" y2="1.143" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.159" y1="-0.635" x2="-1.651" y2="-1.143" width="0.1524" layer="21" curve="90"/>
<wire x1="1.651" y1="1.143" x2="-1.651" y2="1.143" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-0.635" x2="2.159" y2="0.635" width="0.1524" layer="21"/>
<wire x1="1.651" y1="-1.143" x2="-1.651" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="1.651" y1="1.143" x2="2.159" y2="0.635" width="0.1524" layer="21" curve="-90"/>
<wire x1="1.651" y1="-1.143" x2="2.159" y2="-0.635" width="0.1524" layer="21" curve="90"/>
<wire x1="-0.3048" y1="0.762" x2="-0.3048" y2="-0.762" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0.762" x2="0.3302" y2="-0.762" width="0.3048" layer="21"/>
<wire x1="1.27" y1="0" x2="0.3302" y2="0" width="0.1524" layer="51"/>
<wire x1="-1.27" y1="0" x2="-0.3048" y2="0" width="0.1524" layer="51"/>
<pad name="1" x="-1.27" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="1.27" y="0" drill="0.8128" shape="octagon"/>
<text x="-1.778" y="1.397" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-1.778" y="-2.667" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C025-025X050" urn="urn:adsk.eagle:footprint:23137/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 2.5 mm, outline 2.5 x 5 mm</description>
<wire x1="-2.159" y1="1.27" x2="2.159" y2="1.27" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-1.27" x2="-2.159" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="2.413" y1="1.016" x2="2.413" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="1.016" x2="-2.413" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="2.159" y1="1.27" x2="2.413" y2="1.016" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.413" y1="1.016" x2="-2.159" y2="1.27" width="0.1524" layer="21" curve="-90"/>
<wire x1="2.159" y1="-1.27" x2="2.413" y2="-1.016" width="0.1524" layer="21" curve="90"/>
<wire x1="-2.413" y1="-1.016" x2="-2.159" y2="-1.27" width="0.1524" layer="21" curve="90"/>
<wire x1="0.762" y1="0" x2="0.381" y2="0" width="0.1524" layer="51"/>
<wire x1="0.381" y1="0" x2="0.254" y2="0" width="0.1524" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="0.762" width="0.254" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0.762" x2="-0.254" y2="0" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.381" y2="0" width="0.1524" layer="21"/>
<wire x1="-0.381" y1="0" x2="-0.762" y2="0" width="0.1524" layer="51"/>
<pad name="1" x="-1.27" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="1.27" y="0" drill="0.8128" shape="octagon"/>
<text x="-2.286" y="1.524" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.286" y="-2.794" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C025-030X050" urn="urn:adsk.eagle:footprint:23138/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 2.5 mm, outline 3 x 5 mm</description>
<wire x1="-2.159" y1="1.524" x2="2.159" y2="1.524" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-1.524" x2="-2.159" y2="-1.524" width="0.1524" layer="21"/>
<wire x1="2.413" y1="1.27" x2="2.413" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="1.27" x2="-2.413" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="2.159" y1="1.524" x2="2.413" y2="1.27" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.413" y1="1.27" x2="-2.159" y2="1.524" width="0.1524" layer="21" curve="-90"/>
<wire x1="2.159" y1="-1.524" x2="2.413" y2="-1.27" width="0.1524" layer="21" curve="90"/>
<wire x1="-2.413" y1="-1.27" x2="-2.159" y2="-1.524" width="0.1524" layer="21" curve="90"/>
<wire x1="0.762" y1="0" x2="0.381" y2="0" width="0.1524" layer="51"/>
<wire x1="0.381" y1="0" x2="0.254" y2="0" width="0.1524" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="0.762" width="0.254" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0.762" x2="-0.254" y2="0" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.381" y2="0" width="0.1524" layer="21"/>
<wire x1="-0.381" y1="0" x2="-0.762" y2="0" width="0.1524" layer="51"/>
<pad name="1" x="-1.27" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="1.27" y="0" drill="0.8128" shape="octagon"/>
<text x="-2.286" y="1.905" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.286" y="-3.048" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C025-040X050" urn="urn:adsk.eagle:footprint:23139/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 2.5 mm, outline 4 x 5 mm</description>
<wire x1="-2.159" y1="1.905" x2="2.159" y2="1.905" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-1.905" x2="-2.159" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="2.413" y1="1.651" x2="2.413" y2="-1.651" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="1.651" x2="-2.413" y2="-1.651" width="0.1524" layer="21"/>
<wire x1="2.159" y1="1.905" x2="2.413" y2="1.651" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.413" y1="1.651" x2="-2.159" y2="1.905" width="0.1524" layer="21" curve="-90"/>
<wire x1="2.159" y1="-1.905" x2="2.413" y2="-1.651" width="0.1524" layer="21" curve="90"/>
<wire x1="-2.413" y1="-1.651" x2="-2.159" y2="-1.905" width="0.1524" layer="21" curve="90"/>
<wire x1="0.762" y1="0" x2="0.381" y2="0" width="0.1524" layer="51"/>
<wire x1="0.381" y1="0" x2="0.254" y2="0" width="0.1524" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="0.762" width="0.254" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0.762" x2="-0.254" y2="0" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.381" y2="0" width="0.1524" layer="21"/>
<wire x1="-0.381" y1="0" x2="-0.762" y2="0" width="0.1524" layer="51"/>
<pad name="1" x="-1.27" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="1.27" y="0" drill="0.8128" shape="octagon"/>
<text x="-2.286" y="2.159" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.286" y="-3.429" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C025-050X050" urn="urn:adsk.eagle:footprint:23140/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 2.5 mm, outline 5 x 5 mm</description>
<wire x1="-2.159" y1="2.286" x2="2.159" y2="2.286" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-2.286" x2="-2.159" y2="-2.286" width="0.1524" layer="21"/>
<wire x1="2.413" y1="2.032" x2="2.413" y2="-2.032" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="2.032" x2="-2.413" y2="-2.032" width="0.1524" layer="21"/>
<wire x1="2.159" y1="2.286" x2="2.413" y2="2.032" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.413" y1="2.032" x2="-2.159" y2="2.286" width="0.1524" layer="21" curve="-90"/>
<wire x1="2.159" y1="-2.286" x2="2.413" y2="-2.032" width="0.1524" layer="21" curve="90"/>
<wire x1="-2.413" y1="-2.032" x2="-2.159" y2="-2.286" width="0.1524" layer="21" curve="90"/>
<wire x1="0.762" y1="0" x2="0.381" y2="0" width="0.1524" layer="51"/>
<wire x1="0.381" y1="0" x2="0.254" y2="0" width="0.1524" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="0.762" width="0.254" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0.762" x2="-0.254" y2="0" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.381" y2="0" width="0.1524" layer="21"/>
<wire x1="-0.381" y1="0" x2="-0.762" y2="0" width="0.1524" layer="51"/>
<pad name="1" x="-1.27" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="1.27" y="0" drill="0.8128" shape="octagon"/>
<text x="-2.286" y="2.54" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.286" y="-3.81" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C025-060X050" urn="urn:adsk.eagle:footprint:23141/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 2.5 mm, outline 6 x 5 mm</description>
<wire x1="-2.159" y1="2.794" x2="2.159" y2="2.794" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-2.794" x2="-2.159" y2="-2.794" width="0.1524" layer="21"/>
<wire x1="2.413" y1="2.54" x2="2.413" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="2.54" x2="-2.413" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="2.159" y1="2.794" x2="2.413" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.413" y1="2.54" x2="-2.159" y2="2.794" width="0.1524" layer="21" curve="-90"/>
<wire x1="2.159" y1="-2.794" x2="2.413" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="-2.413" y1="-2.54" x2="-2.159" y2="-2.794" width="0.1524" layer="21" curve="90"/>
<wire x1="0.762" y1="0" x2="0.381" y2="0" width="0.1524" layer="51"/>
<wire x1="0.381" y1="0" x2="0.254" y2="0" width="0.1524" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="0.762" width="0.254" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0.762" x2="-0.254" y2="0" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.381" y2="0" width="0.1524" layer="21"/>
<wire x1="-0.381" y1="0" x2="-0.762" y2="0" width="0.1524" layer="51"/>
<pad name="1" x="-1.27" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="1.27" y="0" drill="0.8128" shape="octagon"/>
<text x="-2.286" y="3.048" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.032" y="-2.413" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C025_050-024X070" urn="urn:adsk.eagle:footprint:23142/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 2.5 mm + 5 mm, outline 2.4 x 7 mm</description>
<wire x1="-2.159" y1="-0.635" x2="-2.159" y2="0.635" width="0.1524" layer="51"/>
<wire x1="-2.159" y1="0.635" x2="-1.651" y2="1.143" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.159" y1="-0.635" x2="-1.651" y2="-1.143" width="0.1524" layer="21" curve="90"/>
<wire x1="1.651" y1="1.143" x2="-1.651" y2="1.143" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-0.635" x2="2.159" y2="0.635" width="0.1524" layer="51"/>
<wire x1="1.651" y1="-1.143" x2="-1.651" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="1.651" y1="1.143" x2="2.159" y2="0.635" width="0.1524" layer="21" curve="-90"/>
<wire x1="-4.191" y1="-1.143" x2="-3.9624" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="-4.191" y1="1.143" x2="-3.9624" y2="1.143" width="0.1524" layer="21"/>
<wire x1="-4.699" y1="-0.635" x2="-4.191" y2="-1.143" width="0.1524" layer="21" curve="90"/>
<wire x1="1.651" y1="-1.143" x2="2.159" y2="-0.635" width="0.1524" layer="21" curve="90"/>
<wire x1="-4.699" y1="0.635" x2="-4.191" y2="1.143" width="0.1524" layer="21" curve="-90"/>
<wire x1="-4.699" y1="-0.635" x2="-4.699" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-3.429" y1="1.143" x2="-2.5654" y2="1.143" width="0.1524" layer="21"/>
<wire x1="-3.429" y1="-1.143" x2="-2.5654" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="-0.3048" y1="0.762" x2="-0.3048" y2="-0.762" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0.762" x2="0.3302" y2="-0.762" width="0.3048" layer="21"/>
<wire x1="1.27" y1="0" x2="0.3302" y2="0" width="0.1524" layer="51"/>
<wire x1="-1.27" y1="0" x2="-0.3048" y2="0" width="0.1524" layer="51"/>
<pad name="1" x="-3.81" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="-1.27" y="0" drill="0.8128" shape="octagon"/>
<pad name="3" x="1.27" y="0" drill="0.8128" shape="octagon"/>
<text x="-3.81" y="1.397" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.81" y="-2.667" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C025_050-025X075" urn="urn:adsk.eagle:footprint:23143/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 2.5 + 5 mm, outline 2.5 x 7.5 mm</description>
<wire x1="-2.159" y1="1.27" x2="2.159" y2="1.27" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-1.27" x2="-2.159" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="1.016" x2="-2.413" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="2.159" y1="1.27" x2="2.413" y2="1.016" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.413" y1="1.016" x2="-2.159" y2="1.27" width="0.1524" layer="21" curve="-90"/>
<wire x1="2.159" y1="-1.27" x2="2.413" y2="-1.016" width="0.1524" layer="21" curve="90"/>
<wire x1="-2.413" y1="-1.016" x2="-2.159" y2="-1.27" width="0.1524" layer="21" curve="90"/>
<wire x1="0.381" y1="0" x2="0.254" y2="0" width="0.1524" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="0.762" width="0.254" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0.762" x2="-0.254" y2="0" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.381" y2="0" width="0.1524" layer="21"/>
<wire x1="-0.381" y1="0" x2="-0.762" y2="0" width="0.1524" layer="51"/>
<wire x1="4.953" y1="1.016" x2="4.953" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="4.699" y1="1.27" x2="4.953" y2="1.016" width="0.1524" layer="21" curve="-90"/>
<wire x1="4.699" y1="-1.27" x2="4.953" y2="-1.016" width="0.1524" layer="21" curve="90"/>
<wire x1="2.794" y1="1.27" x2="4.699" y2="1.27" width="0.1524" layer="21"/>
<wire x1="4.699" y1="-1.27" x2="2.794" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="2.413" y1="1.016" x2="2.413" y2="0.762" width="0.1524" layer="21"/>
<wire x1="2.413" y1="-0.762" x2="2.413" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="2.413" y1="0.254" x2="2.413" y2="-0.254" width="0.1524" layer="21"/>
<wire x1="1.778" y1="0" x2="2.286" y2="0" width="0.1524" layer="51"/>
<wire x1="2.286" y1="0" x2="2.794" y2="0" width="0.1524" layer="21"/>
<wire x1="2.794" y1="0" x2="3.302" y2="0" width="0.1524" layer="51"/>
<wire x1="0.762" y1="0" x2="0.381" y2="0" width="0.1524" layer="51"/>
<pad name="1" x="-1.27" y="0" drill="0.8128" shape="octagon"/>
<pad name="3" x="3.81" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="1.27" y="0" drill="0.8128" shape="octagon"/>
<text x="-2.159" y="1.651" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.159" y="-2.794" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C025_050-035X075" urn="urn:adsk.eagle:footprint:23144/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 2.5 + 5 mm, outline 3.5 x 7.5 mm</description>
<wire x1="-2.159" y1="1.778" x2="2.159" y2="1.778" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-1.778" x2="-2.159" y2="-1.778" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="1.524" x2="-2.413" y2="-1.524" width="0.1524" layer="21"/>
<wire x1="2.159" y1="1.778" x2="2.413" y2="1.524" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.413" y1="1.524" x2="-2.159" y2="1.778" width="0.1524" layer="21" curve="-90"/>
<wire x1="2.159" y1="-1.778" x2="2.413" y2="-1.524" width="0.1524" layer="21" curve="90"/>
<wire x1="-2.413" y1="-1.524" x2="-2.159" y2="-1.778" width="0.1524" layer="21" curve="90"/>
<wire x1="0.381" y1="0" x2="0.254" y2="0" width="0.1524" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="0.762" width="0.254" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0.762" x2="-0.254" y2="0" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.381" y2="0" width="0.1524" layer="21"/>
<wire x1="-0.381" y1="0" x2="-0.762" y2="0" width="0.1524" layer="51"/>
<wire x1="4.953" y1="1.524" x2="4.953" y2="-1.524" width="0.1524" layer="21"/>
<wire x1="4.699" y1="1.778" x2="4.953" y2="1.524" width="0.1524" layer="21" curve="-90"/>
<wire x1="4.699" y1="-1.778" x2="4.953" y2="-1.524" width="0.1524" layer="21" curve="90"/>
<wire x1="2.794" y1="1.778" x2="4.699" y2="1.778" width="0.1524" layer="21"/>
<wire x1="4.699" y1="-1.778" x2="2.794" y2="-1.778" width="0.1524" layer="21"/>
<wire x1="2.413" y1="1.524" x2="2.413" y2="1.016" width="0.1524" layer="21"/>
<wire x1="2.413" y1="-1.016" x2="2.413" y2="-1.524" width="0.1524" layer="21"/>
<wire x1="2.413" y1="0.508" x2="2.413" y2="-0.508" width="0.1524" layer="21"/>
<wire x1="0.381" y1="0" x2="0.762" y2="0" width="0.1524" layer="51"/>
<wire x1="2.286" y1="0" x2="2.794" y2="0" width="0.1524" layer="21"/>
<wire x1="2.794" y1="0" x2="3.302" y2="0" width="0.1524" layer="51"/>
<wire x1="2.286" y1="0" x2="1.778" y2="0" width="0.1524" layer="51"/>
<pad name="1" x="-1.27" y="0" drill="0.8128" shape="octagon"/>
<pad name="3" x="3.81" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="1.27" y="0" drill="0.8128" shape="octagon"/>
<text x="-2.286" y="2.159" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.286" y="-3.302" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C025_050-045X075" urn="urn:adsk.eagle:footprint:23145/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 2.5 + 5 mm, outline 4.5 x 7.5 mm</description>
<wire x1="-2.159" y1="2.286" x2="2.159" y2="2.286" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-2.286" x2="-2.159" y2="-2.286" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="2.032" x2="-2.413" y2="-2.032" width="0.1524" layer="21"/>
<wire x1="2.159" y1="2.286" x2="2.413" y2="2.032" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.413" y1="2.032" x2="-2.159" y2="2.286" width="0.1524" layer="21" curve="-90"/>
<wire x1="2.159" y1="-2.286" x2="2.413" y2="-2.032" width="0.1524" layer="21" curve="90"/>
<wire x1="-2.413" y1="-2.032" x2="-2.159" y2="-2.286" width="0.1524" layer="21" curve="90"/>
<wire x1="0.381" y1="0" x2="0.254" y2="0" width="0.1524" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="0.762" width="0.254" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0.762" x2="-0.254" y2="0" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.381" y2="0" width="0.1524" layer="21"/>
<wire x1="-0.381" y1="0" x2="-0.762" y2="0" width="0.1524" layer="51"/>
<wire x1="4.953" y1="2.032" x2="4.953" y2="-2.032" width="0.1524" layer="21"/>
<wire x1="4.699" y1="2.286" x2="4.953" y2="2.032" width="0.1524" layer="21" curve="-90"/>
<wire x1="4.699" y1="-2.286" x2="4.953" y2="-2.032" width="0.1524" layer="21" curve="90"/>
<wire x1="2.794" y1="2.286" x2="4.699" y2="2.286" width="0.1524" layer="21"/>
<wire x1="4.699" y1="-2.286" x2="2.794" y2="-2.286" width="0.1524" layer="21"/>
<wire x1="2.413" y1="2.032" x2="2.413" y2="1.397" width="0.1524" layer="21"/>
<wire x1="2.413" y1="-1.397" x2="2.413" y2="-2.032" width="0.1524" layer="21"/>
<wire x1="2.413" y1="0.762" x2="2.413" y2="-0.762" width="0.1524" layer="21"/>
<wire x1="2.286" y1="0" x2="2.794" y2="0" width="0.1524" layer="21"/>
<wire x1="2.794" y1="0" x2="3.302" y2="0" width="0.1524" layer="51"/>
<wire x1="0.381" y1="0" x2="0.762" y2="0" width="0.1524" layer="51"/>
<wire x1="2.286" y1="0" x2="1.778" y2="0" width="0.1524" layer="51"/>
<pad name="1" x="-1.27" y="0" drill="0.8128" shape="octagon"/>
<pad name="3" x="3.81" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="1.27" y="0" drill="0.8128" shape="octagon"/>
<text x="-2.286" y="2.667" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.286" y="-3.81" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C025_050-055X075" urn="urn:adsk.eagle:footprint:23146/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 2.5 + 5 mm, outline 5.5 x 7.5 mm</description>
<wire x1="-2.159" y1="2.794" x2="2.159" y2="2.794" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-2.794" x2="-2.159" y2="-2.794" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="2.54" x2="-2.413" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="2.159" y1="2.794" x2="2.413" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.413" y1="2.54" x2="-2.159" y2="2.794" width="0.1524" layer="21" curve="-90"/>
<wire x1="2.159" y1="-2.794" x2="2.413" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="-2.413" y1="-2.54" x2="-2.159" y2="-2.794" width="0.1524" layer="21" curve="90"/>
<wire x1="0.381" y1="0" x2="0.254" y2="0" width="0.1524" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="0.762" width="0.254" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0.762" x2="-0.254" y2="0" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.381" y2="0" width="0.1524" layer="21"/>
<wire x1="-0.381" y1="0" x2="-0.762" y2="0" width="0.1524" layer="51"/>
<wire x1="4.953" y1="2.54" x2="4.953" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="4.699" y1="2.794" x2="4.953" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<wire x1="4.699" y1="-2.794" x2="4.953" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="2.794" y1="2.794" x2="4.699" y2="2.794" width="0.1524" layer="21"/>
<wire x1="4.699" y1="-2.794" x2="2.794" y2="-2.794" width="0.1524" layer="21"/>
<wire x1="2.413" y1="2.54" x2="2.413" y2="2.032" width="0.1524" layer="21"/>
<wire x1="2.413" y1="-2.032" x2="2.413" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="2.413" y1="0.762" x2="2.413" y2="-0.762" width="0.1524" layer="21"/>
<wire x1="1.778" y1="0" x2="2.286" y2="0" width="0.1524" layer="51"/>
<wire x1="2.286" y1="0" x2="2.794" y2="0" width="0.1524" layer="21"/>
<wire x1="2.794" y1="0" x2="3.302" y2="0" width="0.1524" layer="51"/>
<wire x1="0.381" y1="0" x2="0.762" y2="0" width="0.1524" layer="51"/>
<pad name="1" x="-1.27" y="0" drill="0.8128" shape="octagon"/>
<pad name="3" x="3.81" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="1.27" y="0" drill="0.8128" shape="octagon"/>
<text x="-2.286" y="3.175" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.032" y="-2.286" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C050-024X044" urn="urn:adsk.eagle:footprint:23147/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 5 mm, outline 2.4 x 4.4 mm</description>
<wire x1="-2.159" y1="-0.635" x2="-2.159" y2="0.635" width="0.1524" layer="51"/>
<wire x1="-2.159" y1="0.635" x2="-1.651" y2="1.143" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.159" y1="-0.635" x2="-1.651" y2="-1.143" width="0.1524" layer="21" curve="90"/>
<wire x1="1.651" y1="1.143" x2="-1.651" y2="1.143" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-0.635" x2="2.159" y2="0.635" width="0.1524" layer="51"/>
<wire x1="1.651" y1="-1.143" x2="-1.651" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="1.651" y1="1.143" x2="2.159" y2="0.635" width="0.1524" layer="21" curve="-90"/>
<wire x1="1.651" y1="-1.143" x2="2.159" y2="-0.635" width="0.1524" layer="21" curve="90"/>
<wire x1="-0.3048" y1="0.762" x2="-0.3048" y2="0" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-0.3048" y2="-0.762" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0.762" x2="0.3302" y2="0" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="0.3302" y2="-0.762" width="0.3048" layer="21"/>
<wire x1="1.27" y1="0" x2="0.3302" y2="0" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="0" x2="-0.3048" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-2.54" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="2.54" y="0" drill="0.8128" shape="octagon"/>
<text x="-2.159" y="1.397" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.159" y="-2.667" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="2.159" y1="-0.381" x2="2.54" y2="0.381" layer="51"/>
<rectangle x1="-2.54" y1="-0.381" x2="-2.159" y2="0.381" layer="51"/>
</package>
<package name="C050-025X075" urn="urn:adsk.eagle:footprint:23148/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 5 mm, outline 2.5 x 7.5 mm</description>
<wire x1="-0.3048" y1="0.635" x2="-0.3048" y2="0" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-0.3048" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="0.3302" y1="0.635" x2="0.3302" y2="0" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="0.3302" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="-3.683" y1="1.016" x2="-3.683" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="-3.429" y1="-1.27" x2="3.429" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="3.683" y1="-1.016" x2="3.683" y2="1.016" width="0.1524" layer="21"/>
<wire x1="3.429" y1="1.27" x2="-3.429" y2="1.27" width="0.1524" layer="21"/>
<wire x1="3.429" y1="1.27" x2="3.683" y2="1.016" width="0.1524" layer="21" curve="-90"/>
<wire x1="3.429" y1="-1.27" x2="3.683" y2="-1.016" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="-1.016" x2="-3.429" y2="-1.27" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="1.016" x2="-3.429" y2="1.27" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-2.54" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="2.54" y="0" drill="0.8128" shape="octagon"/>
<text x="-3.429" y="1.651" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.429" y="-2.794" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C050-045X075" urn="urn:adsk.eagle:footprint:23149/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 5 mm, outline 4.5 x 7.5 mm</description>
<wire x1="-0.3048" y1="0.635" x2="-0.3048" y2="0" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-0.3048" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="0.3302" y1="0.635" x2="0.3302" y2="0" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="0.3302" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="-3.683" y1="2.032" x2="-3.683" y2="-2.032" width="0.1524" layer="21"/>
<wire x1="-3.429" y1="-2.286" x2="3.429" y2="-2.286" width="0.1524" layer="21"/>
<wire x1="3.683" y1="-2.032" x2="3.683" y2="2.032" width="0.1524" layer="21"/>
<wire x1="3.429" y1="2.286" x2="-3.429" y2="2.286" width="0.1524" layer="21"/>
<wire x1="3.429" y1="2.286" x2="3.683" y2="2.032" width="0.1524" layer="21" curve="-90"/>
<wire x1="3.429" y1="-2.286" x2="3.683" y2="-2.032" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="-2.032" x2="-3.429" y2="-2.286" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="2.032" x2="-3.429" y2="2.286" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-2.54" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="2.54" y="0" drill="0.8128" shape="octagon"/>
<text x="-3.556" y="2.667" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.556" y="-3.81" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C050-030X075" urn="urn:adsk.eagle:footprint:23150/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 5 mm, outline 3 x 7.5 mm</description>
<wire x1="-0.3048" y1="0.635" x2="-0.3048" y2="0" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-0.3048" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="0.3302" y1="0.635" x2="0.3302" y2="0" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="0.3302" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="-3.683" y1="1.27" x2="-3.683" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-3.429" y1="-1.524" x2="3.429" y2="-1.524" width="0.1524" layer="21"/>
<wire x1="3.683" y1="-1.27" x2="3.683" y2="1.27" width="0.1524" layer="21"/>
<wire x1="3.429" y1="1.524" x2="-3.429" y2="1.524" width="0.1524" layer="21"/>
<wire x1="3.429" y1="1.524" x2="3.683" y2="1.27" width="0.1524" layer="21" curve="-90"/>
<wire x1="3.429" y1="-1.524" x2="3.683" y2="-1.27" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="-1.27" x2="-3.429" y2="-1.524" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="1.27" x2="-3.429" y2="1.524" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-2.54" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="2.54" y="0" drill="0.8128" shape="octagon"/>
<text x="-3.556" y="1.905" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.556" y="-3.048" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C050-050X075" urn="urn:adsk.eagle:footprint:23151/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 5 mm, outline 5 x 7.5 mm</description>
<wire x1="-0.3048" y1="0.635" x2="-0.3048" y2="0" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-0.3048" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="0.3302" y1="0.635" x2="0.3302" y2="0" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="0.3302" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="-3.683" y1="2.286" x2="-3.683" y2="-2.286" width="0.1524" layer="21"/>
<wire x1="-3.429" y1="-2.54" x2="3.429" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="3.683" y1="-2.286" x2="3.683" y2="2.286" width="0.1524" layer="21"/>
<wire x1="3.429" y1="2.54" x2="-3.429" y2="2.54" width="0.1524" layer="21"/>
<wire x1="3.429" y1="2.54" x2="3.683" y2="2.286" width="0.1524" layer="21" curve="-90"/>
<wire x1="3.429" y1="-2.54" x2="3.683" y2="-2.286" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="-2.286" x2="-3.429" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="2.286" x2="-3.429" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-2.54" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="2.54" y="0" drill="0.8128" shape="octagon"/>
<text x="-3.429" y="2.921" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.175" y="-2.159" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C050-055X075" urn="urn:adsk.eagle:footprint:23152/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 5 mm, outline 5.5 x 7.5 mm</description>
<wire x1="-0.3048" y1="0.635" x2="-0.3048" y2="0" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-0.3048" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="0.3302" y1="0.635" x2="0.3302" y2="0" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="0.3302" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="-3.683" y1="2.54" x2="-3.683" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-3.429" y1="-2.794" x2="3.429" y2="-2.794" width="0.1524" layer="21"/>
<wire x1="3.683" y1="-2.54" x2="3.683" y2="2.54" width="0.1524" layer="21"/>
<wire x1="3.429" y1="2.794" x2="-3.429" y2="2.794" width="0.1524" layer="21"/>
<wire x1="3.429" y1="2.794" x2="3.683" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<wire x1="3.429" y1="-2.794" x2="3.683" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="-2.54" x2="-3.429" y2="-2.794" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="2.54" x2="-3.429" y2="2.794" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-2.54" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="2.54" y="0" drill="0.8128" shape="octagon"/>
<text x="-3.429" y="3.175" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.302" y="-2.286" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C050-075X075" urn="urn:adsk.eagle:footprint:23153/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 5 mm, outline 7.5 x 7.5 mm</description>
<wire x1="-1.524" y1="0" x2="-0.4572" y2="0" width="0.1524" layer="21"/>
<wire x1="-0.4572" y1="0" x2="-0.4572" y2="0.762" width="0.4064" layer="21"/>
<wire x1="-0.4572" y1="0" x2="-0.4572" y2="-0.762" width="0.4064" layer="21"/>
<wire x1="0.4318" y1="0.762" x2="0.4318" y2="0" width="0.4064" layer="21"/>
<wire x1="0.4318" y1="0" x2="1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="0.4318" y1="0" x2="0.4318" y2="-0.762" width="0.4064" layer="21"/>
<wire x1="-3.683" y1="3.429" x2="-3.683" y2="-3.429" width="0.1524" layer="21"/>
<wire x1="-3.429" y1="-3.683" x2="3.429" y2="-3.683" width="0.1524" layer="21"/>
<wire x1="3.683" y1="-3.429" x2="3.683" y2="3.429" width="0.1524" layer="21"/>
<wire x1="3.429" y1="3.683" x2="-3.429" y2="3.683" width="0.1524" layer="21"/>
<wire x1="3.429" y1="3.683" x2="3.683" y2="3.429" width="0.1524" layer="21" curve="-90"/>
<wire x1="3.429" y1="-3.683" x2="3.683" y2="-3.429" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="-3.429" x2="-3.429" y2="-3.683" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="3.429" x2="-3.429" y2="3.683" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-2.54" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="2.54" y="0" drill="0.8128" shape="octagon"/>
<text x="-3.429" y="4.064" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.175" y="-2.921" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C050H075X075" urn="urn:adsk.eagle:footprint:23154/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
Horizontal, grid 5 mm, outline 7.5 x 7.5 mm</description>
<wire x1="-3.683" y1="7.112" x2="-3.683" y2="0.508" width="0.1524" layer="21"/>
<wire x1="-3.683" y1="0.508" x2="-3.302" y2="0.508" width="0.1524" layer="21"/>
<wire x1="-3.302" y1="0.508" x2="-1.778" y2="0.508" width="0.1524" layer="51"/>
<wire x1="-1.778" y1="0.508" x2="1.778" y2="0.508" width="0.1524" layer="21"/>
<wire x1="1.778" y1="0.508" x2="3.302" y2="0.508" width="0.1524" layer="51"/>
<wire x1="3.302" y1="0.508" x2="3.683" y2="0.508" width="0.1524" layer="21"/>
<wire x1="3.683" y1="0.508" x2="3.683" y2="7.112" width="0.1524" layer="21"/>
<wire x1="3.175" y1="7.62" x2="-3.175" y2="7.62" width="0.1524" layer="21"/>
<wire x1="-0.3048" y1="2.413" x2="-0.3048" y2="1.778" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="1.778" x2="-0.3048" y2="1.143" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="1.778" x2="-1.651" y2="1.778" width="0.1524" layer="21"/>
<wire x1="0.3302" y1="2.413" x2="0.3302" y2="1.778" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="1.778" x2="0.3302" y2="1.143" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="1.778" x2="1.651" y2="1.778" width="0.1524" layer="21"/>
<wire x1="-3.683" y1="7.112" x2="-3.175" y2="7.62" width="0.1524" layer="21" curve="-90"/>
<wire x1="3.175" y1="7.62" x2="3.683" y2="7.112" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.54" y1="0" x2="-2.54" y2="0.254" width="0.508" layer="51"/>
<wire x1="2.54" y1="0" x2="2.54" y2="0.254" width="0.508" layer="51"/>
<pad name="1" x="-2.54" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="2.54" y="0" drill="0.8128" shape="octagon"/>
<text x="-3.302" y="8.001" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.175" y="3.175" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="-2.794" y1="0.127" x2="-2.286" y2="0.508" layer="51"/>
<rectangle x1="2.286" y1="0.127" x2="2.794" y2="0.508" layer="51"/>
</package>
<package name="C075-032X103" urn="urn:adsk.eagle:footprint:23155/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 7.5 mm, outline 3.2 x 10.3 mm</description>
<wire x1="4.826" y1="1.524" x2="-4.826" y2="1.524" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="1.27" x2="-5.08" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-4.826" y1="-1.524" x2="4.826" y2="-1.524" width="0.1524" layer="21"/>
<wire x1="5.08" y1="-1.27" x2="5.08" y2="1.27" width="0.1524" layer="21"/>
<wire x1="4.826" y1="1.524" x2="5.08" y2="1.27" width="0.1524" layer="21" curve="-90"/>
<wire x1="4.826" y1="-1.524" x2="5.08" y2="-1.27" width="0.1524" layer="21" curve="90"/>
<wire x1="-5.08" y1="-1.27" x2="-4.826" y2="-1.524" width="0.1524" layer="21" curve="90"/>
<wire x1="-5.08" y1="1.27" x2="-4.826" y2="1.524" width="0.1524" layer="21" curve="-90"/>
<wire x1="0.508" y1="0" x2="2.54" y2="0" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="0" x2="-0.508" y2="0" width="0.1524" layer="21"/>
<wire x1="-0.508" y1="0.889" x2="-0.508" y2="0" width="0.4064" layer="21"/>
<wire x1="-0.508" y1="0" x2="-0.508" y2="-0.889" width="0.4064" layer="21"/>
<wire x1="0.508" y1="0.889" x2="0.508" y2="0" width="0.4064" layer="21"/>
<wire x1="0.508" y1="0" x2="0.508" y2="-0.889" width="0.4064" layer="21"/>
<pad name="1" x="-3.81" y="0" drill="0.9144" shape="octagon"/>
<pad name="2" x="3.81" y="0" drill="0.9144" shape="octagon"/>
<text x="-4.826" y="1.905" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-4.826" y="-3.048" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C075-042X103" urn="urn:adsk.eagle:footprint:23156/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 7.5 mm, outline 4.2 x 10.3 mm</description>
<wire x1="4.826" y1="2.032" x2="-4.826" y2="2.032" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="1.778" x2="-5.08" y2="-1.778" width="0.1524" layer="21"/>
<wire x1="-4.826" y1="-2.032" x2="4.826" y2="-2.032" width="0.1524" layer="21"/>
<wire x1="5.08" y1="-1.778" x2="5.08" y2="1.778" width="0.1524" layer="21"/>
<wire x1="4.826" y1="2.032" x2="5.08" y2="1.778" width="0.1524" layer="21" curve="-90"/>
<wire x1="4.826" y1="-2.032" x2="5.08" y2="-1.778" width="0.1524" layer="21" curve="90"/>
<wire x1="-5.08" y1="-1.778" x2="-4.826" y2="-2.032" width="0.1524" layer="21" curve="90"/>
<wire x1="-5.08" y1="1.778" x2="-4.826" y2="2.032" width="0.1524" layer="21" curve="-90"/>
<wire x1="-1.27" y1="0" x2="2.667" y2="0" width="0.1524" layer="21"/>
<wire x1="-2.667" y1="0" x2="-2.159" y2="0" width="0.1524" layer="21"/>
<wire x1="-2.159" y1="1.27" x2="-2.159" y2="0" width="0.4064" layer="21"/>
<wire x1="-2.159" y1="0" x2="-2.159" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-1.27" y1="1.27" x2="-1.27" y2="0" width="0.4064" layer="21"/>
<wire x1="-1.27" y1="0" x2="-1.27" y2="-1.27" width="0.4064" layer="21"/>
<pad name="1" x="-3.81" y="0" drill="0.9144" shape="octagon"/>
<pad name="2" x="3.81" y="0" drill="0.9144" shape="octagon"/>
<text x="-4.699" y="2.413" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-0.635" y="-1.651" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C075-052X106" urn="urn:adsk.eagle:footprint:23157/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 7.5 mm, outline 5.2 x 10.6 mm</description>
<wire x1="4.953" y1="2.54" x2="-4.953" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-5.207" y1="2.286" x2="-5.207" y2="-2.286" width="0.1524" layer="21"/>
<wire x1="-4.953" y1="-2.54" x2="4.953" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="5.207" y1="-2.286" x2="5.207" y2="2.286" width="0.1524" layer="21"/>
<wire x1="4.953" y1="2.54" x2="5.207" y2="2.286" width="0.1524" layer="21" curve="-90"/>
<wire x1="4.953" y1="-2.54" x2="5.207" y2="-2.286" width="0.1524" layer="21" curve="90"/>
<wire x1="-5.207" y1="-2.286" x2="-4.953" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="-5.207" y1="2.286" x2="-4.953" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<wire x1="-1.27" y1="0" x2="2.667" y2="0" width="0.1524" layer="21"/>
<wire x1="-2.667" y1="0" x2="-2.159" y2="0" width="0.1524" layer="21"/>
<wire x1="-2.159" y1="1.27" x2="-2.159" y2="0" width="0.4064" layer="21"/>
<wire x1="-2.159" y1="0" x2="-2.159" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-1.27" y1="1.27" x2="-1.27" y2="0" width="0.4064" layer="21"/>
<wire x1="-1.27" y1="0" x2="-1.27" y2="-1.27" width="0.4064" layer="21"/>
<pad name="1" x="-3.81" y="0" drill="0.9144" shape="octagon"/>
<pad name="2" x="3.81" y="0" drill="0.9144" shape="octagon"/>
<text x="-4.826" y="2.921" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-0.635" y="-2.032" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C102-043X133" urn="urn:adsk.eagle:footprint:23158/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 10.2 mm, outline 4.3 x 13.3 mm</description>
<wire x1="-3.175" y1="1.27" x2="-3.175" y2="0" width="0.4064" layer="21"/>
<wire x1="-2.286" y1="1.27" x2="-2.286" y2="0" width="0.4064" layer="21"/>
<wire x1="3.81" y1="0" x2="-2.286" y2="0" width="0.1524" layer="21"/>
<wire x1="-2.286" y1="0" x2="-2.286" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-3.81" y1="0" x2="-3.175" y2="0" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="0" x2="-3.175" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-6.096" y1="2.032" x2="6.096" y2="2.032" width="0.1524" layer="21"/>
<wire x1="6.604" y1="1.524" x2="6.604" y2="-1.524" width="0.1524" layer="21"/>
<wire x1="6.096" y1="-2.032" x2="-6.096" y2="-2.032" width="0.1524" layer="21"/>
<wire x1="-6.604" y1="-1.524" x2="-6.604" y2="1.524" width="0.1524" layer="21"/>
<wire x1="6.096" y1="2.032" x2="6.604" y2="1.524" width="0.1524" layer="21" curve="-90"/>
<wire x1="6.096" y1="-2.032" x2="6.604" y2="-1.524" width="0.1524" layer="21" curve="90"/>
<wire x1="-6.604" y1="-1.524" x2="-6.096" y2="-2.032" width="0.1524" layer="21" curve="90"/>
<wire x1="-6.604" y1="1.524" x2="-6.096" y2="2.032" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-5.08" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="5.08" y="0" drill="1.016" shape="octagon"/>
<text x="-6.096" y="2.413" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-1.524" y="-1.651" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C102-054X133" urn="urn:adsk.eagle:footprint:23159/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 10.2 mm, outline 5.4 x 13.3 mm</description>
<wire x1="-3.175" y1="1.27" x2="-3.175" y2="0" width="0.4064" layer="21"/>
<wire x1="-2.286" y1="1.27" x2="-2.286" y2="0" width="0.4064" layer="21"/>
<wire x1="3.81" y1="0" x2="-2.286" y2="0" width="0.1524" layer="21"/>
<wire x1="-2.286" y1="0" x2="-2.286" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-3.81" y1="0" x2="-3.175" y2="0" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="0" x2="-3.175" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-6.096" y1="2.54" x2="6.096" y2="2.54" width="0.1524" layer="21"/>
<wire x1="6.604" y1="2.032" x2="6.604" y2="-2.032" width="0.1524" layer="21"/>
<wire x1="6.096" y1="-2.54" x2="-6.096" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-6.604" y1="-2.032" x2="-6.604" y2="2.032" width="0.1524" layer="21"/>
<wire x1="6.096" y1="2.54" x2="6.604" y2="2.032" width="0.1524" layer="21" curve="-90"/>
<wire x1="6.096" y1="-2.54" x2="6.604" y2="-2.032" width="0.1524" layer="21" curve="90"/>
<wire x1="-6.604" y1="-2.032" x2="-6.096" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="-6.604" y1="2.032" x2="-6.096" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-5.08" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="5.08" y="0" drill="1.016" shape="octagon"/>
<text x="-6.096" y="2.921" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-1.524" y="-1.905" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C102-064X133" urn="urn:adsk.eagle:footprint:23160/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 10.2 mm, outline 6.4 x 13.3 mm</description>
<wire x1="-3.175" y1="1.27" x2="-3.175" y2="0" width="0.4064" layer="21"/>
<wire x1="-2.286" y1="1.27" x2="-2.286" y2="0" width="0.4064" layer="21"/>
<wire x1="3.81" y1="0" x2="-2.286" y2="0" width="0.1524" layer="21"/>
<wire x1="-2.286" y1="0" x2="-2.286" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-3.81" y1="0" x2="-3.175" y2="0" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="0" x2="-3.175" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-6.096" y1="3.048" x2="6.096" y2="3.048" width="0.1524" layer="21"/>
<wire x1="6.604" y1="2.54" x2="6.604" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="6.096" y1="-3.048" x2="-6.096" y2="-3.048" width="0.1524" layer="21"/>
<wire x1="-6.604" y1="-2.54" x2="-6.604" y2="2.54" width="0.1524" layer="21"/>
<wire x1="6.096" y1="3.048" x2="6.604" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<wire x1="6.096" y1="-3.048" x2="6.604" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="-6.604" y1="-2.54" x2="-6.096" y2="-3.048" width="0.1524" layer="21" curve="90"/>
<wire x1="-6.604" y1="2.54" x2="-6.096" y2="3.048" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-5.08" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="5.08" y="0" drill="1.016" shape="octagon"/>
<text x="-6.096" y="3.429" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-1.524" y="-2.032" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C102_152-062X184" urn="urn:adsk.eagle:footprint:23161/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 10.2 mm + 15.2 mm, outline 6.2 x 18.4 mm</description>
<wire x1="-2.286" y1="1.27" x2="-2.286" y2="0" width="0.4064" layer="21"/>
<wire x1="-2.286" y1="0" x2="-2.286" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-3.175" y1="1.27" x2="-3.175" y2="0" width="0.4064" layer="21"/>
<wire x1="-3.175" y1="0" x2="-3.175" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-3.683" y1="0" x2="-3.175" y2="0" width="0.1524" layer="21"/>
<wire x1="-2.286" y1="0" x2="3.683" y2="0" width="0.1524" layer="21"/>
<wire x1="6.477" y1="0" x2="8.636" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.096" y1="3.048" x2="6.223" y2="3.048" width="0.1524" layer="21"/>
<wire x1="6.223" y1="-3.048" x2="-6.096" y2="-3.048" width="0.1524" layer="21"/>
<wire x1="-6.604" y1="-2.54" x2="-6.604" y2="2.54" width="0.1524" layer="21"/>
<wire x1="6.223" y1="3.048" x2="6.731" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<wire x1="6.223" y1="-3.048" x2="6.731" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="-6.604" y1="-2.54" x2="-6.096" y2="-3.048" width="0.1524" layer="21" curve="90"/>
<wire x1="-6.604" y1="2.54" x2="-6.096" y2="3.048" width="0.1524" layer="21" curve="-90"/>
<wire x1="6.731" y1="2.54" x2="6.731" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="11.176" y1="3.048" x2="11.684" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<wire x1="11.176" y1="-3.048" x2="11.684" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="11.176" y1="-3.048" x2="7.112" y2="-3.048" width="0.1524" layer="21"/>
<wire x1="7.112" y1="3.048" x2="11.176" y2="3.048" width="0.1524" layer="21"/>
<wire x1="11.684" y1="2.54" x2="11.684" y2="-2.54" width="0.1524" layer="21"/>
<pad name="1" x="-5.08" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="5.08" y="0" drill="1.016" shape="octagon"/>
<pad name="3" x="10.033" y="0" drill="1.016" shape="octagon"/>
<text x="-5.969" y="3.429" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-1.524" y="-2.286" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C150-054X183" urn="urn:adsk.eagle:footprint:23162/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 15 mm, outline 5.4 x 18.3 mm</description>
<wire x1="-5.08" y1="1.27" x2="-5.08" y2="0" width="0.4064" layer="21"/>
<wire x1="-5.08" y1="0" x2="-5.08" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="1.27" x2="-4.191" y2="0" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="0" x2="-4.191" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="0" x2="6.096" y2="0" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="0" x2="-6.096" y2="0" width="0.1524" layer="21"/>
<wire x1="9.017" y1="2.032" x2="9.017" y2="-2.032" width="0.1524" layer="21"/>
<wire x1="8.509" y1="-2.54" x2="-8.509" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-9.017" y1="-2.032" x2="-9.017" y2="2.032" width="0.1524" layer="21"/>
<wire x1="-8.509" y1="2.54" x2="8.509" y2="2.54" width="0.1524" layer="21"/>
<wire x1="8.509" y1="2.54" x2="9.017" y2="2.032" width="0.1524" layer="21" curve="-90"/>
<wire x1="8.509" y1="-2.54" x2="9.017" y2="-2.032" width="0.1524" layer="21" curve="90"/>
<wire x1="-9.017" y1="-2.032" x2="-8.509" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="-9.017" y1="2.032" x2="-8.509" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-7.493" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="7.493" y="0" drill="1.016" shape="octagon"/>
<text x="-8.382" y="2.921" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.429" y="-2.032" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C150-064X183" urn="urn:adsk.eagle:footprint:23163/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 15 mm, outline 6.4 x 18.3 mm</description>
<wire x1="-5.08" y1="1.27" x2="-5.08" y2="0" width="0.4064" layer="21"/>
<wire x1="-5.08" y1="0" x2="-5.08" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="1.27" x2="-4.191" y2="0" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="0" x2="-4.191" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="0" x2="6.096" y2="0" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="0" x2="-6.096" y2="0" width="0.1524" layer="21"/>
<wire x1="9.017" y1="2.54" x2="9.017" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="8.509" y1="-3.048" x2="-8.509" y2="-3.048" width="0.1524" layer="21"/>
<wire x1="-9.017" y1="-2.54" x2="-9.017" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-8.509" y1="3.048" x2="8.509" y2="3.048" width="0.1524" layer="21"/>
<wire x1="8.509" y1="3.048" x2="9.017" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<wire x1="8.509" y1="-3.048" x2="9.017" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="-9.017" y1="-2.54" x2="-8.509" y2="-3.048" width="0.1524" layer="21" curve="90"/>
<wire x1="-9.017" y1="2.54" x2="-8.509" y2="3.048" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-7.493" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="7.493" y="0" drill="1.016" shape="octagon"/>
<text x="-8.509" y="3.429" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.429" y="-2.032" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C150-072X183" urn="urn:adsk.eagle:footprint:23164/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 15 mm, outline 7.2 x 18.3 mm</description>
<wire x1="-5.08" y1="1.27" x2="-5.08" y2="0" width="0.4064" layer="21"/>
<wire x1="-5.08" y1="0" x2="-5.08" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="1.27" x2="-4.191" y2="0" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="0" x2="-4.191" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="0" x2="6.096" y2="0" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="0" x2="-6.096" y2="0" width="0.1524" layer="21"/>
<wire x1="9.017" y1="3.048" x2="9.017" y2="-3.048" width="0.1524" layer="21"/>
<wire x1="8.509" y1="-3.556" x2="-8.509" y2="-3.556" width="0.1524" layer="21"/>
<wire x1="-9.017" y1="-3.048" x2="-9.017" y2="3.048" width="0.1524" layer="21"/>
<wire x1="-8.509" y1="3.556" x2="8.509" y2="3.556" width="0.1524" layer="21"/>
<wire x1="8.509" y1="3.556" x2="9.017" y2="3.048" width="0.1524" layer="21" curve="-90"/>
<wire x1="8.509" y1="-3.556" x2="9.017" y2="-3.048" width="0.1524" layer="21" curve="90"/>
<wire x1="-9.017" y1="-3.048" x2="-8.509" y2="-3.556" width="0.1524" layer="21" curve="90"/>
<wire x1="-9.017" y1="3.048" x2="-8.509" y2="3.556" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-7.493" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="7.493" y="0" drill="1.016" shape="octagon"/>
<text x="-8.509" y="3.937" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.429" y="-2.286" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C150-084X183" urn="urn:adsk.eagle:footprint:23165/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 15 mm, outline 8.4 x 18.3 mm</description>
<wire x1="-5.08" y1="1.27" x2="-5.08" y2="0" width="0.4064" layer="21"/>
<wire x1="-5.08" y1="0" x2="-5.08" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="1.27" x2="-4.191" y2="0" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="0" x2="-4.191" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="0" x2="6.096" y2="0" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="0" x2="-6.096" y2="0" width="0.1524" layer="21"/>
<wire x1="9.017" y1="3.556" x2="9.017" y2="-3.556" width="0.1524" layer="21"/>
<wire x1="8.509" y1="-4.064" x2="-8.509" y2="-4.064" width="0.1524" layer="21"/>
<wire x1="-9.017" y1="-3.556" x2="-9.017" y2="3.556" width="0.1524" layer="21"/>
<wire x1="-8.509" y1="4.064" x2="8.509" y2="4.064" width="0.1524" layer="21"/>
<wire x1="8.509" y1="4.064" x2="9.017" y2="3.556" width="0.1524" layer="21" curve="-90"/>
<wire x1="8.509" y1="-4.064" x2="9.017" y2="-3.556" width="0.1524" layer="21" curve="90"/>
<wire x1="-9.017" y1="-3.556" x2="-8.509" y2="-4.064" width="0.1524" layer="21" curve="90"/>
<wire x1="-9.017" y1="3.556" x2="-8.509" y2="4.064" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-7.493" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="7.493" y="0" drill="1.016" shape="octagon"/>
<text x="-8.509" y="4.445" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.429" y="-2.54" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C150-091X182" urn="urn:adsk.eagle:footprint:23166/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 15 mm, outline 9.1 x 18.2 mm</description>
<wire x1="-5.08" y1="1.27" x2="-5.08" y2="0" width="0.4064" layer="21"/>
<wire x1="-5.08" y1="0" x2="-5.08" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="1.27" x2="-4.191" y2="0" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="0" x2="-4.191" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="0" x2="6.096" y2="0" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="0" x2="-6.096" y2="0" width="0.1524" layer="21"/>
<wire x1="9.017" y1="3.937" x2="9.017" y2="-3.937" width="0.1524" layer="21"/>
<wire x1="8.509" y1="-4.445" x2="-8.509" y2="-4.445" width="0.1524" layer="21"/>
<wire x1="-9.017" y1="-3.937" x2="-9.017" y2="3.937" width="0.1524" layer="21"/>
<wire x1="-8.509" y1="4.445" x2="8.509" y2="4.445" width="0.1524" layer="21"/>
<wire x1="8.509" y1="4.445" x2="9.017" y2="3.937" width="0.1524" layer="21" curve="-90"/>
<wire x1="8.509" y1="-4.445" x2="9.017" y2="-3.937" width="0.1524" layer="21" curve="90"/>
<wire x1="-9.017" y1="-3.937" x2="-8.509" y2="-4.445" width="0.1524" layer="21" curve="90"/>
<wire x1="-9.017" y1="3.937" x2="-8.509" y2="4.445" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-7.493" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="7.493" y="0" drill="1.016" shape="octagon"/>
<text x="-8.509" y="4.826" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.429" y="-2.54" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C225-062X268" urn="urn:adsk.eagle:footprint:23167/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 22.5 mm, outline 6.2 x 26.8 mm</description>
<wire x1="-12.827" y1="3.048" x2="12.827" y2="3.048" width="0.1524" layer="21"/>
<wire x1="13.335" y1="2.54" x2="13.335" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="12.827" y1="-3.048" x2="-12.827" y2="-3.048" width="0.1524" layer="21"/>
<wire x1="-13.335" y1="-2.54" x2="-13.335" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="12.827" y1="3.048" x2="13.335" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<wire x1="12.827" y1="-3.048" x2="13.335" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="-13.335" y1="-2.54" x2="-12.827" y2="-3.048" width="0.1524" layer="21" curve="90"/>
<wire x1="-13.335" y1="2.54" x2="-12.827" y2="3.048" width="0.1524" layer="21" curve="-90"/>
<wire x1="-9.652" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="9.652" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-11.303" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="11.303" y="0" drill="1.016" shape="octagon"/>
<text x="-12.7" y="3.429" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C225-074X268" urn="urn:adsk.eagle:footprint:23168/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 22.5 mm, outline 7.4 x 26.8 mm</description>
<wire x1="-12.827" y1="3.556" x2="12.827" y2="3.556" width="0.1524" layer="21"/>
<wire x1="13.335" y1="3.048" x2="13.335" y2="-3.048" width="0.1524" layer="21"/>
<wire x1="12.827" y1="-3.556" x2="-12.827" y2="-3.556" width="0.1524" layer="21"/>
<wire x1="-13.335" y1="-3.048" x2="-13.335" y2="3.048" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="12.827" y1="3.556" x2="13.335" y2="3.048" width="0.1524" layer="21" curve="-90"/>
<wire x1="12.827" y1="-3.556" x2="13.335" y2="-3.048" width="0.1524" layer="21" curve="90"/>
<wire x1="-13.335" y1="-3.048" x2="-12.827" y2="-3.556" width="0.1524" layer="21" curve="90"/>
<wire x1="-13.335" y1="3.048" x2="-12.827" y2="3.556" width="0.1524" layer="21" curve="-90"/>
<wire x1="-9.652" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="9.652" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-11.303" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="11.303" y="0" drill="1.016" shape="octagon"/>
<text x="-12.827" y="3.937" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C225-087X268" urn="urn:adsk.eagle:footprint:23169/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 22.5 mm, outline 8.7 x 26.8 mm</description>
<wire x1="-12.827" y1="4.318" x2="12.827" y2="4.318" width="0.1524" layer="21"/>
<wire x1="13.335" y1="3.81" x2="13.335" y2="-3.81" width="0.1524" layer="21"/>
<wire x1="12.827" y1="-4.318" x2="-12.827" y2="-4.318" width="0.1524" layer="21"/>
<wire x1="-13.335" y1="-3.81" x2="-13.335" y2="3.81" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="12.827" y1="4.318" x2="13.335" y2="3.81" width="0.1524" layer="21" curve="-90"/>
<wire x1="12.827" y1="-4.318" x2="13.335" y2="-3.81" width="0.1524" layer="21" curve="90"/>
<wire x1="-13.335" y1="-3.81" x2="-12.827" y2="-4.318" width="0.1524" layer="21" curve="90"/>
<wire x1="-13.335" y1="3.81" x2="-12.827" y2="4.318" width="0.1524" layer="21" curve="-90"/>
<wire x1="-9.652" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="9.652" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-11.303" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="11.303" y="0" drill="1.016" shape="octagon"/>
<text x="-12.827" y="4.699" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C225-108X268" urn="urn:adsk.eagle:footprint:23170/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 22.5 mm, outline 10.8 x 26.8 mm</description>
<wire x1="-12.827" y1="5.334" x2="12.827" y2="5.334" width="0.1524" layer="21"/>
<wire x1="13.335" y1="4.826" x2="13.335" y2="-4.826" width="0.1524" layer="21"/>
<wire x1="12.827" y1="-5.334" x2="-12.827" y2="-5.334" width="0.1524" layer="21"/>
<wire x1="-13.335" y1="-4.826" x2="-13.335" y2="4.826" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="12.827" y1="5.334" x2="13.335" y2="4.826" width="0.1524" layer="21" curve="-90"/>
<wire x1="12.827" y1="-5.334" x2="13.335" y2="-4.826" width="0.1524" layer="21" curve="90"/>
<wire x1="-13.335" y1="-4.826" x2="-12.827" y2="-5.334" width="0.1524" layer="21" curve="90"/>
<wire x1="-13.335" y1="4.826" x2="-12.827" y2="5.334" width="0.1524" layer="21" curve="-90"/>
<wire x1="-9.652" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="9.652" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-11.303" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="11.303" y="0" drill="1.016" shape="octagon"/>
<text x="-12.954" y="5.715" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C225-113X268" urn="urn:adsk.eagle:footprint:23171/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 22.5 mm, outline 11.3 x 26.8 mm</description>
<wire x1="-12.827" y1="5.588" x2="12.827" y2="5.588" width="0.1524" layer="21"/>
<wire x1="13.335" y1="5.08" x2="13.335" y2="-5.08" width="0.1524" layer="21"/>
<wire x1="12.827" y1="-5.588" x2="-12.827" y2="-5.588" width="0.1524" layer="21"/>
<wire x1="-13.335" y1="-5.08" x2="-13.335" y2="5.08" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="12.827" y1="5.588" x2="13.335" y2="5.08" width="0.1524" layer="21" curve="-90"/>
<wire x1="12.827" y1="-5.588" x2="13.335" y2="-5.08" width="0.1524" layer="21" curve="90"/>
<wire x1="-13.335" y1="-5.08" x2="-12.827" y2="-5.588" width="0.1524" layer="21" curve="90"/>
<wire x1="-13.335" y1="5.08" x2="-12.827" y2="5.588" width="0.1524" layer="21" curve="-90"/>
<wire x1="-9.652" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="9.652" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-11.303" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="11.303" y="0" drill="1.016" shape="octagon"/>
<text x="-12.954" y="5.969" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C275-093X316" urn="urn:adsk.eagle:footprint:23172/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 27.5 mm, outline 9.3 x 31.6 mm</description>
<wire x1="-15.24" y1="4.572" x2="15.24" y2="4.572" width="0.1524" layer="21"/>
<wire x1="15.748" y1="4.064" x2="15.748" y2="-4.064" width="0.1524" layer="21"/>
<wire x1="15.24" y1="-4.572" x2="-15.24" y2="-4.572" width="0.1524" layer="21"/>
<wire x1="-15.748" y1="-4.064" x2="-15.748" y2="4.064" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="15.24" y1="4.572" x2="15.748" y2="4.064" width="0.1524" layer="21" curve="-90"/>
<wire x1="15.24" y1="-4.572" x2="15.748" y2="-4.064" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="-4.064" x2="-15.24" y2="-4.572" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="4.064" x2="-15.24" y2="4.572" width="0.1524" layer="21" curve="-90"/>
<wire x1="-11.557" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="11.557" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-13.716" y="0" drill="1.1938" shape="octagon"/>
<pad name="2" x="13.716" y="0" drill="1.1938" shape="octagon"/>
<text x="-15.24" y="4.953" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C275-113X316" urn="urn:adsk.eagle:footprint:23173/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 27.5 mm, outline 11.3 x 31.6 mm</description>
<wire x1="-15.24" y1="5.588" x2="15.24" y2="5.588" width="0.1524" layer="21"/>
<wire x1="15.748" y1="5.08" x2="15.748" y2="-5.08" width="0.1524" layer="21"/>
<wire x1="15.24" y1="-5.588" x2="-15.24" y2="-5.588" width="0.1524" layer="21"/>
<wire x1="-15.748" y1="-5.08" x2="-15.748" y2="5.08" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="15.24" y1="5.588" x2="15.748" y2="5.08" width="0.1524" layer="21" curve="-90"/>
<wire x1="15.24" y1="-5.588" x2="15.748" y2="-5.08" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="-5.08" x2="-15.24" y2="-5.588" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="5.08" x2="-15.24" y2="5.588" width="0.1524" layer="21" curve="-90"/>
<wire x1="-11.557" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="11.557" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-13.716" y="0" drill="1.1938" shape="octagon"/>
<pad name="2" x="13.716" y="0" drill="1.1938" shape="octagon"/>
<text x="-15.24" y="5.969" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C275-134X316" urn="urn:adsk.eagle:footprint:23174/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 27.5 mm, outline 13.4 x 31.6 mm</description>
<wire x1="-15.24" y1="6.604" x2="15.24" y2="6.604" width="0.1524" layer="21"/>
<wire x1="15.748" y1="6.096" x2="15.748" y2="-6.096" width="0.1524" layer="21"/>
<wire x1="15.24" y1="-6.604" x2="-15.24" y2="-6.604" width="0.1524" layer="21"/>
<wire x1="-15.748" y1="-6.096" x2="-15.748" y2="6.096" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="15.24" y1="6.604" x2="15.748" y2="6.096" width="0.1524" layer="21" curve="-90"/>
<wire x1="15.24" y1="-6.604" x2="15.748" y2="-6.096" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="-6.096" x2="-15.24" y2="-6.604" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="6.096" x2="-15.24" y2="6.604" width="0.1524" layer="21" curve="-90"/>
<wire x1="-11.557" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="11.557" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-13.716" y="0" drill="1.1938" shape="octagon"/>
<pad name="2" x="13.716" y="0" drill="1.1938" shape="octagon"/>
<text x="-15.24" y="6.985" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C275-205X316" urn="urn:adsk.eagle:footprint:23175/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 27.5 mm, outline 20.5 x 31.6 mm</description>
<wire x1="-15.24" y1="10.16" x2="15.24" y2="10.16" width="0.1524" layer="21"/>
<wire x1="15.748" y1="9.652" x2="15.748" y2="-9.652" width="0.1524" layer="21"/>
<wire x1="15.24" y1="-10.16" x2="-15.24" y2="-10.16" width="0.1524" layer="21"/>
<wire x1="-15.748" y1="-9.652" x2="-15.748" y2="9.652" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="15.24" y1="10.16" x2="15.748" y2="9.652" width="0.1524" layer="21" curve="-90"/>
<wire x1="15.24" y1="-10.16" x2="15.748" y2="-9.652" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="-9.652" x2="-15.24" y2="-10.16" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="9.652" x2="-15.24" y2="10.16" width="0.1524" layer="21" curve="-90"/>
<wire x1="-11.557" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="11.557" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-13.716" y="0" drill="1.1938" shape="octagon"/>
<pad name="2" x="13.716" y="0" drill="1.1938" shape="octagon"/>
<text x="-15.24" y="10.541" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-4.318" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C325-137X374" urn="urn:adsk.eagle:footprint:23176/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 32.5 mm, outline 13.7 x 37.4 mm</description>
<wire x1="-14.2748" y1="0" x2="-12.7" y2="0" width="0.1524" layer="21"/>
<wire x1="-12.7" y1="1.905" x2="-12.7" y2="0" width="0.4064" layer="21"/>
<wire x1="-11.811" y1="1.905" x2="-11.811" y2="0" width="0.4064" layer="21"/>
<wire x1="-11.811" y1="0" x2="14.2748" y2="0" width="0.1524" layer="21"/>
<wire x1="-11.811" y1="0" x2="-11.811" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-12.7" y1="0" x2="-12.7" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="18.542" y1="6.731" x2="18.542" y2="-6.731" width="0.1524" layer="21"/>
<wire x1="-18.542" y1="6.731" x2="-18.542" y2="-6.731" width="0.1524" layer="21"/>
<wire x1="-18.542" y1="-6.731" x2="18.542" y2="-6.731" width="0.1524" layer="21"/>
<wire x1="18.542" y1="6.731" x2="-18.542" y2="6.731" width="0.1524" layer="21"/>
<pad name="1" x="-16.256" y="0" drill="1.1938" shape="octagon"/>
<pad name="2" x="16.256" y="0" drill="1.1938" shape="octagon"/>
<text x="-18.2372" y="7.0612" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-10.8458" y="-2.8702" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C325-162X374" urn="urn:adsk.eagle:footprint:23177/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 32.5 mm, outline 16.2 x 37.4 mm</description>
<wire x1="-14.2748" y1="0" x2="-12.7" y2="0" width="0.1524" layer="21"/>
<wire x1="-12.7" y1="1.905" x2="-12.7" y2="0" width="0.4064" layer="21"/>
<wire x1="-11.811" y1="1.905" x2="-11.811" y2="0" width="0.4064" layer="21"/>
<wire x1="-11.811" y1="0" x2="14.2748" y2="0" width="0.1524" layer="21"/>
<wire x1="-11.811" y1="0" x2="-11.811" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-12.7" y1="0" x2="-12.7" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="18.542" y1="8.001" x2="18.542" y2="-8.001" width="0.1524" layer="21"/>
<wire x1="-18.542" y1="8.001" x2="-18.542" y2="-8.001" width="0.1524" layer="21"/>
<wire x1="-18.542" y1="-8.001" x2="18.542" y2="-8.001" width="0.1524" layer="21"/>
<wire x1="18.542" y1="8.001" x2="-18.542" y2="8.001" width="0.1524" layer="21"/>
<pad name="1" x="-16.256" y="0" drill="1.1938" shape="octagon"/>
<pad name="2" x="16.256" y="0" drill="1.1938" shape="octagon"/>
<text x="-18.3642" y="8.3312" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-10.8458" y="-2.8702" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C325-182X374" urn="urn:adsk.eagle:footprint:23178/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 32.5 mm, outline 18.2 x 37.4 mm</description>
<wire x1="-14.2748" y1="0" x2="-12.7" y2="0" width="0.1524" layer="21"/>
<wire x1="-12.7" y1="1.905" x2="-12.7" y2="0" width="0.4064" layer="21"/>
<wire x1="-11.811" y1="1.905" x2="-11.811" y2="0" width="0.4064" layer="21"/>
<wire x1="-11.811" y1="0" x2="14.2748" y2="0" width="0.1524" layer="21"/>
<wire x1="-11.811" y1="0" x2="-11.811" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-12.7" y1="0" x2="-12.7" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="18.542" y1="9.017" x2="18.542" y2="-9.017" width="0.1524" layer="21"/>
<wire x1="-18.542" y1="9.017" x2="-18.542" y2="-9.017" width="0.1524" layer="21"/>
<wire x1="-18.542" y1="-9.017" x2="18.542" y2="-9.017" width="0.1524" layer="21"/>
<wire x1="18.542" y1="9.017" x2="-18.542" y2="9.017" width="0.1524" layer="21"/>
<pad name="1" x="-16.256" y="0" drill="1.1938" shape="octagon"/>
<pad name="2" x="16.256" y="0" drill="1.1938" shape="octagon"/>
<text x="-18.3642" y="9.3472" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-10.8458" y="-2.8702" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C375-192X418" urn="urn:adsk.eagle:footprint:23179/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 37.5 mm, outline 19.2 x 41.8 mm</description>
<wire x1="-20.32" y1="8.509" x2="20.32" y2="8.509" width="0.1524" layer="21"/>
<wire x1="20.828" y1="8.001" x2="20.828" y2="-8.001" width="0.1524" layer="21"/>
<wire x1="20.32" y1="-8.509" x2="-20.32" y2="-8.509" width="0.1524" layer="21"/>
<wire x1="-20.828" y1="-8.001" x2="-20.828" y2="8.001" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="20.32" y1="8.509" x2="20.828" y2="8.001" width="0.1524" layer="21" curve="-90"/>
<wire x1="20.32" y1="-8.509" x2="20.828" y2="-8.001" width="0.1524" layer="21" curve="90"/>
<wire x1="-20.828" y1="-8.001" x2="-20.32" y2="-8.509" width="0.1524" layer="21" curve="90"/>
<wire x1="-20.828" y1="8.001" x2="-20.32" y2="8.509" width="0.1524" layer="21" curve="-90"/>
<wire x1="-16.002" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="16.002" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-18.796" y="0" drill="1.3208" shape="octagon"/>
<pad name="2" x="18.796" y="0" drill="1.3208" shape="octagon"/>
<text x="-20.447" y="8.89" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C375-203X418" urn="urn:adsk.eagle:footprint:23180/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 37.5 mm, outline 20.3 x 41.8 mm</description>
<wire x1="-20.32" y1="10.16" x2="20.32" y2="10.16" width="0.1524" layer="21"/>
<wire x1="20.828" y1="9.652" x2="20.828" y2="-9.652" width="0.1524" layer="21"/>
<wire x1="20.32" y1="-10.16" x2="-20.32" y2="-10.16" width="0.1524" layer="21"/>
<wire x1="-20.828" y1="-9.652" x2="-20.828" y2="9.652" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="20.32" y1="10.16" x2="20.828" y2="9.652" width="0.1524" layer="21" curve="-90"/>
<wire x1="20.32" y1="-10.16" x2="20.828" y2="-9.652" width="0.1524" layer="21" curve="90"/>
<wire x1="-20.828" y1="-9.652" x2="-20.32" y2="-10.16" width="0.1524" layer="21" curve="90"/>
<wire x1="-20.828" y1="9.652" x2="-20.32" y2="10.16" width="0.1524" layer="21" curve="-90"/>
<wire x1="-16.002" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="16.002" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-18.796" y="0" drill="1.3208" shape="octagon"/>
<pad name="2" x="18.796" y="0" drill="1.3208" shape="octagon"/>
<text x="-20.32" y="10.541" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C050-035X075" urn="urn:adsk.eagle:footprint:23181/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 5 mm, outline 3.5 x 7.5 mm</description>
<wire x1="-0.3048" y1="0.635" x2="-0.3048" y2="0" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-0.3048" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="0.3302" y1="0.635" x2="0.3302" y2="0" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="0.3302" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="-3.683" y1="1.524" x2="-3.683" y2="-1.524" width="0.1524" layer="21"/>
<wire x1="-3.429" y1="-1.778" x2="3.429" y2="-1.778" width="0.1524" layer="21"/>
<wire x1="3.683" y1="-1.524" x2="3.683" y2="1.524" width="0.1524" layer="21"/>
<wire x1="3.429" y1="1.778" x2="-3.429" y2="1.778" width="0.1524" layer="21"/>
<wire x1="3.429" y1="1.778" x2="3.683" y2="1.524" width="0.1524" layer="21" curve="-90"/>
<wire x1="3.429" y1="-1.778" x2="3.683" y2="-1.524" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="-1.524" x2="-3.429" y2="-1.778" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="1.524" x2="-3.429" y2="1.778" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-2.54" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="2.54" y="0" drill="0.8128" shape="octagon"/>
<text x="-3.556" y="2.159" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.556" y="-3.429" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C375-155X418" urn="urn:adsk.eagle:footprint:23182/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 37.5 mm, outline 15.5 x 41.8 mm</description>
<wire x1="-20.32" y1="7.62" x2="20.32" y2="7.62" width="0.1524" layer="21"/>
<wire x1="20.828" y1="7.112" x2="20.828" y2="-7.112" width="0.1524" layer="21"/>
<wire x1="20.32" y1="-7.62" x2="-20.32" y2="-7.62" width="0.1524" layer="21"/>
<wire x1="-20.828" y1="-7.112" x2="-20.828" y2="7.112" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="20.32" y1="7.62" x2="20.828" y2="7.112" width="0.1524" layer="21" curve="-90"/>
<wire x1="20.32" y1="-7.62" x2="20.828" y2="-7.112" width="0.1524" layer="21" curve="90"/>
<wire x1="-20.828" y1="-7.112" x2="-20.32" y2="-7.62" width="0.1524" layer="21" curve="90"/>
<wire x1="-20.828" y1="7.112" x2="-20.32" y2="7.62" width="0.1524" layer="21" curve="-90"/>
<wire x1="-16.002" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="16.002" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-18.796" y="0" drill="1.3208" shape="octagon"/>
<pad name="2" x="18.796" y="0" drill="1.3208" shape="octagon"/>
<text x="-20.447" y="8.001" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C075-063X106" urn="urn:adsk.eagle:footprint:23183/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 7.5 mm, outline 6.3 x 10.6 mm</description>
<wire x1="4.953" y1="3.048" x2="-4.953" y2="3.048" width="0.1524" layer="21"/>
<wire x1="-5.207" y1="2.794" x2="-5.207" y2="-2.794" width="0.1524" layer="21"/>
<wire x1="-4.953" y1="-3.048" x2="4.953" y2="-3.048" width="0.1524" layer="21"/>
<wire x1="5.207" y1="-2.794" x2="5.207" y2="2.794" width="0.1524" layer="21"/>
<wire x1="4.953" y1="3.048" x2="5.207" y2="2.794" width="0.1524" layer="21" curve="-90"/>
<wire x1="4.953" y1="-3.048" x2="5.207" y2="-2.794" width="0.1524" layer="21" curve="90"/>
<wire x1="-5.207" y1="-2.794" x2="-4.953" y2="-3.048" width="0.1524" layer="21" curve="90"/>
<wire x1="-5.207" y1="2.794" x2="-4.953" y2="3.048" width="0.1524" layer="21" curve="-90"/>
<wire x1="-1.27" y1="0" x2="2.667" y2="0" width="0.1524" layer="21"/>
<wire x1="-2.667" y1="0" x2="-2.159" y2="0" width="0.1524" layer="21"/>
<wire x1="-2.159" y1="1.27" x2="-2.159" y2="0" width="0.4064" layer="21"/>
<wire x1="-2.159" y1="0" x2="-2.159" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-1.27" y1="1.27" x2="-1.27" y2="0" width="0.4064" layer="21"/>
<wire x1="-1.27" y1="0" x2="-1.27" y2="-1.27" width="0.4064" layer="21"/>
<pad name="1" x="-3.81" y="0" drill="0.9144" shape="octagon"/>
<pad name="2" x="3.81" y="0" drill="0.9144" shape="octagon"/>
<text x="-4.826" y="3.429" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-0.635" y="-2.54" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C275-154X316" urn="urn:adsk.eagle:footprint:23184/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 27.5 mm, outline 15.4 x 31.6 mm</description>
<wire x1="-15.24" y1="7.62" x2="15.24" y2="7.62" width="0.1524" layer="21"/>
<wire x1="15.748" y1="7.112" x2="15.748" y2="-7.112" width="0.1524" layer="21"/>
<wire x1="15.24" y1="-7.62" x2="-15.24" y2="-7.62" width="0.1524" layer="21"/>
<wire x1="-15.748" y1="-7.112" x2="-15.748" y2="7.112" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="15.24" y1="7.62" x2="15.748" y2="7.112" width="0.1524" layer="21" curve="-90"/>
<wire x1="15.24" y1="-7.62" x2="15.748" y2="-7.112" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="-7.112" x2="-15.24" y2="-7.62" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="7.112" x2="-15.24" y2="7.62" width="0.1524" layer="21" curve="-90"/>
<wire x1="-11.557" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="11.557" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-13.716" y="0" drill="1.1938" shape="octagon"/>
<pad name="2" x="13.716" y="0" drill="1.1938" shape="octagon"/>
<text x="-15.24" y="8.001" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C275-173X316" urn="urn:adsk.eagle:footprint:23185/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 27.5 mm, outline 17.3 x 31.6 mm</description>
<wire x1="-15.24" y1="8.509" x2="15.24" y2="8.509" width="0.1524" layer="21"/>
<wire x1="15.748" y1="8.001" x2="15.748" y2="-8.001" width="0.1524" layer="21"/>
<wire x1="15.24" y1="-8.509" x2="-15.24" y2="-8.509" width="0.1524" layer="21"/>
<wire x1="-15.748" y1="-8.001" x2="-15.748" y2="8.001" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="15.24" y1="8.509" x2="15.748" y2="8.001" width="0.1524" layer="21" curve="-90"/>
<wire x1="15.24" y1="-8.509" x2="15.748" y2="-8.001" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="-8.001" x2="-15.24" y2="-8.509" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="8.001" x2="-15.24" y2="8.509" width="0.1524" layer="21" curve="-90"/>
<wire x1="-11.557" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="11.557" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-13.716" y="0" drill="1.1938" shape="octagon"/>
<pad name="2" x="13.716" y="0" drill="1.1938" shape="octagon"/>
<text x="-15.24" y="8.89" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C0402K" urn="urn:adsk.eagle:footprint:23186/1" library_version="11">
<description>&lt;b&gt;Ceramic Chip Capacitor KEMET 0204 reflow solder&lt;/b&gt;&lt;p&gt;
Metric Code Size 1005</description>
<wire x1="-0.425" y1="0.2" x2="0.425" y2="0.2" width="0.1016" layer="51"/>
<wire x1="0.425" y1="-0.2" x2="-0.425" y2="-0.2" width="0.1016" layer="51"/>
<smd name="1" x="-0.6" y="0" dx="0.925" dy="0.74" layer="1"/>
<smd name="2" x="0.6" y="0" dx="0.925" dy="0.74" layer="1"/>
<text x="-0.5" y="0.425" size="1.016" layer="25">&gt;NAME</text>
<text x="-0.5" y="-1.45" size="1.016" layer="27">&gt;VALUE</text>
<rectangle x1="-0.5" y1="-0.25" x2="-0.225" y2="0.25" layer="51"/>
<rectangle x1="0.225" y1="-0.25" x2="0.5" y2="0.25" layer="51"/>
</package>
<package name="C0603K" urn="urn:adsk.eagle:footprint:23187/1" library_version="11">
<description>&lt;b&gt;Ceramic Chip Capacitor KEMET 0603 reflow solder&lt;/b&gt;&lt;p&gt;
Metric Code Size 1608</description>
<wire x1="-0.725" y1="0.35" x2="0.725" y2="0.35" width="0.1016" layer="51"/>
<wire x1="0.725" y1="-0.35" x2="-0.725" y2="-0.35" width="0.1016" layer="51"/>
<smd name="1" x="-0.875" y="0" dx="1.05" dy="1.08" layer="1"/>
<smd name="2" x="0.875" y="0" dx="1.05" dy="1.08" layer="1"/>
<text x="-0.8" y="0.65" size="1.016" layer="25">&gt;NAME</text>
<text x="-0.8" y="-1.65" size="1.016" layer="27">&gt;VALUE</text>
<rectangle x1="-0.8" y1="-0.4" x2="-0.45" y2="0.4" layer="51"/>
<rectangle x1="0.45" y1="-0.4" x2="0.8" y2="0.4" layer="51"/>
</package>
<package name="C0805K" urn="urn:adsk.eagle:footprint:23188/1" library_version="11">
<description>&lt;b&gt;Ceramic Chip Capacitor KEMET 0805 reflow solder&lt;/b&gt;&lt;p&gt;
Metric Code Size 2012</description>
<wire x1="-0.925" y1="0.6" x2="0.925" y2="0.6" width="0.1016" layer="51"/>
<wire x1="0.925" y1="-0.6" x2="-0.925" y2="-0.6" width="0.1016" layer="51"/>
<smd name="1" x="-1" y="0" dx="1.3" dy="1.6" layer="1"/>
<smd name="2" x="1" y="0" dx="1.3" dy="1.6" layer="1"/>
<text x="-1" y="0.875" size="1.016" layer="25">&gt;NAME</text>
<text x="-1" y="-1.9" size="1.016" layer="27">&gt;VALUE</text>
<rectangle x1="-1" y1="-0.65" x2="-0.5" y2="0.65" layer="51"/>
<rectangle x1="0.5" y1="-0.65" x2="1" y2="0.65" layer="51"/>
</package>
<package name="C1206K" urn="urn:adsk.eagle:footprint:23189/1" library_version="11">
<description>&lt;b&gt;Ceramic Chip Capacitor KEMET 1206 reflow solder&lt;/b&gt;&lt;p&gt;
Metric Code Size 3216</description>
<wire x1="-1.525" y1="0.75" x2="1.525" y2="0.75" width="0.1016" layer="51"/>
<wire x1="1.525" y1="-0.75" x2="-1.525" y2="-0.75" width="0.1016" layer="51"/>
<smd name="1" x="-1.5" y="0" dx="1.5" dy="2" layer="1"/>
<smd name="2" x="1.5" y="0" dx="1.5" dy="2" layer="1"/>
<text x="-1.6" y="1.1" size="1.016" layer="25">&gt;NAME</text>
<text x="-1.6" y="-2.1" size="1.016" layer="27">&gt;VALUE</text>
<rectangle x1="-1.6" y1="-0.8" x2="-1.1" y2="0.8" layer="51"/>
<rectangle x1="1.1" y1="-0.8" x2="1.6" y2="0.8" layer="51"/>
</package>
<package name="C1210K" urn="urn:adsk.eagle:footprint:23190/1" library_version="11">
<description>&lt;b&gt;Ceramic Chip Capacitor KEMET 1210 reflow solder&lt;/b&gt;&lt;p&gt;
Metric Code Size 3225</description>
<wire x1="-1.525" y1="1.175" x2="1.525" y2="1.175" width="0.1016" layer="51"/>
<wire x1="1.525" y1="-1.175" x2="-1.525" y2="-1.175" width="0.1016" layer="51"/>
<smd name="1" x="-1.5" y="0" dx="1.5" dy="2.9" layer="1"/>
<smd name="2" x="1.5" y="0" dx="1.5" dy="2.9" layer="1"/>
<text x="-1.6" y="1.55" size="1.016" layer="25">&gt;NAME</text>
<text x="-1.6" y="-2.575" size="1.016" layer="27">&gt;VALUE</text>
<rectangle x1="-1.6" y1="-1.25" x2="-1.1" y2="1.25" layer="51"/>
<rectangle x1="1.1" y1="-1.25" x2="1.6" y2="1.25" layer="51"/>
</package>
<package name="C1812K" urn="urn:adsk.eagle:footprint:23191/1" library_version="11">
<description>&lt;b&gt;Ceramic Chip Capacitor KEMET 1812 reflow solder&lt;/b&gt;&lt;p&gt;
Metric Code Size 4532</description>
<wire x1="-2.175" y1="1.525" x2="2.175" y2="1.525" width="0.1016" layer="51"/>
<wire x1="2.175" y1="-1.525" x2="-2.175" y2="-1.525" width="0.1016" layer="51"/>
<smd name="1" x="-2.05" y="0" dx="1.8" dy="3.7" layer="1"/>
<smd name="2" x="2.05" y="0" dx="1.8" dy="3.7" layer="1"/>
<text x="-2.25" y="1.95" size="1.016" layer="25">&gt;NAME</text>
<text x="-2.25" y="-2.975" size="1.016" layer="27">&gt;VALUE</text>
<rectangle x1="-2.25" y1="-1.6" x2="-1.65" y2="1.6" layer="51"/>
<rectangle x1="1.65" y1="-1.6" x2="2.25" y2="1.6" layer="51"/>
</package>
<package name="C1825K" urn="urn:adsk.eagle:footprint:23192/1" library_version="11">
<description>&lt;b&gt;Ceramic Chip Capacitor KEMET 1825 reflow solder&lt;/b&gt;&lt;p&gt;
Metric Code Size 4564</description>
<wire x1="-1.525" y1="3.125" x2="1.525" y2="3.125" width="0.1016" layer="51"/>
<wire x1="1.525" y1="-3.125" x2="-1.525" y2="-3.125" width="0.1016" layer="51"/>
<smd name="1" x="-1.5" y="0" dx="1.8" dy="6.9" layer="1"/>
<smd name="2" x="1.5" y="0" dx="1.8" dy="6.9" layer="1"/>
<text x="-1.6" y="3.55" size="1.016" layer="25">&gt;NAME</text>
<text x="-1.6" y="-4.625" size="1.016" layer="27">&gt;VALUE</text>
<rectangle x1="-1.6" y1="-3.2" x2="-1.1" y2="3.2" layer="51"/>
<rectangle x1="1.1" y1="-3.2" x2="1.6" y2="3.2" layer="51"/>
</package>
<package name="C2220K" urn="urn:adsk.eagle:footprint:23193/1" library_version="11">
<description>&lt;b&gt;Ceramic Chip Capacitor KEMET 2220 reflow solder&lt;/b&gt;&lt;p&gt;Metric Code Size 5650</description>
<wire x1="-2.725" y1="2.425" x2="2.725" y2="2.425" width="0.1016" layer="51"/>
<wire x1="2.725" y1="-2.425" x2="-2.725" y2="-2.425" width="0.1016" layer="51"/>
<smd name="1" x="-2.55" y="0" dx="1.85" dy="5.5" layer="1"/>
<smd name="2" x="2.55" y="0" dx="1.85" dy="5.5" layer="1"/>
<text x="-2.8" y="2.95" size="1.016" layer="25">&gt;NAME</text>
<text x="-2.8" y="-3.975" size="1.016" layer="27">&gt;VALUE</text>
<rectangle x1="-2.8" y1="-2.5" x2="-2.2" y2="2.5" layer="51"/>
<rectangle x1="2.2" y1="-2.5" x2="2.8" y2="2.5" layer="51"/>
</package>
<package name="C2225K" urn="urn:adsk.eagle:footprint:23194/1" library_version="11">
<description>&lt;b&gt;Ceramic Chip Capacitor KEMET 2225 reflow solder&lt;/b&gt;&lt;p&gt;Metric Code Size 5664</description>
<wire x1="-2.725" y1="3.075" x2="2.725" y2="3.075" width="0.1016" layer="51"/>
<wire x1="2.725" y1="-3.075" x2="-2.725" y2="-3.075" width="0.1016" layer="51"/>
<smd name="1" x="-2.55" y="0" dx="1.85" dy="6.8" layer="1"/>
<smd name="2" x="2.55" y="0" dx="1.85" dy="6.8" layer="1"/>
<text x="-2.8" y="3.6" size="1.016" layer="25">&gt;NAME</text>
<text x="-2.8" y="-4.575" size="1.016" layer="27">&gt;VALUE</text>
<rectangle x1="-2.8" y1="-3.15" x2="-2.2" y2="3.15" layer="51"/>
<rectangle x1="2.2" y1="-3.15" x2="2.8" y2="3.15" layer="51"/>
</package>
<package name="C0201" urn="urn:adsk.eagle:footprint:23196/1" library_version="11">
<description>Source: http://www.avxcorp.com/docs/catalogs/cx5r.pdf</description>
<smd name="1" x="-0.25" y="0" dx="0.25" dy="0.35" layer="1"/>
<smd name="2" x="0.25" y="0" dx="0.25" dy="0.35" layer="1"/>
<text x="-0.635" y="0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-1.905" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.3" y1="-0.15" x2="-0.15" y2="0.15" layer="51"/>
<rectangle x1="0.15" y1="-0.15" x2="0.3" y2="0.15" layer="51"/>
<rectangle x1="-0.15" y1="0.1" x2="0.15" y2="0.15" layer="51"/>
<rectangle x1="-0.15" y1="-0.15" x2="0.15" y2="-0.1" layer="51"/>
</package>
<package name="C1808" urn="urn:adsk.eagle:footprint:23197/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
Source: AVX .. aphvc.pdf</description>
<wire x1="-1.4732" y1="0.9502" x2="1.4732" y2="0.9502" width="0.1016" layer="51"/>
<wire x1="-1.4478" y1="-0.9502" x2="1.4732" y2="-0.9502" width="0.1016" layer="51"/>
<smd name="1" x="-1.95" y="0" dx="1.6" dy="2.2" layer="1"/>
<smd name="2" x="1.95" y="0" dx="1.6" dy="2.2" layer="1"/>
<text x="-2.233" y="1.827" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.233" y="-2.842" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.275" y1="-1.015" x2="-1.225" y2="1.015" layer="51"/>
<rectangle x1="1.225" y1="-1.015" x2="2.275" y2="1.015" layer="51"/>
</package>
<package name="C3640" urn="urn:adsk.eagle:footprint:23198/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
Source: AVX .. aphvc.pdf</description>
<wire x1="-3.8322" y1="5.0496" x2="3.8322" y2="5.0496" width="0.1016" layer="51"/>
<wire x1="-3.8322" y1="-5.0496" x2="3.8322" y2="-5.0496" width="0.1016" layer="51"/>
<smd name="1" x="-4.267" y="0" dx="2.6" dy="10.7" layer="1"/>
<smd name="2" x="4.267" y="0" dx="2.6" dy="10.7" layer="1"/>
<text x="-4.647" y="6.465" size="1.27" layer="25">&gt;NAME</text>
<text x="-4.647" y="-7.255" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-4.57" y1="-5.1" x2="-3.05" y2="5.1" layer="51"/>
<rectangle x1="3.05" y1="-5.1" x2="4.5688" y2="5.1" layer="51"/>
</package>
<package name="C01005" urn="urn:adsk.eagle:footprint:23199/1" library_version="11">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<rectangle x1="-0.1999" y1="-0.3" x2="0.1999" y2="0.3" layer="35"/>
<rectangle x1="-0.2" y1="-0.1" x2="-0.075" y2="0.1" layer="51"/>
<rectangle x1="0.075" y1="-0.1" x2="0.2" y2="0.1" layer="51"/>
<rectangle x1="-0.15" y1="0.05" x2="0.15" y2="0.1" layer="51"/>
<rectangle x1="-0.15" y1="-0.1" x2="0.15" y2="-0.05" layer="51"/>
<smd name="1" x="-0.1625" y="0" dx="0.2" dy="0.25" layer="1"/>
<smd name="2" x="0.1625" y="0" dx="0.2" dy="0.25" layer="1"/>
<text x="-0.4" y="0.3" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.4" y="-1.6" size="1.27" layer="27">&gt;VALUE</text>
</package>
</packages>
<packages3d>
<package3d name="CAPC1005X60" urn="urn:adsk.eagle:package:23626/2" type="model">
<description>Chip, 1.00 X 0.50 X 0.60 mm body
&lt;p&gt;Chip package with body size 1.00 X 0.50 X 0.60 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="C0402"/>
</packageinstances>
</package3d>
<package3d name="C0504" urn="urn:adsk.eagle:package:23624/2" type="model">
<description>CAPACITOR</description>
<packageinstances>
<packageinstance name="C0504"/>
</packageinstances>
</package3d>
<package3d name="C0603" urn="urn:adsk.eagle:package:23616/2" type="model">
<description>CAPACITOR</description>
<packageinstances>
<packageinstance name="C0603"/>
</packageinstances>
</package3d>
<package3d name="C0805" urn="urn:adsk.eagle:package:23617/2" type="model">
<description>CAPACITOR</description>
<packageinstances>
<packageinstance name="C0805"/>
</packageinstances>
</package3d>
<package3d name="C1206" urn="urn:adsk.eagle:package:23618/2" type="model">
<description>CAPACITOR</description>
<packageinstances>
<packageinstance name="C1206"/>
</packageinstances>
</package3d>
<package3d name="C1210" urn="urn:adsk.eagle:package:23619/2" type="model">
<description>CAPACITOR</description>
<packageinstances>
<packageinstance name="C1210"/>
</packageinstances>
</package3d>
<package3d name="C1310" urn="urn:adsk.eagle:package:23620/2" type="model">
<description>CAPACITOR</description>
<packageinstances>
<packageinstance name="C1310"/>
</packageinstances>
</package3d>
<package3d name="C1608" urn="urn:adsk.eagle:package:23621/2" type="model">
<description>CAPACITOR</description>
<packageinstances>
<packageinstance name="C1608"/>
</packageinstances>
</package3d>
<package3d name="C1812" urn="urn:adsk.eagle:package:23622/2" type="model">
<description>CAPACITOR</description>
<packageinstances>
<packageinstance name="C1812"/>
</packageinstances>
</package3d>
<package3d name="C1825" urn="urn:adsk.eagle:package:23623/2" type="model">
<description>CAPACITOR</description>
<packageinstances>
<packageinstance name="C1825"/>
</packageinstances>
</package3d>
<package3d name="C2012" urn="urn:adsk.eagle:package:23625/2" type="model">
<description>CAPACITOR</description>
<packageinstances>
<packageinstance name="C2012"/>
</packageinstances>
</package3d>
<package3d name="C3216" urn="urn:adsk.eagle:package:23628/2" type="model">
<description>CAPACITOR</description>
<packageinstances>
<packageinstance name="C3216"/>
</packageinstances>
</package3d>
<package3d name="C3225" urn="urn:adsk.eagle:package:23655/2" type="model">
<description>CAPACITOR</description>
<packageinstances>
<packageinstance name="C3225"/>
</packageinstances>
</package3d>
<package3d name="C4532" urn="urn:adsk.eagle:package:23627/2" type="model">
<description>CAPACITOR</description>
<packageinstances>
<packageinstance name="C4532"/>
</packageinstances>
</package3d>
<package3d name="C4564" urn="urn:adsk.eagle:package:23648/2" type="model">
<description>CAPACITOR</description>
<packageinstances>
<packageinstance name="C4564"/>
</packageinstances>
</package3d>
<package3d name="C025-024X044" urn="urn:adsk.eagle:package:23630/1" type="box">
<description>CAPACITOR
grid 2.5 mm, outline 2.4 x 4.4 mm</description>
<packageinstances>
<packageinstance name="C025-024X044"/>
</packageinstances>
</package3d>
<package3d name="C025-025X050" urn="urn:adsk.eagle:package:23629/2" type="model">
<description>CAPACITOR
grid 2.5 mm, outline 2.5 x 5 mm</description>
<packageinstances>
<packageinstance name="C025-025X050"/>
</packageinstances>
</package3d>
<package3d name="C025-030X050" urn="urn:adsk.eagle:package:23631/1" type="box">
<description>CAPACITOR
grid 2.5 mm, outline 3 x 5 mm</description>
<packageinstances>
<packageinstance name="C025-030X050"/>
</packageinstances>
</package3d>
<package3d name="C025-040X050" urn="urn:adsk.eagle:package:23634/1" type="box">
<description>CAPACITOR
grid 2.5 mm, outline 4 x 5 mm</description>
<packageinstances>
<packageinstance name="C025-040X050"/>
</packageinstances>
</package3d>
<package3d name="C025-050X050" urn="urn:adsk.eagle:package:23633/1" type="box">
<description>CAPACITOR
grid 2.5 mm, outline 5 x 5 mm</description>
<packageinstances>
<packageinstance name="C025-050X050"/>
</packageinstances>
</package3d>
<package3d name="C025-060X050" urn="urn:adsk.eagle:package:23632/1" type="box">
<description>CAPACITOR
grid 2.5 mm, outline 6 x 5 mm</description>
<packageinstances>
<packageinstance name="C025-060X050"/>
</packageinstances>
</package3d>
<package3d name="C025_050-024X070" urn="urn:adsk.eagle:package:23639/1" type="box">
<description>CAPACITOR
grid 2.5 mm + 5 mm, outline 2.4 x 7 mm</description>
<packageinstances>
<packageinstance name="C025_050-024X070"/>
</packageinstances>
</package3d>
<package3d name="C025_050-025X075" urn="urn:adsk.eagle:package:23641/1" type="box">
<description>CAPACITOR
grid 2.5 + 5 mm, outline 2.5 x 7.5 mm</description>
<packageinstances>
<packageinstance name="C025_050-025X075"/>
</packageinstances>
</package3d>
<package3d name="C025_050-035X075" urn="urn:adsk.eagle:package:23651/1" type="box">
<description>CAPACITOR
grid 2.5 + 5 mm, outline 3.5 x 7.5 mm</description>
<packageinstances>
<packageinstance name="C025_050-035X075"/>
</packageinstances>
</package3d>
<package3d name="C025_050-045X075" urn="urn:adsk.eagle:package:23635/1" type="box">
<description>CAPACITOR
grid 2.5 + 5 mm, outline 4.5 x 7.5 mm</description>
<packageinstances>
<packageinstance name="C025_050-045X075"/>
</packageinstances>
</package3d>
<package3d name="C025_050-055X075" urn="urn:adsk.eagle:package:23636/1" type="box">
<description>CAPACITOR
grid 2.5 + 5 mm, outline 5.5 x 7.5 mm</description>
<packageinstances>
<packageinstance name="C025_050-055X075"/>
</packageinstances>
</package3d>
<package3d name="C050-024X044" urn="urn:adsk.eagle:package:23643/1" type="box">
<description>CAPACITOR
grid 5 mm, outline 2.4 x 4.4 mm</description>
<packageinstances>
<packageinstance name="C050-024X044"/>
</packageinstances>
</package3d>
<package3d name="C050-025X075" urn="urn:adsk.eagle:package:23637/1" type="box">
<description>CAPACITOR
grid 5 mm, outline 2.5 x 7.5 mm</description>
<packageinstances>
<packageinstance name="C050-025X075"/>
</packageinstances>
</package3d>
<package3d name="C050-045X075" urn="urn:adsk.eagle:package:23638/1" type="box">
<description>CAPACITOR
grid 5 mm, outline 4.5 x 7.5 mm</description>
<packageinstances>
<packageinstance name="C050-045X075"/>
</packageinstances>
</package3d>
<package3d name="C050-030X075" urn="urn:adsk.eagle:package:23640/1" type="box">
<description>CAPACITOR
grid 5 mm, outline 3 x 7.5 mm</description>
<packageinstances>
<packageinstance name="C050-030X075"/>
</packageinstances>
</package3d>
<package3d name="C050-050X075" urn="urn:adsk.eagle:package:23665/1" type="box">
<description>CAPACITOR
grid 5 mm, outline 5 x 7.5 mm</description>
<packageinstances>
<packageinstance name="C050-050X075"/>
</packageinstances>
</package3d>
<package3d name="C050-055X075" urn="urn:adsk.eagle:package:23642/1" type="box">
<description>CAPACITOR
grid 5 mm, outline 5.5 x 7.5 mm</description>
<packageinstances>
<packageinstance name="C050-055X075"/>
</packageinstances>
</package3d>
<package3d name="C050-075X075" urn="urn:adsk.eagle:package:23645/1" type="box">
<description>CAPACITOR
grid 5 mm, outline 7.5 x 7.5 mm</description>
<packageinstances>
<packageinstance name="C050-075X075"/>
</packageinstances>
</package3d>
<package3d name="C050H075X075" urn="urn:adsk.eagle:package:23644/1" type="box">
<description>CAPACITOR
Horizontal, grid 5 mm, outline 7.5 x 7.5 mm</description>
<packageinstances>
<packageinstance name="C050H075X075"/>
</packageinstances>
</package3d>
<package3d name="C075-032X103" urn="urn:adsk.eagle:package:23646/1" type="box">
<description>CAPACITOR
grid 7.5 mm, outline 3.2 x 10.3 mm</description>
<packageinstances>
<packageinstance name="C075-032X103"/>
</packageinstances>
</package3d>
<package3d name="C075-042X103" urn="urn:adsk.eagle:package:23656/1" type="box">
<description>CAPACITOR
grid 7.5 mm, outline 4.2 x 10.3 mm</description>
<packageinstances>
<packageinstance name="C075-042X103"/>
</packageinstances>
</package3d>
<package3d name="C075-052X106" urn="urn:adsk.eagle:package:23650/1" type="box">
<description>CAPACITOR
grid 7.5 mm, outline 5.2 x 10.6 mm</description>
<packageinstances>
<packageinstance name="C075-052X106"/>
</packageinstances>
</package3d>
<package3d name="C102-043X133" urn="urn:adsk.eagle:package:23647/1" type="box">
<description>CAPACITOR
grid 10.2 mm, outline 4.3 x 13.3 mm</description>
<packageinstances>
<packageinstance name="C102-043X133"/>
</packageinstances>
</package3d>
<package3d name="C102-054X133" urn="urn:adsk.eagle:package:23649/1" type="box">
<description>CAPACITOR
grid 10.2 mm, outline 5.4 x 13.3 mm</description>
<packageinstances>
<packageinstance name="C102-054X133"/>
</packageinstances>
</package3d>
<package3d name="C102-064X133" urn="urn:adsk.eagle:package:23653/1" type="box">
<description>CAPACITOR
grid 10.2 mm, outline 6.4 x 13.3 mm</description>
<packageinstances>
<packageinstance name="C102-064X133"/>
</packageinstances>
</package3d>
<package3d name="C102_152-062X184" urn="urn:adsk.eagle:package:23652/1" type="box">
<description>CAPACITOR
grid 10.2 mm + 15.2 mm, outline 6.2 x 18.4 mm</description>
<packageinstances>
<packageinstance name="C102_152-062X184"/>
</packageinstances>
</package3d>
<package3d name="C150-054X183" urn="urn:adsk.eagle:package:23669/1" type="box">
<description>CAPACITOR
grid 15 mm, outline 5.4 x 18.3 mm</description>
<packageinstances>
<packageinstance name="C150-054X183"/>
</packageinstances>
</package3d>
<package3d name="C150-064X183" urn="urn:adsk.eagle:package:23654/1" type="box">
<description>CAPACITOR
grid 15 mm, outline 6.4 x 18.3 mm</description>
<packageinstances>
<packageinstance name="C150-064X183"/>
</packageinstances>
</package3d>
<package3d name="C150-072X183" urn="urn:adsk.eagle:package:23657/1" type="box">
<description>CAPACITOR
grid 15 mm, outline 7.2 x 18.3 mm</description>
<packageinstances>
<packageinstance name="C150-072X183"/>
</packageinstances>
</package3d>
<package3d name="C150-084X183" urn="urn:adsk.eagle:package:23658/1" type="box">
<description>CAPACITOR
grid 15 mm, outline 8.4 x 18.3 mm</description>
<packageinstances>
<packageinstance name="C150-084X183"/>
</packageinstances>
</package3d>
<package3d name="C150-091X182" urn="urn:adsk.eagle:package:23659/1" type="box">
<description>CAPACITOR
grid 15 mm, outline 9.1 x 18.2 mm</description>
<packageinstances>
<packageinstance name="C150-091X182"/>
</packageinstances>
</package3d>
<package3d name="C225-062X268" urn="urn:adsk.eagle:package:23661/1" type="box">
<description>CAPACITOR
grid 22.5 mm, outline 6.2 x 26.8 mm</description>
<packageinstances>
<packageinstance name="C225-062X268"/>
</packageinstances>
</package3d>
<package3d name="C225-074X268" urn="urn:adsk.eagle:package:23660/1" type="box">
<description>CAPACITOR
grid 22.5 mm, outline 7.4 x 26.8 mm</description>
<packageinstances>
<packageinstance name="C225-074X268"/>
</packageinstances>
</package3d>
<package3d name="C225-087X268" urn="urn:adsk.eagle:package:23662/1" type="box">
<description>CAPACITOR
grid 22.5 mm, outline 8.7 x 26.8 mm</description>
<packageinstances>
<packageinstance name="C225-087X268"/>
</packageinstances>
</package3d>
<package3d name="C225-108X268" urn="urn:adsk.eagle:package:23663/1" type="box">
<description>CAPACITOR
grid 22.5 mm, outline 10.8 x 26.8 mm</description>
<packageinstances>
<packageinstance name="C225-108X268"/>
</packageinstances>
</package3d>
<package3d name="C225-113X268" urn="urn:adsk.eagle:package:23667/1" type="box">
<description>CAPACITOR
grid 22.5 mm, outline 11.3 x 26.8 mm</description>
<packageinstances>
<packageinstance name="C225-113X268"/>
</packageinstances>
</package3d>
<package3d name="C275-093X316" urn="urn:adsk.eagle:package:23701/1" type="box">
<description>CAPACITOR
grid 27.5 mm, outline 9.3 x 31.6 mm</description>
<packageinstances>
<packageinstance name="C275-093X316"/>
</packageinstances>
</package3d>
<package3d name="C275-113X316" urn="urn:adsk.eagle:package:23673/1" type="box">
<description>CAPACITOR
grid 27.5 mm, outline 11.3 x 31.6 mm</description>
<packageinstances>
<packageinstance name="C275-113X316"/>
</packageinstances>
</package3d>
<package3d name="C275-134X316" urn="urn:adsk.eagle:package:23664/1" type="box">
<description>CAPACITOR
grid 27.5 mm, outline 13.4 x 31.6 mm</description>
<packageinstances>
<packageinstance name="C275-134X316"/>
</packageinstances>
</package3d>
<package3d name="C275-205X316" urn="urn:adsk.eagle:package:23666/1" type="box">
<description>CAPACITOR
grid 27.5 mm, outline 20.5 x 31.6 mm</description>
<packageinstances>
<packageinstance name="C275-205X316"/>
</packageinstances>
</package3d>
<package3d name="C325-137X374" urn="urn:adsk.eagle:package:23672/1" type="box">
<description>CAPACITOR
grid 32.5 mm, outline 13.7 x 37.4 mm</description>
<packageinstances>
<packageinstance name="C325-137X374"/>
</packageinstances>
</package3d>
<package3d name="C325-162X374" urn="urn:adsk.eagle:package:23670/1" type="box">
<description>CAPACITOR
grid 32.5 mm, outline 16.2 x 37.4 mm</description>
<packageinstances>
<packageinstance name="C325-162X374"/>
</packageinstances>
</package3d>
<package3d name="C325-182X374" urn="urn:adsk.eagle:package:23668/1" type="box">
<description>CAPACITOR
grid 32.5 mm, outline 18.2 x 37.4 mm</description>
<packageinstances>
<packageinstance name="C325-182X374"/>
</packageinstances>
</package3d>
<package3d name="C375-192X418" urn="urn:adsk.eagle:package:23674/1" type="box">
<description>CAPACITOR
grid 37.5 mm, outline 19.2 x 41.8 mm</description>
<packageinstances>
<packageinstance name="C375-192X418"/>
</packageinstances>
</package3d>
<package3d name="C375-203X418" urn="urn:adsk.eagle:package:23671/1" type="box">
<description>CAPACITOR
grid 37.5 mm, outline 20.3 x 41.8 mm</description>
<packageinstances>
<packageinstance name="C375-203X418"/>
</packageinstances>
</package3d>
<package3d name="C050-035X075" urn="urn:adsk.eagle:package:23677/1" type="box">
<description>CAPACITOR
grid 5 mm, outline 3.5 x 7.5 mm</description>
<packageinstances>
<packageinstance name="C050-035X075"/>
</packageinstances>
</package3d>
<package3d name="C375-155X418" urn="urn:adsk.eagle:package:23675/1" type="box">
<description>CAPACITOR
grid 37.5 mm, outline 15.5 x 41.8 mm</description>
<packageinstances>
<packageinstance name="C375-155X418"/>
</packageinstances>
</package3d>
<package3d name="C075-063X106" urn="urn:adsk.eagle:package:23678/1" type="box">
<description>CAPACITOR
grid 7.5 mm, outline 6.3 x 10.6 mm</description>
<packageinstances>
<packageinstance name="C075-063X106"/>
</packageinstances>
</package3d>
<package3d name="C275-154X316" urn="urn:adsk.eagle:package:23685/1" type="box">
<description>CAPACITOR
grid 27.5 mm, outline 15.4 x 31.6 mm</description>
<packageinstances>
<packageinstance name="C275-154X316"/>
</packageinstances>
</package3d>
<package3d name="C275-173X316" urn="urn:adsk.eagle:package:23676/1" type="box">
<description>CAPACITOR
grid 27.5 mm, outline 17.3 x 31.6 mm</description>
<packageinstances>
<packageinstance name="C275-173X316"/>
</packageinstances>
</package3d>
<package3d name="C0402K" urn="urn:adsk.eagle:package:23679/2" type="model">
<description>Ceramic Chip Capacitor KEMET 0204 reflow solder
Metric Code Size 1005</description>
<packageinstances>
<packageinstance name="C0402K"/>
</packageinstances>
</package3d>
<package3d name="C0603K" urn="urn:adsk.eagle:package:23680/2" type="model">
<description>Ceramic Chip Capacitor KEMET 0603 reflow solder
Metric Code Size 1608</description>
<packageinstances>
<packageinstance name="C0603K"/>
</packageinstances>
</package3d>
<package3d name="C0805K" urn="urn:adsk.eagle:package:23681/2" type="model">
<description>Ceramic Chip Capacitor KEMET 0805 reflow solder
Metric Code Size 2012</description>
<packageinstances>
<packageinstance name="C0805K"/>
</packageinstances>
</package3d>
<package3d name="C1206K" urn="urn:adsk.eagle:package:23682/2" type="model">
<description>Ceramic Chip Capacitor KEMET 1206 reflow solder
Metric Code Size 3216</description>
<packageinstances>
<packageinstance name="C1206K"/>
</packageinstances>
</package3d>
<package3d name="C1210K" urn="urn:adsk.eagle:package:23683/2" type="model">
<description>Ceramic Chip Capacitor KEMET 1210 reflow solder
Metric Code Size 3225</description>
<packageinstances>
<packageinstance name="C1210K"/>
</packageinstances>
</package3d>
<package3d name="C1812K" urn="urn:adsk.eagle:package:23686/2" type="model">
<description>Ceramic Chip Capacitor KEMET 1812 reflow solder
Metric Code Size 4532</description>
<packageinstances>
<packageinstance name="C1812K"/>
</packageinstances>
</package3d>
<package3d name="C1825K" urn="urn:adsk.eagle:package:23684/2" type="model">
<description>Ceramic Chip Capacitor KEMET 1825 reflow solder
Metric Code Size 4564</description>
<packageinstances>
<packageinstance name="C1825K"/>
</packageinstances>
</package3d>
<package3d name="C2220K" urn="urn:adsk.eagle:package:23687/2" type="model">
<description>Ceramic Chip Capacitor KEMET 2220 reflow solderMetric Code Size 5650</description>
<packageinstances>
<packageinstance name="C2220K"/>
</packageinstances>
</package3d>
<package3d name="C2225K" urn="urn:adsk.eagle:package:23692/2" type="model">
<description>Ceramic Chip Capacitor KEMET 2225 reflow solderMetric Code Size 5664</description>
<packageinstances>
<packageinstance name="C2225K"/>
</packageinstances>
</package3d>
<package3d name="C0201" urn="urn:adsk.eagle:package:23690/2" type="model">
<description>Source: http://www.avxcorp.com/docs/catalogs/cx5r.pdf</description>
<packageinstances>
<packageinstance name="C0201"/>
</packageinstances>
</package3d>
<package3d name="C1808" urn="urn:adsk.eagle:package:23689/2" type="model">
<description>CAPACITOR
Source: AVX .. aphvc.pdf</description>
<packageinstances>
<packageinstance name="C1808"/>
</packageinstances>
</package3d>
<package3d name="C3640" urn="urn:adsk.eagle:package:23693/2" type="model">
<description>CAPACITOR
Source: AVX .. aphvc.pdf</description>
<packageinstances>
<packageinstance name="C3640"/>
</packageinstances>
</package3d>
<package3d name="C01005" urn="urn:adsk.eagle:package:23691/1" type="box">
<description>CAPACITOR</description>
<packageinstances>
<packageinstance name="C01005"/>
</packageinstances>
</package3d>
</packages3d>
<symbols>
<symbol name="C-US" urn="urn:adsk.eagle:symbol:23201/1" library_version="11">
<wire x1="-2.54" y1="0" x2="2.54" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="-1.016" x2="0" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="0" y1="-1" x2="2.4892" y2="-1.8542" width="0.254" layer="94" curve="-37.878202"/>
<wire x1="-2.4668" y1="-1.8504" x2="0" y2="-1.0161" width="0.254" layer="94" curve="-37.373024"/>
<text x="1.016" y="0.635" size="1.778" layer="95">&gt;NAME</text>
<text x="1.016" y="-4.191" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="0" y="2.54" visible="off" length="short" direction="pas" swaplevel="1" rot="R270"/>
<pin name="2" x="0" y="-5.08" visible="off" length="short" direction="pas" swaplevel="1" rot="R90"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="C-US" urn="urn:adsk.eagle:component:23794/44" prefix="C" uservalue="yes" library_version="11">
<description>&lt;B&gt;CAPACITOR&lt;/B&gt;, American symbol</description>
<gates>
<gate name="G$1" symbol="C-US" x="0" y="0"/>
</gates>
<devices>
<device name="C0402" package="C0402">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23626/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="16" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C0504" package="C0504">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23624/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C0603" package="C0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23616/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="37" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C0805" package="C0805">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23617/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="63" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C1206" package="C1206">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23618/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="24" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C1210" package="C1210">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23619/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="6" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C1310" package="C1310">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23620/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C1608" package="C1608">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23621/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C1812" package="C1812">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23622/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C1825" package="C1825">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23623/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C2012" package="C2012">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23625/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C3216" package="C3216">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23628/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C3225" package="C3225">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23655/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C4532" package="C4532">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23627/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C4564" package="C4564">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23648/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="025-024X044" package="C025-024X044">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23630/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="17" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="025-025X050" package="C025-025X050">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23629/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="025-030X050" package="C025-030X050">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23631/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="1" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="025-040X050" package="C025-040X050">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23634/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="025-050X050" package="C025-050X050">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23633/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="7" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="025-060X050" package="C025-060X050">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23632/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="1" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C025_050-024X070" package="C025_050-024X070">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23639/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="025_050-025X075" package="C025_050-025X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23641/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="025_050-035X075" package="C025_050-035X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23651/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="025_050-045X075" package="C025_050-045X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23635/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="025_050-055X075" package="C025_050-055X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23636/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="050-024X044" package="C050-024X044">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23643/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="14" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="050-025X075" package="C050-025X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23637/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="050-045X075" package="C050-045X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23638/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="2" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="050-030X075" package="C050-030X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23640/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="5" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="050-050X075" package="C050-050X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23665/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="050-055X075" package="C050-055X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23642/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="050-075X075" package="C050-075X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23645/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="1" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="050H075X075" package="C050H075X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23644/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="075-032X103" package="C075-032X103">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23646/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="7" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="075-042X103" package="C075-042X103">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23656/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="1" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="075-052X106" package="C075-052X106">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23650/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="102-043X133" package="C102-043X133">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23647/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="102-054X133" package="C102-054X133">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23649/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="102-064X133" package="C102-064X133">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23653/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="102_152-062X184" package="C102_152-062X184">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23652/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="150-054X183" package="C150-054X183">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23669/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="150-064X183" package="C150-064X183">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23654/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="150-072X183" package="C150-072X183">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23657/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="150-084X183" package="C150-084X183">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23658/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="150-091X182" package="C150-091X182">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23659/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="225-062X268" package="C225-062X268">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23661/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="225-074X268" package="C225-074X268">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23660/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="225-087X268" package="C225-087X268">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23662/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="225-108X268" package="C225-108X268">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23663/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="225-113X268" package="C225-113X268">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23667/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="275-093X316" package="C275-093X316">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23701/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="275-113X316" package="C275-113X316">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23673/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="275-134X316" package="C275-134X316">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23664/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="275-205X316" package="C275-205X316">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23666/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="325-137X374" package="C325-137X374">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23672/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="325-162X374" package="C325-162X374">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23670/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="325-182X374" package="C325-182X374">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23668/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="375-192X418" package="C375-192X418">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23674/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="375-203X418" package="C375-203X418">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23671/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="050-035X075" package="C050-035X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23677/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="375-155X418" package="C375-155X418">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23675/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="075-063X106" package="C075-063X106">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23678/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="1" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="275-154X316" package="C275-154X316">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23685/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="275-173X316" package="C275-173X316">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23676/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C0402K" package="C0402K">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23679/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="4" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C0603K" package="C0603K">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23680/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="5" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C0805K" package="C0805K">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23681/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="19" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C1206K" package="C1206K">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23682/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="2" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C1210K" package="C1210K">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23683/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C1812K" package="C1812K">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23686/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C1825K" package="C1825K">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23684/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C2220K" package="C2220K">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23687/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C2225K" package="C2225K">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23692/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C0201" package="C0201">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23690/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="3" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C1808" package="C1808">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23689/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="C3640" package="C3640">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23693/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
<device name="01005" package="C01005">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23691/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="2" constant="no"/>
<attribute name="SPICEPREFIX" value="C" constant="no"/>
</technology>
</technologies>
</device>
</devices>
<spice>
<pinmapping spiceprefix="C">
<pinmap gate="G$1" pin="1" pinorder="1"/>
<pinmap gate="G$1" pin="2" pinorder="2"/>
</pinmapping>
</spice>
</deviceset>
</devicesets>
</library>
<library name="diodes" urn="urn:adsk.eagle:library:10801186">
<description>&lt;Diode: switching; SMD; 75V; 150mA; 4ns; 0805&lt;/b&gt;&lt;p&gt;
&lt;author&gt;Created by SamacSys&lt;/author&gt;</description>
<packages>
<package name="0603" urn="urn:adsk.eagle:footprint:16125209/1" library_version="13">
<smd name="C" x="0.877" y="0" dx="1" dy="1" layer="1" roundness="30" rot="R270"/>
<smd name="A" x="-0.877" y="0" dx="1" dy="1" layer="1" roundness="30" rot="R270"/>
<text x="0" y="0.635" size="0.6096" layer="25" font="vector" ratio="20" align="bottom-center">&gt;NAME</text>
<text x="0" y="-0.635" size="0.6096" layer="27" font="vector" ratio="20" align="top-center">&gt;VALUE</text>
<wire x1="1.5875" y1="0.47625" x2="1.5875" y2="-0.47625" width="0.127" layer="21"/>
<wire x1="0.15875" y1="0.47625" x2="0.15875" y2="0" width="0.127" layer="51"/>
<wire x1="0.15875" y1="0" x2="0.15875" y2="-0.47625" width="0.127" layer="51"/>
<wire x1="0.15875" y1="0" x2="-0.15875" y2="0.3175" width="0.127" layer="51"/>
<wire x1="0.15875" y1="0" x2="-0.15875" y2="-0.3175" width="0.127" layer="51"/>
</package>
</packages>
<packages3d>
<package3d name="0603" urn="urn:adsk.eagle:package:16125211/2" type="model">
<packageinstances>
<packageinstance name="0603"/>
</packageinstances>
</package3d>
</packages3d>
<symbols>
<symbol name="LED" urn="urn:adsk.eagle:symbol:16125210/1" locally_modified="yes" library_version="13">
<wire x1="1.27" y1="0" x2="0" y2="-2.54" width="0.254" layer="94"/>
<wire x1="0" y1="-2.54" x2="-1.27" y2="0" width="0.254" layer="94"/>
<wire x1="1.27" y1="-2.54" x2="0" y2="-2.54" width="0.254" layer="94"/>
<wire x1="0" y1="-2.54" x2="-1.27" y2="-2.54" width="0.254" layer="94"/>
<wire x1="1.27" y1="0" x2="-1.27" y2="0" width="0.254" layer="94"/>
<wire x1="-2.032" y1="-0.762" x2="-3.429" y2="-2.159" width="0.1524" layer="94"/>
<wire x1="-1.905" y1="-1.905" x2="-3.302" y2="-3.302" width="0.1524" layer="94"/>
<text x="-3.429" y="-4.572" size="1.778" layer="95" font="vector" rot="R90">&gt;NAME</text>
<text x="1.905" y="-4.572" size="1.778" layer="96" font="vector" rot="R90" align="top-left">&gt;VALUE</text>
<pin name="C" x="0" y="-5.08" visible="off" length="short" direction="pas" rot="R90"/>
<pin name="A" x="0" y="2.54" visible="off" length="short" direction="pas" rot="R270"/>
<polygon width="0.1524" layer="94" pour="solid">
<vertex x="-3.048" y="-1.27"/>
<vertex x="-3.429" y="-2.159"/>
<vertex x="-2.54" y="-1.778"/>
</polygon>
<polygon width="0.1524" layer="94" pour="solid">
<vertex x="-2.921" y="-2.413"/>
<vertex x="-3.302" y="-3.302"/>
<vertex x="-2.413" y="-2.921"/>
</polygon>
</symbol>
</symbols>
<devicesets>
<deviceset name="LED" urn="urn:adsk.eagle:component:16125212/2" library_version="13">
<gates>
<gate name="G$1" symbol="LED" x="0" y="0"/>
</gates>
<devices>
<device name="" package="0603">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16125211/2"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Circuit-Protection" urn="urn:adsk.eagle:library:16378135">
<description>&lt;B&gt;Fuse, TVS, Thermistor, Thyristor, Varistor, ESD Suppression</description>
<packages>
<package name="DIOM5226X290N" urn="urn:adsk.eagle:footprint:16378143/3" library_version="21">
<description>Molded Body, 5.20 X 2.60 X 2.90 mm body
&lt;p&gt;Molded Body package with body size 5.20 X 2.60 X 2.90 mm&lt;/p&gt;</description>
<wire x1="2.8" y1="1.475" x2="-3.6179" y2="1.475" width="0.12" layer="21"/>
<wire x1="-3.6179" y1="1.475" x2="-3.6179" y2="-1.475" width="0.12" layer="21"/>
<wire x1="-3.6179" y1="-1.475" x2="2.8" y2="-1.475" width="0.12" layer="21"/>
<wire x1="2.8" y1="-1.475" x2="-2.8" y2="-1.475" width="0.12" layer="51"/>
<wire x1="-2.8" y1="-1.475" x2="-2.8" y2="1.475" width="0.12" layer="51"/>
<wire x1="-2.8" y1="1.475" x2="2.8" y2="1.475" width="0.12" layer="51"/>
<wire x1="2.8" y1="1.475" x2="2.8" y2="-1.475" width="0.12" layer="51"/>
<smd name="1" x="-2.1079" y="0" dx="2.392" dy="1.5653" layer="1"/>
<smd name="2" x="2.1079" y="0" dx="2.392" dy="1.5653" layer="1"/>
<text x="0" y="2.54" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="center">&gt;VALUE</text>
</package>
<package name="DIOM7959X625N" urn="urn:adsk.eagle:footprint:16378140/3" library_version="21">
<description>Molded Body, 7.95 X 5.90 X 6.25 mm body
&lt;p&gt;Molded Body package with body size 7.95 X 5.90 X 6.25 mm&lt;/p&gt;</description>
<wire x1="4.075" y1="3.125" x2="-4.8967" y2="3.125" width="0.12" layer="21"/>
<wire x1="-4.8967" y1="3.125" x2="-4.8967" y2="-3.125" width="0.12" layer="21"/>
<wire x1="-4.8967" y1="-3.125" x2="4.075" y2="-3.125" width="0.12" layer="21"/>
<wire x1="4.075" y1="-3.125" x2="-4.075" y2="-3.125" width="0.12" layer="51"/>
<wire x1="-4.075" y1="-3.125" x2="-4.075" y2="3.125" width="0.12" layer="51"/>
<wire x1="-4.075" y1="3.125" x2="4.075" y2="3.125" width="0.12" layer="51"/>
<wire x1="4.075" y1="3.125" x2="4.075" y2="-3.125" width="0.12" layer="51"/>
<smd name="1" x="-3.4567" y="0" dx="2.2518" dy="3.1202" layer="1"/>
<smd name="2" x="3.4567" y="0" dx="2.2518" dy="3.1202" layer="1"/>
<text x="0" y="3.81" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-3.81" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
</packages>
<packages3d>
<package3d name="DIOM5226X290N" urn="urn:adsk.eagle:package:16378158/3" type="model">
<description>Molded Body, 5.20 X 2.60 X 2.90 mm body
&lt;p&gt;Molded Body package with body size 5.20 X 2.60 X 2.90 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="DIOM5226X290N"/>
</packageinstances>
</package3d>
<package3d name="DIOM7959X625N" urn="urn:adsk.eagle:package:16378159/3" type="model">
<description>Molded Body, 7.95 X 5.90 X 6.25 mm body
&lt;p&gt;Molded Body package with body size 7.95 X 5.90 X 6.25 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="DIOM7959X625N"/>
</packageinstances>
</package3d>
</packages3d>
<symbols>
<symbol name="TVS" urn="urn:adsk.eagle:symbol:16378136/3" library_version="21">
<wire x1="-2.54" y1="-1.27" x2="0" y2="0" width="0.1524" layer="94"/>
<wire x1="0" y1="0" x2="-2.54" y2="1.27" width="0.1524" layer="94"/>
<wire x1="0.635" y1="1.27" x2="0" y2="1.27" width="0.1524" layer="94"/>
<wire x1="0" y1="1.27" x2="0" y2="0" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="1.27" x2="-2.54" y2="-1.27" width="0.1524" layer="94"/>
<wire x1="0" y1="0" x2="0" y2="-1.27" width="0.1524" layer="94"/>
<wire x1="0" y1="-1.27" x2="-0.635" y2="-1.27" width="0.1524" layer="94"/>
<wire x1="2.54" y1="1.27" x2="2.54" y2="-1.27" width="0.1524" layer="94"/>
<wire x1="2.54" y1="-1.27" x2="0" y2="0" width="0.1524" layer="94"/>
<wire x1="0" y1="0" x2="2.54" y2="1.27" width="0.1524" layer="94"/>
<pin name="1" x="-5.08" y="0" visible="off" length="short" direction="pas"/>
<pin name="2" x="5.08" y="0" visible="off" length="short" direction="pas" rot="R180"/>
<text x="0" y="2.54" size="1.778" layer="95" align="center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.778" layer="96" align="center">&gt;VALUE</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="TVS" urn="urn:adsk.eagle:component:16378161/11" prefix="D" library_version="21">
<description>TVS Diode - Generic</description>
<gates>
<gate name="G$1" symbol="TVS" x="0" y="0"/>
</gates>
<devices>
<device name="DO-214AC(SMA)" package="DIOM5226X290N">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378158/3"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="BREAKDOWN_VOLTAGE" value="" constant="no"/>
<attribute name="CATEGORY" value="Circuit Protection" constant="no"/>
<attribute name="CLAMPING_VOLTAGE" value="" constant="no"/>
<attribute name="CURRENT_RATING" value="" constant="no"/>
<attribute name="CURRENT_SURGE" value="" constant="no"/>
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PACKAGE_SIZE" value="DO-214AC" constant="no"/>
<attribute name="PACKAGE_TYPE" value="Surface Mount" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUBCATEGORY" value="TVS Diode" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VARISTOR_VOLTAGE" value="" constant="no"/>
<attribute name="VOLTAGE_RATING" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="MOLDED(7929-METRIC)" package="DIOM7959X625N">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378159/3"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="BREAKDOWN_VOLTAGE" value="" constant="no"/>
<attribute name="CATEGORY" value="Circuit Protection" constant="no"/>
<attribute name="CLAMPING_VOLTAGE" value="" constant="no"/>
<attribute name="CURRENT_RATING" value="" constant="no"/>
<attribute name="CURRENT_SURGE" value="" constant="no"/>
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PACKAGE_SIZE" value="DO-214AB" constant="no"/>
<attribute name="PACKAGE_TYPE" value="Surface Mount" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUBCATEGORY" value="TVS Diode" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VARISTOR_VOLTAGE" value="" constant="no"/>
<attribute name="VOLTAGE_RATING" value="" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="2025-10-28_16-15-34_Library" urn="urn:adsk.wipprod:fs.file:vf.AYd5E19VTza6wI4NEddNEA">
<packages>
<package name="CON10_2X5_SHM_TEC" library_version="2">
<pad name="1" x="0" y="0" drill="0.9652" diameter="1.524" shape="square"/>
<pad name="2" x="0" y="2.54" drill="0.9652" diameter="1.524"/>
<pad name="3" x="2.54" y="0" drill="0.9652" diameter="1.524"/>
<pad name="4" x="2.54" y="2.54" drill="0.9652" diameter="1.524"/>
<pad name="5" x="5.08" y="0" drill="0.9652" diameter="1.524"/>
<pad name="6" x="5.08" y="2.54" drill="0.9652" diameter="1.524"/>
<pad name="7" x="7.62" y="0" drill="0.9652" diameter="1.524"/>
<pad name="8" x="7.62" y="2.54" drill="0.9652" diameter="1.524"/>
<pad name="9" x="10.16" y="0" drill="0.9652" diameter="1.524"/>
<pad name="10" x="10.16" y="2.54" drill="0.9652" diameter="1.524"/>
<pad name="11" x="-3.81" y="1.27" drill="2.6924" diameter="3.302"/>
<pad name="12" x="13.97" y="1.27" drill="2.6924" diameter="3.302"/>
<wire x1="0" y1="0" x2="0" y2="8.4582" width="0.1524" layer="48"/>
<wire x1="2.54" y1="0" x2="2.54" y2="8.4582" width="0.1524" layer="48"/>
<wire x1="0" y1="8.0772" x2="-1.27" y2="8.0772" width="0.1524" layer="48"/>
<wire x1="2.54" y1="8.0772" x2="3.81" y2="8.0772" width="0.1524" layer="48"/>
<wire x1="0" y1="8.0772" x2="-0.254" y2="8.2042" width="0.1524" layer="48"/>
<wire x1="0" y1="8.0772" x2="-0.254" y2="7.9502" width="0.1524" layer="48"/>
<wire x1="-0.254" y1="8.2042" x2="-0.254" y2="7.9502" width="0.1524" layer="48"/>
<wire x1="2.54" y1="8.0772" x2="2.794" y2="8.2042" width="0.1524" layer="48"/>
<wire x1="2.54" y1="8.0772" x2="2.794" y2="7.9502" width="0.1524" layer="48"/>
<wire x1="2.794" y1="8.2042" x2="2.794" y2="7.9502" width="0.1524" layer="48"/>
<wire x1="-3.81" y1="1.27" x2="-3.81" y2="13.5382" width="0.1524" layer="48"/>
<wire x1="13.97" y1="1.27" x2="13.97" y2="13.5382" width="0.1524" layer="48"/>
<wire x1="-3.81" y1="13.1572" x2="13.97" y2="13.1572" width="0.1524" layer="48"/>
<wire x1="-3.81" y1="13.1572" x2="-3.556" y2="13.2842" width="0.1524" layer="48"/>
<wire x1="-3.81" y1="13.1572" x2="-3.556" y2="13.0302" width="0.1524" layer="48"/>
<wire x1="-3.556" y1="13.2842" x2="-3.556" y2="13.0302" width="0.1524" layer="48"/>
<wire x1="13.97" y1="13.1572" x2="13.716" y2="13.2842" width="0.1524" layer="48"/>
<wire x1="13.97" y1="13.1572" x2="13.716" y2="13.0302" width="0.1524" layer="48"/>
<wire x1="13.716" y1="13.2842" x2="13.716" y2="13.0302" width="0.1524" layer="48"/>
<wire x1="-10.922" y1="5.5372" x2="-10.922" y2="16.0782" width="0.1524" layer="48"/>
<wire x1="21.082" y1="5.5372" x2="21.082" y2="16.0782" width="0.1524" layer="48"/>
<wire x1="-10.922" y1="15.6972" x2="21.082" y2="15.6972" width="0.1524" layer="48"/>
<wire x1="-10.922" y1="15.6972" x2="-10.668" y2="15.8242" width="0.1524" layer="48"/>
<wire x1="-10.922" y1="15.6972" x2="-10.668" y2="15.5702" width="0.1524" layer="48"/>
<wire x1="-10.668" y1="15.8242" x2="-10.668" y2="15.5702" width="0.1524" layer="48"/>
<wire x1="21.082" y1="15.6972" x2="20.828" y2="15.8242" width="0.1524" layer="48"/>
<wire x1="21.082" y1="15.6972" x2="20.828" y2="15.5702" width="0.1524" layer="48"/>
<wire x1="20.828" y1="15.8242" x2="20.828" y2="15.5702" width="0.1524" layer="48"/>
<wire x1="0" y1="2.54" x2="24.003" y2="2.54" width="0.1524" layer="48"/>
<wire x1="0" y1="0" x2="24.003" y2="0" width="0.1524" layer="48"/>
<wire x1="23.622" y1="2.54" x2="23.622" y2="3.81" width="0.1524" layer="48"/>
<wire x1="23.622" y1="0" x2="23.622" y2="-1.27" width="0.1524" layer="48"/>
<wire x1="23.622" y1="2.54" x2="23.495" y2="2.794" width="0.1524" layer="48"/>
<wire x1="23.622" y1="2.54" x2="23.749" y2="2.794" width="0.1524" layer="48"/>
<wire x1="23.495" y1="2.794" x2="23.749" y2="2.794" width="0.1524" layer="48"/>
<wire x1="23.622" y1="0" x2="23.495" y2="-0.254" width="0.1524" layer="48"/>
<wire x1="23.622" y1="0" x2="23.749" y2="-0.254" width="0.1524" layer="48"/>
<wire x1="23.495" y1="-0.254" x2="23.749" y2="-0.254" width="0.1524" layer="48"/>
<wire x1="5.08" y1="1.27" x2="-13.843" y2="1.27" width="0.1524" layer="48"/>
<wire x1="13.97" y1="1.27" x2="-13.843" y2="1.27" width="0.1524" layer="48"/>
<wire x1="-13.462" y1="1.27" x2="-13.462" y2="2.54" width="0.1524" layer="48"/>
<wire x1="-13.462" y1="1.27" x2="-13.462" y2="0" width="0.1524" layer="48"/>
<wire x1="-13.462" y1="1.27" x2="-13.589" y2="1.524" width="0.1524" layer="48"/>
<wire x1="-13.462" y1="1.27" x2="-13.335" y2="1.524" width="0.1524" layer="48"/>
<wire x1="-13.589" y1="1.524" x2="-13.335" y2="1.524" width="0.1524" layer="48"/>
<wire x1="-13.462" y1="1.27" x2="-13.589" y2="1.016" width="0.1524" layer="48"/>
<wire x1="-13.462" y1="1.27" x2="-13.335" y2="1.016" width="0.1524" layer="48"/>
<wire x1="-13.589" y1="1.016" x2="-13.335" y2="1.016" width="0.1524" layer="48"/>
<wire x1="13.97" y1="8.89" x2="-16.383" y2="8.89" width="0.1524" layer="48"/>
<wire x1="5.08" y1="1.27" x2="-16.383" y2="1.27" width="0.1524" layer="48"/>
<wire x1="-16.002" y1="8.89" x2="-16.002" y2="1.27" width="0.1524" layer="48"/>
<wire x1="-16.002" y1="8.89" x2="-16.129" y2="8.636" width="0.1524" layer="48"/>
<wire x1="-16.002" y1="8.89" x2="-15.875" y2="8.636" width="0.1524" layer="48"/>
<wire x1="-16.129" y1="8.636" x2="-15.875" y2="8.636" width="0.1524" layer="48"/>
<wire x1="-16.002" y1="1.27" x2="-16.129" y2="1.524" width="0.1524" layer="48"/>
<wire x1="-16.002" y1="1.27" x2="-15.875" y2="1.524" width="0.1524" layer="48"/>
<wire x1="-16.129" y1="1.524" x2="-15.875" y2="1.524" width="0.1524" layer="48"/>
<wire x1="-10.922" y1="5.5372" x2="-18.923" y2="5.5372" width="0.1524" layer="48"/>
<wire x1="5.08" y1="1.27" x2="-18.923" y2="1.27" width="0.1524" layer="48"/>
<wire x1="-18.542" y1="5.5372" x2="-18.542" y2="1.27" width="0.1524" layer="48"/>
<wire x1="-18.542" y1="5.5372" x2="-18.669" y2="5.2832" width="0.1524" layer="48"/>
<wire x1="-18.542" y1="5.5372" x2="-18.415" y2="5.2832" width="0.1524" layer="48"/>
<wire x1="-18.669" y1="5.2832" x2="-18.415" y2="5.2832" width="0.1524" layer="48"/>
<wire x1="-18.542" y1="1.27" x2="-18.669" y2="1.524" width="0.1524" layer="48"/>
<wire x1="-18.542" y1="1.27" x2="-18.415" y2="1.524" width="0.1524" layer="48"/>
<wire x1="-18.669" y1="1.524" x2="-18.415" y2="1.524" width="0.1524" layer="48"/>
<wire x1="-10.922" y1="5.5372" x2="-21.463" y2="5.5372" width="0.1524" layer="48"/>
<wire x1="-10.922" y1="-2.9972" x2="-21.463" y2="-2.9972" width="0.1524" layer="48"/>
<wire x1="-21.082" y1="5.5372" x2="-21.082" y2="-2.9972" width="0.1524" layer="48"/>
<wire x1="-21.082" y1="5.5372" x2="-21.209" y2="5.2832" width="0.1524" layer="48"/>
<wire x1="-21.082" y1="5.5372" x2="-20.955" y2="5.2832" width="0.1524" layer="48"/>
<wire x1="-21.209" y1="5.2832" x2="-20.955" y2="5.2832" width="0.1524" layer="48"/>
<wire x1="-21.082" y1="-2.9972" x2="-21.209" y2="-2.7432" width="0.1524" layer="48"/>
<wire x1="-21.082" y1="-2.9972" x2="-20.955" y2="-2.7432" width="0.1524" layer="48"/>
<wire x1="-21.209" y1="-2.7432" x2="-20.955" y2="-2.7432" width="0.1524" layer="48"/>
<text x="-10.6997" y="-6.8072" size="1.27" layer="48" ratio="6">Default Padstyle: EX60Y60D38P</text>
<text x="-9.92" y="-9.3472" size="1.27" layer="48" ratio="6">Pin 1 Padstyle: SX60Y60D38P</text>
<text x="-16.276" y="-11.8872" size="1.27" layer="48" ratio="6">First Mounting Padstyle: EX130Y130D106P</text>
<text x="-15.4962" y="-14.4272" size="1.27" layer="48" ratio="6">Second Mounting Padstyle: EX70Y70D70P</text>
<text x="-1.908" y="8.5852" size="0.635" layer="48" ratio="4">0.1in/2.54mm</text>
<text x="1.6139" y="13.6652" size="0.635" layer="48" ratio="4">0.7in/17.78mm</text>
<text x="1.0376" y="16.2052" size="0.635" layer="48" ratio="4">1.26in/32.004mm</text>
<text x="24.13" y="0.9525" size="0.635" layer="48" ratio="4">0.1in/2.54mm</text>
<text x="-17.8175" y="0.9525" size="0.635" layer="48" ratio="4">0in/0mm</text>
<text x="-22.866" y="4.7625" size="0.635" layer="48" ratio="4">0.3in/7.62mm</text>
<text x="-27.1348" y="3.0861" size="0.635" layer="48" ratio="4">0.168in/4.267mm</text>
<text x="-29.6748" y="3.0861" size="0.635" layer="48" ratio="4">0.336in/8.534mm</text>
<wire x1="-11.049" y1="-3.1242" x2="21.209" y2="-3.1242" width="0.1524" layer="21"/>
<wire x1="21.209" y1="-3.1242" x2="21.209" y2="5.6642" width="0.1524" layer="21"/>
<wire x1="21.209" y1="5.6642" x2="-11.049" y2="5.6642" width="0.1524" layer="21"/>
<wire x1="-11.049" y1="5.6642" x2="-11.049" y2="-3.1242" width="0.1524" layer="21"/>
<wire x1="0.381" y1="10.4394" x2="-0.381" y2="10.4394" width="0.508" layer="21" curve="-180"/>
<wire x1="-0.381" y1="10.4394" x2="0.381" y2="10.4394" width="0.508" layer="21" curve="-180"/>
<text x="-2.1003" y="-0.635" size="1.27" layer="21" ratio="6">1</text>
<text x="-2.1003" y="1.905" size="1.27" layer="21" ratio="6">2</text>
<text x="11.1077" y="-0.635" size="1.27" layer="21" ratio="6">9</text>
<text x="10.5315" y="1.905" size="1.27" layer="21" ratio="6">10</text>
<wire x1="-10.922" y1="-2.9972" x2="21.082" y2="-2.9972" width="0.1524" layer="51"/>
<wire x1="21.082" y1="-2.9972" x2="21.082" y2="5.5372" width="0.1524" layer="51"/>
<wire x1="21.082" y1="5.5372" x2="-10.922" y2="5.5372" width="0.1524" layer="51"/>
<wire x1="-10.922" y1="5.5372" x2="-10.922" y2="-2.9972" width="0.1524" layer="51"/>
<wire x1="0.381" y1="-1.905" x2="-0.381" y2="-1.905" width="0.508" layer="51" curve="-180"/>
<wire x1="-0.381" y1="-1.905" x2="0.381" y2="-1.905" width="0.508" layer="51" curve="-180"/>
<text x="-2.1003" y="-0.635" size="1.27" layer="51" ratio="6">1</text>
<text x="-2.1003" y="1.905" size="1.27" layer="51" ratio="6">2</text>
<text x="11.1077" y="-0.635" size="1.27" layer="51" ratio="6">9</text>
<text x="10.5315" y="1.905" size="1.27" layer="51" ratio="6">10</text>
<wire x1="0.381" y1="10.4394" x2="-0.381" y2="10.4394" width="0.508" layer="22" curve="-180"/>
<wire x1="-0.381" y1="10.4394" x2="0.381" y2="10.4394" width="0.508" layer="22" curve="-180"/>
<text x="-0.9477" y="-0.635" size="1.27" layer="22" ratio="6" rot="MR0">1</text>
<text x="-0.9477" y="1.905" size="1.27" layer="22" ratio="6" rot="MR0">2</text>
<text x="12.2603" y="-0.635" size="1.27" layer="22" ratio="6" rot="MR0">9</text>
<text x="12.8365" y="1.905" size="1.27" layer="22" ratio="6" rot="MR0">10</text>
<text x="1.8088" y="0.635" size="1.27" layer="27" ratio="6">&gt;Name</text>
<text x="3.3512" y="0.635" size="1.27" layer="27" ratio="6">&gt;Value</text>
</package>
</packages>
<symbols>
<symbol name="CON10_2X5_SHM" library_version="2">
<pin name="1" x="0" y="0" visible="pad" length="middle"/>
<pin name="2" x="0" y="-2.54" visible="pad" length="middle"/>
<pin name="3" x="0" y="-5.08" visible="pad" length="middle"/>
<pin name="4" x="0" y="-7.62" visible="pad" length="middle"/>
<pin name="5" x="0" y="-10.16" visible="pad" length="middle"/>
<pin name="6" x="0" y="-12.7" visible="pad" length="middle"/>
<pin name="7" x="0" y="-15.24" visible="pad" length="middle"/>
<pin name="8" x="0" y="-17.78" visible="pad" length="middle"/>
<pin name="9" x="0" y="-20.32" visible="pad" length="middle"/>
<pin name="10" x="0" y="-22.86" visible="pad" length="middle"/>
<pin name="11" x="0" y="-25.4" visible="pad" length="middle" direction="pas"/>
<pin name="12" x="0" y="-27.94" visible="pad" length="middle" direction="pas"/>
<wire x1="10.16" y1="0" x2="5.08" y2="0" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-2.54" x2="5.08" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-5.08" x2="5.08" y2="-5.08" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-7.62" x2="5.08" y2="-7.62" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-10.16" x2="5.08" y2="-10.16" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-12.7" x2="5.08" y2="-12.7" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-15.24" x2="5.08" y2="-15.24" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-17.78" x2="5.08" y2="-17.78" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-20.32" x2="5.08" y2="-20.32" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-22.86" x2="5.08" y2="-22.86" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-25.4" x2="5.08" y2="-25.4" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-27.94" x2="5.08" y2="-27.94" width="0.1524" layer="94"/>
<wire x1="10.16" y1="0" x2="8.89" y2="0.8467" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-2.54" x2="8.89" y2="-1.6933" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-5.08" x2="8.89" y2="-4.2333" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-7.62" x2="8.89" y2="-6.7733" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-10.16" x2="8.89" y2="-9.3133" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-12.7" x2="8.89" y2="-11.8533" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-15.24" x2="8.89" y2="-14.3933" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-17.78" x2="8.89" y2="-16.9333" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-20.32" x2="8.89" y2="-19.4733" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-22.86" x2="8.89" y2="-22.0133" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-25.4" x2="8.89" y2="-24.5533" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-27.94" x2="8.89" y2="-27.0933" width="0.1524" layer="94"/>
<wire x1="10.16" y1="0" x2="8.89" y2="-0.8467" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-2.54" x2="8.89" y2="-3.3867" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-5.08" x2="8.89" y2="-5.9267" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-7.62" x2="8.89" y2="-8.4667" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-10.16" x2="8.89" y2="-11.0067" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-12.7" x2="8.89" y2="-13.5467" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-15.24" x2="8.89" y2="-16.0867" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-17.78" x2="8.89" y2="-18.6267" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-20.32" x2="8.89" y2="-21.1667" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-22.86" x2="8.89" y2="-23.7067" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-25.4" x2="8.89" y2="-26.2467" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-27.94" x2="8.89" y2="-28.7867" width="0.1524" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-30.48" width="0.1524" layer="94"/>
<wire x1="5.08" y1="-30.48" x2="12.7" y2="-30.48" width="0.1524" layer="94"/>
<wire x1="12.7" y1="-30.48" x2="12.7" y2="2.54" width="0.1524" layer="94"/>
<wire x1="12.7" y1="2.54" x2="5.08" y2="2.54" width="0.1524" layer="94"/>
<text x="4.1646" y="5.3086" size="2.083" layer="95" ratio="6">&gt;Name</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="5499206-1" prefix="J" library_version="2">
<gates>
<gate name="A" symbol="CON10_2X5_SHM" x="0" y="0"/>
</gates>
<devices>
<device name="CON10_2X5_SHM_TEC" package="CON10_2X5_SHM_TEC">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="10" pad="10"/>
<connect gate="A" pin="11" pad="11"/>
<connect gate="A" pin="12" pad="12"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
<connect gate="A" pin="7" pad="7"/>
<connect gate="A" pin="8" pad="8"/>
<connect gate="A" pin="9" pad="9"/>
</connects>
<technologies>
<technology name="">
<attribute name="COPYRIGHT" value="Copyright (C) 2025 Ultra Librarian. All rights reserved." constant="no"/>
<attribute name="DESCRIPTION" value="A/L UNIV HDR 10P VERT LAT" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="TE Connectivity" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="5499206-1" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Diode" urn="urn:adsk.eagle:library:16378169">
<description>PN Junction, BridgeRectifier, Zener, Schottky, Switching</description>
<packages>
<package name="SOD3715X135" urn="urn:adsk.eagle:footprint:48498302/2" library_version="22">
<description>SOD123G, DO-215-AD package with 3.70 mm span with body size 2.70 X 1.55 X 1.35 mm</description>
<wire x1="1.5" y1="1" x2="-2.7" y2="1" width="0.2" layer="21"/>
<wire x1="-2.7" y1="1" x2="-2.7" y2="-1" width="0.2" layer="21"/>
<wire x1="-2.7" y1="-1" x2="1.5" y2="-1" width="0.2" layer="21"/>
<wire x1="1.425" y1="-0.85" x2="-1.425" y2="-0.85" width="0.1" layer="51"/>
<wire x1="-1.425" y1="-0.85" x2="-1.425" y2="0.85" width="0.1" layer="51"/>
<wire x1="-1.425" y1="0.85" x2="1.425" y2="0.85" width="0.1" layer="51"/>
<wire x1="1.425" y1="0.85" x2="1.425" y2="-0.85" width="0.1" layer="51"/>
<smd name="1" x="-1.7215" y="0" dx="1.1272" dy="0.7839" layer="1"/>
<smd name="2" x="1.7215" y="0" dx="1.1272" dy="0.7839" layer="1"/>
<text x="0" y="2.54" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="center">&gt;VALUE</text>
<polygon width="0.1524" layer="39" pour="solid">
<vertex x="-2.8238" y="-1.1238"/>
<vertex x="2.4238" y="-1.1238"/>
<vertex x="2.4238" y="1.1238"/>
<vertex x="-2.8238" y="1.1238"/>
</polygon>
</package>
<package name="DIOMELF3516" urn="urn:adsk.eagle:footprint:16378178/5" library_version="22">
<description>DO-213AA, SOD-80, MiniMELF Glass Diode package with 3.50 mm length and 1.65 mm diameter</description>
<wire x1="0.983" y1="1.2" x2="-2.6" y2="1.2" width="0.2" layer="21"/>
<wire x1="-2.6" y1="1.2" x2="-2.6" y2="-1.2" width="0.2" layer="21"/>
<wire x1="-2.6" y1="-1.2" x2="0.983" y2="-1.2" width="0.2" layer="21"/>
<wire x1="1.85" y1="-0.85" x2="-1.85" y2="-0.85" width="0.1" layer="51"/>
<wire x1="-1.85" y1="-0.85" x2="-1.85" y2="0.85" width="0.1" layer="51"/>
<wire x1="-1.85" y1="0.85" x2="1.85" y2="0.85" width="0.1" layer="51"/>
<wire x1="1.85" y1="0.85" x2="1.85" y2="-0.85" width="0.1" layer="51"/>
<smd name="1" x="-1.6203" y="0" dx="1.2747" dy="1.85" layer="1"/>
<smd name="2" x="1.6203" y="0" dx="1.2747" dy="1.85" layer="1"/>
<text x="0" y="2.54" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="center">&gt;VALUE</text>
<polygon width="0.1524" layer="39" pour="solid">
<vertex x="-2.7238" y="-1.3238"/>
<vertex x="2.4238" y="-1.3238"/>
<vertex x="2.4238" y="1.3238"/>
<vertex x="-2.7238" y="1.3238"/>
</polygon>
</package>
<package name="DIOM5226X290N" urn="urn:adsk.eagle:footprint:16378179/5" library_version="22">
<description>DO-214AC(SMA) Molded Body package with body size 5.20 X 2.60 X 2.90 mm</description>
<wire x1="2.8" y1="1.6" x2="-3.7" y2="1.6" width="0.2" layer="21"/>
<wire x1="-3.7" y1="1.6" x2="-3.7" y2="-1.6" width="0.2" layer="21"/>
<wire x1="-3.7" y1="-1.6" x2="2.8" y2="-1.6" width="0.2" layer="21"/>
<wire x1="2.8" y1="-1.475" x2="-2.8" y2="-1.475" width="0.1" layer="51"/>
<wire x1="-2.8" y1="-1.475" x2="-2.8" y2="1.475" width="0.1" layer="51"/>
<wire x1="-2.8" y1="1.475" x2="2.8" y2="1.475" width="0.1" layer="51"/>
<wire x1="2.8" y1="1.475" x2="2.8" y2="-1.475" width="0.1" layer="51"/>
<smd name="1" x="-2.1079" y="0" dx="2.392" dy="1.5653" layer="1"/>
<smd name="2" x="2.1079" y="0" dx="2.392" dy="1.5653" layer="1"/>
<text x="0" y="2.54" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
<polygon width="0.1524" layer="39" pour="solid">
<vertex x="-3.8238" y="-1.7238"/>
<vertex x="3.4238" y="-1.7238"/>
<vertex x="3.4238" y="1.7238"/>
<vertex x="-3.8238" y="1.7238"/>
</polygon>
</package>
<package name="DO41-10" urn="urn:adsk.eagle:footprint:49025815/2" library_version="22">
<description>Diode, DO-41 (DO-204AL), Diameter 2.54 mm, Horizontal, Grid 10.16 mm</description>
<wire x1="2" y1="-1.3" x2="-2" y2="-1.3" width="0.2" layer="21"/>
<wire x1="2" y1="-1.3" x2="2" y2="1.3" width="0.2" layer="21"/>
<wire x1="-2" y1="1.3" x2="2" y2="1.3" width="0.2" layer="21"/>
<wire x1="-2" y1="1.3" x2="-2" y2="-1.3" width="0.2" layer="21"/>
<wire x1="-0.635" y1="0" x2="0" y2="0" width="0.2" layer="21"/>
<wire x1="1.016" y1="0.635" x2="1.016" y2="-0.635" width="0.2" layer="21"/>
<wire x1="1.016" y1="-0.635" x2="0" y2="0" width="0.2" layer="21"/>
<wire x1="0" y1="0" x2="1.524" y2="0" width="0.2" layer="21"/>
<wire x1="0" y1="0" x2="1.016" y2="0.635" width="0.2" layer="21"/>
<wire x1="0" y1="0.635" x2="0" y2="0" width="0.2" layer="21"/>
<wire x1="0" y1="0" x2="0" y2="-0.635" width="0.2" layer="21"/>
<rectangle x1="-1.651" y1="-1.27" x2="-1.143" y2="1.27" layer="21"/>
<rectangle x1="2.032" y1="-0.381" x2="5.08" y2="0.381" layer="51"/>
<rectangle x1="-5.08" y1="-0.381" x2="-2.032" y2="0.381" layer="51"/>
<pad name="A" x="5.08" y="0" drill="1.1176"/>
<pad name="C" x="-5.08" y="0" drill="1.1176"/>
<text x="0" y="2.54" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="center">&gt;VALUE</text>
<polygon width="0.1524" layer="21" pour="solid">
<vertex x="0.143771875" y="0"/>
<vertex x="0.9398" y="-0.497515625"/>
<vertex x="0.9398" y="0.497515625"/>
</polygon>
<polygon width="0.1524" layer="39" pour="solid">
<vertex x="-6.1238" y="-1.4238"/>
<vertex x="6.1238" y="-1.4238"/>
<vertex x="6.1238" y="1.4238"/>
<vertex x="-6.1238" y="1.4238"/>
</polygon>
</package>
<package name="DIOMELF5024" urn="urn:adsk.eagle:footprint:16378176/5" library_version="22">
<description>DO-213AB(5025-METRIC) MELF Diode package with 5.00 mm length and 2.49 mm diameter</description>
<wire x1="1.9" y1="1.7" x2="-3.3" y2="1.7" width="0.2" layer="21"/>
<wire x1="-3.3" y1="1.7" x2="-3.3" y2="-1.7" width="0.2" layer="21"/>
<wire x1="-3.3" y1="-1.7" x2="1.9" y2="-1.7" width="0.2" layer="21"/>
<wire x1="2.6" y1="-1.27" x2="-2.6" y2="-1.27" width="0.1" layer="51"/>
<wire x1="-2.6" y1="-1.27" x2="-2.6" y2="1.27" width="0.1" layer="51"/>
<wire x1="-2.6" y1="1.27" x2="2.6" y2="1.27" width="0.1" layer="51"/>
<wire x1="2.6" y1="1.27" x2="2.6" y2="-1.27" width="0.1" layer="51"/>
<smd name="1" x="-2.4296" y="0" dx="1.1561" dy="2.69" layer="1"/>
<smd name="2" x="2.4296" y="0" dx="1.1561" dy="2.69" layer="1"/>
<text x="0" y="2.54" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
<polygon width="0.1524" layer="39" pour="solid">
<vertex x="-3.4238" y="-1.8238"/>
<vertex x="3.1238" y="-1.8238"/>
<vertex x="3.1238" y="1.8238"/>
<vertex x="-3.4238" y="1.8238"/>
</polygon>
</package>
<package name="SOD6126X290" urn="urn:adsk.eagle:footprint:48498294/2" library_version="22">
<description>DO-215-AC SOD package with 6.10 mm span with body size 4.33 X 2.60 X 2.90 mm</description>
<wire x1="2.4" y1="1.6" x2="-4" y2="1.6" width="0.2" layer="21"/>
<wire x1="-4" y1="1.6" x2="-4" y2="-1.6" width="0.2" layer="21"/>
<wire x1="-4" y1="-1.6" x2="2.4" y2="-1.6" width="0.2" layer="21"/>
<wire x1="2.3" y1="-1.475" x2="-2.3" y2="-1.475" width="0.1" layer="51"/>
<wire x1="-2.3" y1="-1.475" x2="-2.3" y2="1.475" width="0.1" layer="51"/>
<wire x1="-2.3" y1="1.475" x2="2.3" y2="1.475" width="0.1" layer="51"/>
<wire x1="2.3" y1="1.475" x2="2.3" y2="-1.475" width="0.1" layer="51"/>
<smd name="1" x="-2.7048" y="0" dx="1.7981" dy="1.7253" layer="1"/>
<smd name="2" x="2.7048" y="0" dx="1.7981" dy="1.7253" layer="1"/>
<text x="0" y="2.54" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="center">&gt;VALUE</text>
<polygon width="0.1524" layer="39" pour="solid">
<vertex x="-4.1238" y="-1.7238"/>
<vertex x="3.7238" y="-1.7238"/>
<vertex x="3.7238" y="1.7238"/>
<vertex x="-4.1238" y="1.7238"/>
</polygon>
</package>
<package name="SOD6126X350" urn="urn:adsk.eagle:footprint:48498298/2" library_version="22">
<description>DO-215-BA, SOD package with 6.10 mm span with body size 4.20 X 2.65 X 3.50 mm</description>
<wire x1="2.3" y1="1.8" x2="-4" y2="1.8" width="0.2" layer="21"/>
<wire x1="-4" y1="1.8" x2="-4" y2="-1.8" width="0.2" layer="21"/>
<wire x1="-4" y1="-1.8" x2="2.3" y2="-1.8" width="0.2" layer="21"/>
<wire x1="2.225" y1="-1.65" x2="-2.225" y2="-1.65" width="0.1" layer="51"/>
<wire x1="-2.225" y1="-1.65" x2="-2.225" y2="1.65" width="0.1" layer="51"/>
<wire x1="-2.225" y1="1.65" x2="2.225" y2="1.65" width="0.1" layer="51"/>
<wire x1="2.225" y1="1.65" x2="2.225" y2="-1.65" width="0.1" layer="51"/>
<smd name="1" x="-2.7048" y="0" dx="1.7981" dy="1.7689" layer="1"/>
<smd name="2" x="2.7048" y="0" dx="1.7981" dy="1.7689" layer="1"/>
<text x="0" y="2.54" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
<polygon width="0.1524" layer="39" pour="solid">
<vertex x="-4.1238" y="-1.9238"/>
<vertex x="3.8238" y="-1.9238"/>
<vertex x="3.8238" y="1.9238"/>
<vertex x="-4.1238" y="1.9238"/>
</polygon>
</package>
<package name="SOD6236X265" urn="urn:adsk.eagle:footprint:48498291/2" library_version="22">
<description>DO-215-AA, SOD package with 6.22 mm span with body size 4.33 X 3.63 X 2.65 mm</description>
<wire x1="2.4" y1="2.1" x2="-4" y2="2.1" width="0.2" layer="21"/>
<wire x1="-4" y1="2.1" x2="-4" y2="-2.1" width="0.2" layer="21"/>
<wire x1="-4" y1="-2.1" x2="2.4" y2="-2.1" width="0.2" layer="21"/>
<wire x1="2.3" y1="-1.975" x2="-2.3" y2="-1.975" width="0.1" layer="51"/>
<wire x1="-2.3" y1="-1.975" x2="-2.3" y2="1.975" width="0.1" layer="51"/>
<wire x1="-2.3" y1="1.975" x2="2.3" y2="1.975" width="0.1" layer="51"/>
<wire x1="2.3" y1="1.975" x2="2.3" y2="-1.975" width="0.1" layer="51"/>
<smd name="1" x="-2.7561" y="0" dx="1.699" dy="2.2839" layer="1"/>
<smd name="2" x="2.7561" y="0" dx="1.699" dy="2.2839" layer="1"/>
<text x="0" y="3.81" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="-3.81" size="1.27" layer="27" align="center">&gt;VALUE</text>
<polygon width="0.1524" layer="39" pour="solid">
<vertex x="-4.1238" y="-2.2238"/>
<vertex x="3.7238" y="-2.2238"/>
<vertex x="3.7238" y="2.2238"/>
<vertex x="-4.1238" y="2.2238"/>
</polygon>
</package>
<package name="SOD9959X265" urn="urn:adsk.eagle:footprint:48498296/2" library_version="22">
<description>DO-215-AB, SOD package with 9.93 mm span with body size 6.88 X 5.90 X 2.65 mm</description>
<wire x1="3.7" y1="3.2" x2="-5.9" y2="3.2" width="0.2" layer="21"/>
<wire x1="-5.9" y1="3.2" x2="-5.9" y2="-3.2" width="0.2" layer="21"/>
<wire x1="-5.9" y1="-3.2" x2="3.7" y2="-3.2" width="0.2" layer="21"/>
<wire x1="3.575" y1="-3.125" x2="-3.575" y2="-3.125" width="0.1" layer="51"/>
<wire x1="-3.575" y1="-3.125" x2="-3.575" y2="3.125" width="0.1" layer="51"/>
<wire x1="-3.575" y1="3.125" x2="3.575" y2="3.125" width="0.1" layer="51"/>
<wire x1="3.575" y1="3.125" x2="3.575" y2="-3.125" width="0.1" layer="51"/>
<smd name="1" x="-4.5203" y="0" dx="1.8706" dy="3.2802" layer="1"/>
<smd name="2" x="4.5203" y="0" dx="1.8706" dy="3.2802" layer="1"/>
<text x="0" y="3.81" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-3.81" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
<polygon width="0.1524" layer="39" pour="solid">
<vertex x="-6.0238" y="-3.3238"/>
<vertex x="5.6238" y="-3.3238"/>
<vertex x="5.6238" y="3.3238"/>
<vertex x="-6.0238" y="3.3238"/>
</polygon>
</package>
<package name="SODFL2513X70" urn="urn:adsk.eagle:footprint:48498300/2" library_version="22">
<description>DO-219-AC, SOD323F, SODFL package with 2.50 mm span with body size 1.90 X 1.30 X 0.70 mm</description>
<wire x1="1.1" y1="0.8" x2="-1.9" y2="0.8" width="0.2" layer="21"/>
<wire x1="-1.9" y1="0.8" x2="-1.9" y2="-0.8" width="0.2" layer="21"/>
<wire x1="-1.9" y1="-0.8" x2="1.1" y2="-0.8" width="0.2" layer="21"/>
<wire x1="1" y1="-0.7" x2="-1" y2="-0.7" width="0.1" layer="51"/>
<wire x1="-1" y1="-0.7" x2="-1" y2="0.7" width="0.1" layer="51"/>
<wire x1="-1" y1="0.7" x2="1" y2="0.7" width="0.1" layer="51"/>
<wire x1="1" y1="0.7" x2="1" y2="-0.7" width="0.1" layer="51"/>
<smd name="1" x="-1.065" y="0" dx="0.9854" dy="0.7739" layer="1"/>
<smd name="2" x="1.065" y="0" dx="0.9854" dy="0.7739" layer="1"/>
<text x="0" y="1.27" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.27" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
<polygon width="0.1524" layer="39" pour="solid">
<vertex x="-2.0238" y="-0.9238"/>
<vertex x="1.7238" y="-0.9238"/>
<vertex x="1.7238" y="0.9238"/>
<vertex x="-2.0238" y="0.9238"/>
</polygon>
</package>
<package name="SODFL2513X75" urn="urn:adsk.eagle:footprint:48498297/2" library_version="22">
<description>DO-219-AD, SODFL package with 2.50 mm span with body size 2.20 X 1.30 X 0.75 mm</description>
<wire x1="1.2" y1="0.8" x2="-1.9" y2="0.8" width="0.2" layer="21"/>
<wire x1="-1.9" y1="0.8" x2="-1.9" y2="-0.8" width="0.2" layer="21"/>
<wire x1="-1.9" y1="-0.8" x2="1.2" y2="-0.8" width="0.2" layer="21"/>
<wire x1="1.15" y1="-0.7" x2="-1.15" y2="-0.7" width="0.1" layer="51"/>
<wire x1="-1.15" y1="-0.7" x2="-1.15" y2="0.7" width="0.1" layer="51"/>
<wire x1="-1.15" y1="0.7" x2="1.15" y2="0.7" width="0.1" layer="51"/>
<wire x1="1.15" y1="0.7" x2="1.15" y2="-0.7" width="0.1" layer="51"/>
<smd name="1" x="-0.7394" y="0" dx="1.6364" dy="1.003" layer="1"/>
<smd name="2" x="1.0394" y="0" dx="1.0027" dy="0.7739" layer="1"/>
<text x="0" y="1.27" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.27" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
<polygon width="0.1524" layer="39" pour="solid">
<vertex x="-2.0238" y="-0.9238"/>
<vertex x="1.7238" y="-0.9238"/>
<vertex x="1.7238" y="0.9238"/>
<vertex x="-2.0238" y="0.9238"/>
</polygon>
</package>
<package name="SODFL3718X115" urn="urn:adsk.eagle:footprint:48498299/2" library_version="22">
<description>DO-219-AB, SOD123F, SODFL package with 3.70 mm span with body size 2.80 X 1.80 X 1.15 mm</description>
<wire x1="1.5" y1="1.1" x2="-2.5" y2="1.1" width="0.2" layer="21"/>
<wire x1="-2.5" y1="1.1" x2="-2.5" y2="-1.1" width="0.2" layer="21"/>
<wire x1="-2.5" y1="-1.1" x2="1.5" y2="-1.1" width="0.2" layer="21"/>
<wire x1="1.45" y1="-0.95" x2="-1.45" y2="-0.95" width="0.1" layer="51"/>
<wire x1="-1.45" y1="-0.95" x2="-1.45" y2="0.95" width="0.1" layer="51"/>
<wire x1="-1.45" y1="0.95" x2="1.45" y2="0.95" width="0.1" layer="51"/>
<wire x1="1.45" y1="0.95" x2="1.45" y2="-0.95" width="0.1" layer="51"/>
<smd name="1" x="-1.6004" y="0" dx="1.1146" dy="1.3612" layer="1"/>
<smd name="2" x="1.6004" y="0" dx="1.1146" dy="1.3612" layer="1"/>
<text x="0" y="2.54" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="center">&gt;VALUE</text>
<polygon width="0.1524" layer="39" pour="solid">
<vertex x="-2.6238" y="-1.2238"/>
<vertex x="2.3238" y="-1.2238"/>
<vertex x="2.3238" y="1.2238"/>
<vertex x="-2.6238" y="1.2238"/>
</polygon>
</package>
<package name="SODFL3718X140" urn="urn:adsk.eagle:footprint:48498290/2" library_version="22">
<description>DO-219-AA, SODFL package with 3.70 mm span with body size 2.80 X 1.80 X 1.40 mm</description>
<wire x1="1.5" y1="1.1" x2="-2.5" y2="1.1" width="0.2" layer="21"/>
<wire x1="-2.5" y1="1.1" x2="-2.5" y2="-1.1" width="0.2" layer="21"/>
<wire x1="-2.5" y1="-1.1" x2="1.5" y2="-1.1" width="0.2" layer="21"/>
<wire x1="1.45" y1="-0.95" x2="-1.45" y2="-0.95" width="0.1" layer="51"/>
<wire x1="-1.45" y1="-0.95" x2="-1.45" y2="0.95" width="0.1" layer="51"/>
<wire x1="-1.45" y1="0.95" x2="1.45" y2="0.95" width="0.1" layer="51"/>
<wire x1="1.45" y1="0.95" x2="1.45" y2="-0.95" width="0.1" layer="51"/>
<smd name="1" x="-1.5233" y="0" dx="1.2688" dy="1.3612" layer="1"/>
<smd name="2" x="1.5233" y="0" dx="1.2688" dy="1.3612" layer="1"/>
<text x="0" y="2.54" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="center">&gt;VALUE</text>
<polygon width="0.1524" layer="39" pour="solid">
<vertex x="-2.6238" y="-1.2238"/>
<vertex x="2.2238" y="-1.2238"/>
<vertex x="2.2238" y="1.2238"/>
<vertex x="-2.6238" y="1.2238"/>
</polygon>
</package>
<package name="SODFL5336X110" urn="urn:adsk.eagle:footprint:48498301/2" library_version="22">
<description>DO-221-AA, SODFL package with 5.35 mm span with body size 4.33 X 3.63 X 1.10 mm</description>
<wire x1="2.4" y1="2.1" x2="-3.3" y2="2.1" width="0.2" layer="21"/>
<wire x1="-3.3" y1="2.1" x2="-3.3" y2="-2.1" width="0.2" layer="21"/>
<wire x1="-3.3" y1="-2.1" x2="2.4" y2="-2.1" width="0.2" layer="21"/>
<wire x1="2.3" y1="-1.975" x2="-2.3" y2="-1.975" width="0.1" layer="51"/>
<wire x1="-2.3" y1="-1.975" x2="-2.3" y2="1.975" width="0.1" layer="51"/>
<wire x1="-2.3" y1="1.975" x2="2.3" y2="1.975" width="0.1" layer="51"/>
<wire x1="2.3" y1="1.975" x2="2.3" y2="-1.975" width="0.1" layer="51"/>
<smd name="1" x="-2.1302" y="0" dx="1.752" dy="2.2239" layer="1"/>
<smd name="2" x="2.1302" y="0" dx="1.752" dy="2.2239" layer="1"/>
<text x="0" y="2.54" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
<polygon width="0.1524" layer="39" pour="solid">
<vertex x="-3.4238" y="-2.2238"/>
<vertex x="3.1238" y="-2.2238"/>
<vertex x="3.1238" y="2.2238"/>
<vertex x="-3.4238" y="2.2238"/>
</polygon>
</package>
<package name="SODFL7959X110" urn="urn:adsk.eagle:footprint:48498295/2" library_version="22">
<description>DO-221-AB, SODFL package with 7.95 mm span with body size 6.88 X 5.90 X 1.10 mm</description>
<wire x1="3.7" y1="3.2" x2="-4.6" y2="3.2" width="0.2" layer="21"/>
<wire x1="-4.6" y1="3.2" x2="-4.6" y2="-3.2" width="0.2" layer="21"/>
<wire x1="-4.6" y1="-3.2" x2="3.7" y2="-3.2" width="0.2" layer="21"/>
<wire x1="3.575" y1="-3.125" x2="-3.575" y2="-3.125" width="0.1" layer="51"/>
<wire x1="-3.575" y1="-3.125" x2="-3.575" y2="3.125" width="0.1" layer="51"/>
<wire x1="-3.575" y1="3.125" x2="3.575" y2="3.125" width="0.1" layer="51"/>
<wire x1="3.575" y1="3.125" x2="3.575" y2="-3.125" width="0.1" layer="51"/>
<smd name="1" x="-3.4233" y="0" dx="1.7188" dy="3.2202" layer="1"/>
<smd name="2" x="3.4233" y="0" dx="1.7188" dy="3.2202" layer="1"/>
<text x="0" y="3.81" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-3.81" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
<polygon width="0.1524" layer="39" pour="solid">
<vertex x="-4.7238" y="-3.3238"/>
<vertex x="4.4238" y="-3.3238"/>
<vertex x="4.4238" y="3.3238"/>
<vertex x="-4.7238" y="3.3238"/>
</polygon>
</package>
<package name="SODFL5226X110" urn="urn:adsk.eagle:footprint:48498292/2" library_version="22">
<description>DO-221-AC, SODFL package with 5.20 mm span with body size 4.28 X 2.60 X 1.10 mm</description>
<wire x1="2.4" y1="1.6" x2="-3.3" y2="1.6" width="0.2" layer="21"/>
<wire x1="-3.3" y1="1.6" x2="-3.3" y2="-1.6" width="0.2" layer="21"/>
<wire x1="-3.3" y1="-1.6" x2="2.4" y2="-1.6" width="0.2" layer="21"/>
<wire x1="2.3" y1="-1.475" x2="-2.3" y2="-1.475" width="0.1" layer="51"/>
<wire x1="-2.3" y1="-1.475" x2="-2.3" y2="1.475" width="0.1" layer="51"/>
<wire x1="-2.3" y1="1.475" x2="2.3" y2="1.475" width="0.1" layer="51"/>
<wire x1="2.3" y1="1.475" x2="2.3" y2="-1.475" width="0.1" layer="51"/>
<smd name="1" x="-2.0722" y="0" dx="1.8634" dy="1.6653" layer="1"/>
<smd name="2" x="2.0722" y="0" dx="1.8634" dy="1.6653" layer="1"/>
<text x="0" y="2.54" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="center">&gt;VALUE</text>
<polygon width="0.1524" layer="39" pour="solid">
<vertex x="-3.4238" y="-1.7238"/>
<vertex x="3.1238" y="-1.7238"/>
<vertex x="3.1238" y="1.7238"/>
<vertex x="-3.4238" y="1.7238"/>
</polygon>
</package>
<package name="SODFL4725X110" urn="urn:adsk.eagle:footprint:48498293/2" library_version="22">
<description>DO-221-AD, SODFL package with 4.70 mm span with body size 3.80 X 2.50 X 1.10 mm</description>
<wire x1="2.1" y1="1.5" x2="-3" y2="1.5" width="0.2" layer="21"/>
<wire x1="-3" y1="1.5" x2="-3" y2="-1.5" width="0.2" layer="21"/>
<wire x1="-3" y1="-1.5" x2="2.1" y2="-1.5" width="0.2" layer="21"/>
<wire x1="2" y1="-1.35" x2="-2" y2="-1.35" width="0.1" layer="51"/>
<wire x1="-2" y1="-1.35" x2="-2" y2="1.35" width="0.1" layer="51"/>
<wire x1="-2" y1="1.35" x2="2" y2="1.35" width="0.1" layer="51"/>
<wire x1="2" y1="1.35" x2="2" y2="-1.35" width="0.1" layer="51"/>
<smd name="1" x="-2.11" y="0" dx="1.1904" dy="2.0153" layer="1"/>
<smd name="2" x="2.11" y="0" dx="1.1904" dy="2.0153" layer="1"/>
<text x="0" y="2.54" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="center">&gt;VALUE</text>
<polygon width="0.1524" layer="39" pour="solid">
<vertex x="-3.1238" y="-1.6238"/>
<vertex x="2.8238" y="-1.6238"/>
<vertex x="2.8238" y="1.6238"/>
<vertex x="-3.1238" y="1.6238"/>
</polygon>
</package>
<package name="SODFL1608X70" urn="urn:adsk.eagle:footprint:16378177/5" library_version="22">
<description>SODFL(1608-METRIC) package with 1.60 mm span with body size 1.20 X 0.80 X 0.70 mm</description>
<wire x1="0.7" y1="0.6" x2="-1.3" y2="0.6" width="0.2" layer="21"/>
<wire x1="-1.3" y1="0.6" x2="-1.3" y2="-0.6" width="0.2" layer="21"/>
<wire x1="-1.3" y1="-0.6" x2="0.7" y2="-0.6" width="0.2" layer="21"/>
<wire x1="0.65" y1="-0.45" x2="-0.65" y2="-0.45" width="0.1" layer="51"/>
<wire x1="-0.65" y1="-0.45" x2="-0.65" y2="0.45" width="0.1" layer="51"/>
<wire x1="-0.65" y1="0.45" x2="0.65" y2="0.45" width="0.1" layer="51"/>
<wire x1="0.65" y1="0.45" x2="0.65" y2="-0.45" width="0.1" layer="51"/>
<smd name="1" x="-0.7956" y="0" dx="0.538" dy="0.4" layer="1"/>
<smd name="2" x="0.7956" y="0" dx="0.538" dy="0.4" layer="1"/>
<text x="0" y="1.27" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.27" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
<polygon width="0.1524" layer="39" pour="solid">
<vertex x="-1.4238" y="-0.7238"/>
<vertex x="1.2238" y="-0.7238"/>
<vertex x="1.2238" y="0.7238"/>
<vertex x="-1.4238" y="0.7238"/>
</polygon>
</package>
<package name="DIOM5336X265N" urn="urn:adsk.eagle:footprint:16378175/5" library_version="22">
<description>DO-214AA(SMB) Molded Body package with body size 5.35 X 3.63 X 2.65 mm</description>
<wire x1="2.8" y1="2.1" x2="-3.7" y2="2.1" width="0.2" layer="21"/>
<wire x1="-3.7" y1="2.1" x2="-3.7" y2="-2.1" width="0.2" layer="21"/>
<wire x1="-3.7" y1="-2.1" x2="2.8" y2="-2.1" width="0.2" layer="21"/>
<wire x1="2.8" y1="-1.975" x2="-2.8" y2="-1.975" width="0.1" layer="51"/>
<wire x1="-2.8" y1="-1.975" x2="-2.8" y2="1.975" width="0.1" layer="51"/>
<wire x1="-2.8" y1="1.975" x2="2.8" y2="1.975" width="0.1" layer="51"/>
<wire x1="2.8" y1="1.975" x2="2.8" y2="-1.975" width="0.1" layer="51"/>
<smd name="1" x="-2.1641" y="0" dx="2.2841" dy="2.1239" layer="1"/>
<smd name="2" x="2.1641" y="0" dx="2.2841" dy="2.1239" layer="1"/>
<text x="0" y="2.54" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
<polygon width="0.1524" layer="39" pour="solid">
<vertex x="-3.8238" y="-2.2238"/>
<vertex x="3.4238" y="-2.2238"/>
<vertex x="3.4238" y="2.2238"/>
<vertex x="-3.8238" y="2.2238"/>
</polygon>
</package>
<package name="DIOM7959X625N" urn="urn:adsk.eagle:footprint:16378174/5" library_version="22">
<description>DO-214AB(SMC) Molded Body package with body size 7.95 X 5.90 X 6.25 mm</description>
<wire x1="4.1" y1="3.2" x2="-5" y2="3.2" width="0.2" layer="21"/>
<wire x1="-5" y1="3.2" x2="-5" y2="-3.2" width="0.2" layer="21"/>
<wire x1="-5" y1="-3.2" x2="4.1" y2="-3.2" width="0.2" layer="21"/>
<wire x1="4.075" y1="-3.125" x2="-4.075" y2="-3.125" width="0.1" layer="51"/>
<wire x1="-4.075" y1="-3.125" x2="-4.075" y2="3.125" width="0.1" layer="51"/>
<wire x1="-4.075" y1="3.125" x2="4.075" y2="3.125" width="0.1" layer="51"/>
<wire x1="4.075" y1="3.125" x2="4.075" y2="-3.125" width="0.1" layer="51"/>
<smd name="1" x="-3.4567" y="0" dx="2.2518" dy="3.1202" layer="1"/>
<smd name="2" x="3.4567" y="0" dx="2.2518" dy="3.1202" layer="1"/>
<text x="0" y="3.81" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-3.81" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
<polygon width="0.1524" layer="39" pour="solid">
<vertex x="-5.1238" y="-3.3238"/>
<vertex x="4.7238" y="-3.3238"/>
<vertex x="4.7238" y="3.3238"/>
<vertex x="-5.1238" y="3.3238"/>
</polygon>
</package>
</packages>
<packages3d>
<package3d name="SOD3715X135" urn="urn:adsk.eagle:package:48498329/2" type="model">
<description>SOD123G, DO-215-AD package with 3.70 mm span with body size 2.70 X 1.55 X 1.35 mm</description>
<packageinstances>
<packageinstance name="SOD3715X135"/>
</packageinstances>
</package3d>
<package3d name="DIOMELF3516" urn="urn:adsk.eagle:package:16378190/7" type="model">
<description>DO-213AA, SOD-80, MiniMELF Glass Diode package with 3.50 mm length and 1.65 mm diameter</description>
<packageinstances>
<packageinstance name="DIOMELF3516"/>
</packageinstances>
</package3d>
<package3d name="DIOM5226X290N" urn="urn:adsk.eagle:package:16378188/5" type="model">
<description>DO-214AC(SMA) Molded Body package with body size 5.20 X 2.60 X 2.90 mm</description>
<packageinstances>
<packageinstance name="DIOM5226X290N"/>
</packageinstances>
</package3d>
<package3d name="DO41-10" urn="urn:adsk.eagle:package:49025819/2" type="model">
<description>Diode, DO-41 (DO-204AL), Diameter 2.54 mm, Horizontal, Grid 10.16 mm</description>
<packageinstances>
<packageinstance name="DO41-10"/>
</packageinstances>
</package3d>
<package3d name="DIOMELF5024" urn="urn:adsk.eagle:package:16378191/5" type="model">
<description>DO-213AB(5025-METRIC) MELF Diode package with 5.00 mm length and 2.49 mm diameter</description>
<packageinstances>
<packageinstance name="DIOMELF5024"/>
</packageinstances>
</package3d>
<package3d name="SOD6126X290" urn="urn:adsk.eagle:package:48498328/2" type="model">
<description>DO-215-AC SOD package with 6.10 mm span with body size 4.33 X 2.60 X 2.90 mm</description>
<packageinstances>
<packageinstance name="SOD6126X290"/>
</packageinstances>
</package3d>
<package3d name="SOD6126X350" urn="urn:adsk.eagle:package:48498327/2" type="model">
<description>DO-215-BA, SOD package with 6.10 mm span with body size 4.20 X 2.65 X 3.50 mm</description>
<packageinstances>
<packageinstance name="SOD6126X350"/>
</packageinstances>
</package3d>
<package3d name="SOD6236X265" urn="urn:adsk.eagle:package:48498334/2" type="model">
<description>DO-215-AA, SOD package with 6.22 mm span with body size 4.33 X 3.63 X 2.65 mm</description>
<packageinstances>
<packageinstance name="SOD6236X265"/>
</packageinstances>
</package3d>
<package3d name="SOD9959X265" urn="urn:adsk.eagle:package:48498324/2" type="model">
<description>DO-215-AB, SOD package with 9.93 mm span with body size 6.88 X 5.90 X 2.65 mm</description>
<packageinstances>
<packageinstance name="SOD9959X265"/>
</packageinstances>
</package3d>
<package3d name="SODFL2513X70" urn="urn:adsk.eagle:package:48498332/2" type="model">
<description>DO-219-AC, SOD323F, SODFL package with 2.50 mm span with body size 1.90 X 1.30 X 0.70 mm</description>
<packageinstances>
<packageinstance name="SODFL2513X70"/>
</packageinstances>
</package3d>
<package3d name="SODFL2513X75" urn="urn:adsk.eagle:package:48498330/2" type="model">
<description>DO-219-AD, SODFL package with 2.50 mm span with body size 2.20 X 1.30 X 0.75 mm</description>
<packageinstances>
<packageinstance name="SODFL2513X75"/>
</packageinstances>
</package3d>
<package3d name="SODFL3718X115" urn="urn:adsk.eagle:package:48498333/2" type="model">
<description>DO-219-AB, SOD123F, SODFL package with 3.70 mm span with body size 2.80 X 1.80 X 1.15 mm</description>
<packageinstances>
<packageinstance name="SODFL3718X115"/>
</packageinstances>
</package3d>
<package3d name="SODFL3718X140" urn="urn:adsk.eagle:package:48498315/3" type="model">
<description>DO-219-AA, SODFL package with 3.70 mm span with body size 2.80 X 1.80 X 1.40 mm</description>
<packageinstances>
<packageinstance name="SODFL3718X140"/>
</packageinstances>
</package3d>
<package3d name="SODFL5336X110" urn="urn:adsk.eagle:package:48498325/2" type="model">
<description>DO-221-AA, SODFL package with 5.35 mm span with body size 4.33 X 3.63 X 1.10 mm</description>
<packageinstances>
<packageinstance name="SODFL5336X110"/>
</packageinstances>
</package3d>
<package3d name="SODFL7959X110" urn="urn:adsk.eagle:package:48498331/2" type="model">
<description>DO-221-AB, SODFL package with 7.95 mm span with body size 6.88 X 5.90 X 1.10 mm</description>
<packageinstances>
<packageinstance name="SODFL7959X110"/>
</packageinstances>
</package3d>
<package3d name="SODFL5226X110" urn="urn:adsk.eagle:package:48498320/2" type="model">
<description>DO-221-AC, SODFL package with 5.20 mm span with body size 4.28 X 2.60 X 1.10 mm</description>
<packageinstances>
<packageinstance name="SODFL5226X110"/>
</packageinstances>
</package3d>
<package3d name="SODFL4725X110" urn="urn:adsk.eagle:package:48498326/2" type="model">
<description>DO-221-AD, SODFL package with 4.70 mm span with body size 3.80 X 2.50 X 1.10 mm</description>
<packageinstances>
<packageinstance name="SODFL4725X110"/>
</packageinstances>
</package3d>
<package3d name="SODFL1608X70" urn="urn:adsk.eagle:package:16378187/5" type="model">
<description>SODFL(1608-METRIC) package with 1.60 mm span with body size 1.20 X 0.80 X 0.70 mm</description>
<packageinstances>
<packageinstance name="SODFL1608X70"/>
</packageinstances>
</package3d>
<package3d name="DIOM5336X265N" urn="urn:adsk.eagle:package:16378189/6" type="model">
<description>DO-214AA(SMB) Molded Body package with body size 5.35 X 3.63 X 2.65 mm</description>
<packageinstances>
<packageinstance name="DIOM5336X265N"/>
</packageinstances>
</package3d>
<package3d name="DIOM7959X625N" urn="urn:adsk.eagle:package:16378186/5" type="model">
<description>DO-214AB(SMC) Molded Body package with body size 7.95 X 5.90 X 6.25 mm</description>
<packageinstances>
<packageinstance name="DIOM7959X625N"/>
</packageinstances>
</package3d>
</packages3d>
<symbols>
<symbol name="DIODE" urn="urn:adsk.eagle:symbol:16378170/5" library_version="20">
<description>Diode</description>
<pin name="A" x="-2.54" y="0" visible="off" length="point" direction="pas" swaplevel="1"/>
<pin name="C" x="2.54" y="0" visible="off" length="point" direction="pas" swaplevel="1" rot="R180"/>
<text x="0" y="2.54" size="1.778" layer="95" align="center">&gt;NAME</text>
<text x="0" y="-2.54" size="1.778" layer="96" align="center">&gt;VALUE</text>
<text x="0" y="-5.08" size="1.778" layer="95" align="center">&gt;SPICEMODEL</text>
<text x="0" y="-7.62" size="1.778" layer="95" align="center">&gt;SPICEEXTRA</text>
<wire x1="-1.27" y1="-1.27" x2="1.27" y2="0" width="0.1524" layer="94"/>
<wire x1="1.27" y1="0" x2="-1.27" y2="1.27" width="0.1524" layer="94"/>
<wire x1="-1.27" y1="1.27" x2="-1.27" y2="0" width="0.1524" layer="94"/>
<wire x1="-1.27" y1="0" x2="-1.27" y2="-1.27" width="0.1524" layer="94"/>
<wire x1="1.397" y1="1.27" x2="1.397" y2="-1.27" width="0.1524" layer="94"/>
<wire x1="2.54" y1="0" x2="1.27" y2="0" width="0.1524" layer="94"/>
<wire x1="-1.27" y1="0" x2="-2.54" y2="0" width="0.1524" layer="94"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="DIODE_" urn="urn:adsk.eagle:component:16378192/14" prefix="D" library_version="22">
<description>Diode Rectifier - Popular Parts</description>
<gates>
<gate name="G$1" symbol="DIODE" x="0" y="0"/>
</gates>
<devices>
<device name="_SOD-80" package="DIOMELF3516">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378190/7"/>
</package3dinstances>
<technologies>
<technology name="LL4148">
<attribute name="DATASHEET" value="https://www.onsemi.com/download/data-sheet/pdf/ll4148-d.pdf" constant="no"/>
<attribute name="DESCRIPTION" value="Diode 100V 200mA Surface Mount DO-213AA (SOD-80 or MiniMELF)" constant="no"/>
<attribute name="FORWARD_CURRENT" value="10mA" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="1V" constant="no"/>
<attribute name="MANUFACTURER" value="onsemi" constant="no"/>
<attribute name="MPN" value="LL4148" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="-55°C ~ 175°C" constant="no"/>
<attribute name="PART_STATUS" value="Active" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="100V" constant="no"/>
<attribute name="ROHS" value="Compliant" constant="no"/>
<attribute name="SERIES" value="LL4148" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="Small Signal Switching Diodes" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
</technology>
<technology name="LL4148-GS08">
<attribute name="DATASHEET" value="https://www.vishay.com/docs/85557/ll4148.pdf" constant="no"/>
<attribute name="DESCRIPTION" value="Diode 75 V 300mA Surface Mount DO-213AA (SOD-80 or MiniMELF)" constant="no"/>
<attribute name="FORWARD_CURRENT" value="50mA" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="1V" constant="no"/>
<attribute name="MANUFACTURER" value="Vishay General Semiconductor - Diodes Division" constant="no"/>
<attribute name="MPN" value="LL4148-GS08" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="-65°C ~ 175°C" constant="no"/>
<attribute name="PART_STATUS" value="Active" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="75V" constant="no"/>
<attribute name="ROHS" value="Compliant" constant="no"/>
<attribute name="SERIES" value="NA" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="Small Signal Switching Diodes" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
</technology>
</technologies>
</device>
<device name="_SOD123G" package="SOD3715X135">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:48498329/2"/>
</package3dinstances>
<technologies>
<technology name="1N4148W-7-F">
<attribute name="DATASHEET" value="https://www.diodes.com/datasheet/download/1N4148W.pdf" constant="no"/>
<attribute name="DESCRIPTION" value="Diode 100 V 300mA Surface Mount SOD-123" constant="no"/>
<attribute name="FORWARD_CURRENT" value="150mA" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="1.25V" constant="no"/>
<attribute name="MANUFACTURER" value="Diodes Incorporated" constant="no"/>
<attribute name="MPN" value="1N4148W-7-F" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="-55°C ~ 150°C" constant="no"/>
<attribute name="PART_STATUS" value="Active" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="100V" constant="no"/>
<attribute name="ROHS" value="Compliant" constant="no"/>
<attribute name="SERIES" value="1N4148" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="Small Signal Switching Diodes" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
</technology>
<technology name="1N4148W-TP">
<attribute name="DATASHEET" value="https://www.mccsemi.com/pdf/products/1N4148W(SOD-123).pdf" constant="no"/>
<attribute name="DESCRIPTION" value="Diode 100 V 150mA Surface Mount SOD-123" constant="no"/>
<attribute name="FORWARD_CURRENT" value="150mA" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="1.25V" constant="no"/>
<attribute name="MANUFACTURER" value="Micro Commercial Co" constant="no"/>
<attribute name="MPN" value="1N4148W-TP" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="-65°C ~ 150°C" constant="no"/>
<attribute name="PART_STATUS" value="Active" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="100V" constant="no"/>
<attribute name="ROHS" value="Compliant" constant="no"/>
<attribute name="SERIES" value="1N4148" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="Small Signal Switching Diodes" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
</technology>
<technology name="1N4448W-TP">
<attribute name="DATASHEET" value="https://www.mccsemi.com/pdf/products/1N4448W(SOD-123).pdf" constant="no"/>
<attribute name="DESCRIPTION" value="Diode 75 V 250mA Surface Mount SOD-123" constant="no"/>
<attribute name="FORWARD_CURRENT" value="100mA" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="1V" constant="no"/>
<attribute name="MANUFACTURER" value="Micro Commercial Co" constant="no"/>
<attribute name="MPN" value="1N4448W-TP" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="-55°C ~ 150°C" constant="no"/>
<attribute name="PART_STATUS" value="Active" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="75V" constant="no"/>
<attribute name="ROHS" value="Compliant" constant="no"/>
<attribute name="SERIES" value="1N4148" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="Small Signal Switching Diodes" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
</technology>
<technology name="MMSD4148T1G">
<attribute name="DATASHEET" value="https://www.onsemi.com/download/data-sheet/pdf/mmsd4148t1-d.pdf" constant="no"/>
<attribute name="DESCRIPTION" value="Diode 100 V 200mA Surface Mount SOD-123" constant="no"/>
<attribute name="FORWARD_CURRENT" value="10mA" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="1V" constant="no"/>
<attribute name="MANUFACTURER" value="onsemi" constant="no"/>
<attribute name="MPN" value="MMSD4148T1G" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="-55°C ~ 150°C" constant="no"/>
<attribute name="PART_STATUS" value="Active" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="100V" constant="no"/>
<attribute name="ROHS" value="Compliant" constant="no"/>
<attribute name="SERIES" value="MMSD4148" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="Small Signal Switching Diodes" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
</technology>
</technologies>
</device>
<device name="_SMA" package="DIOM5226X290N">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378188/5"/>
</package3dinstances>
<technologies>
<technology name="ES1D">
<attribute name="DATASHEET" value="https://www.onsemi.com/download/data-sheet/pdf/es1d-d.pdf" constant="no"/>
<attribute name="DESCRIPTION" value="Diode 200 V 1A Surface Mount DO-214AC (SMA)" constant="no"/>
<attribute name="FORWARD_CURRENT" value="1A" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="920mV" constant="no"/>
<attribute name="MANUFACTURER" value="onsemi" constant="no"/>
<attribute name="MPN" value="ES1D" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="-55°C ~ 150°C" constant="no"/>
<attribute name="PART_STATUS" value="Active" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="200V" constant="no"/>
<attribute name="ROHS" value="Compliant" constant="no"/>
<attribute name="SERIES" value="ES1D" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="Ultra Fast Recovery Rectifiers" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
</technology>
<technology name="ES1G-13-F">
<attribute name="DATASHEET" value="https://www.diodes.com/datasheet/download/ES1G.pdf" constant="no"/>
<attribute name="DESCRIPTION" value="Diode 400 V 1A Surface Mount DO-214AC (SMA)" constant="no"/>
<attribute name="FORWARD_CURRENT" value="1A" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="1.25V" constant="no"/>
<attribute name="MANUFACTURER" value="Diodes Incorporated" constant="no"/>
<attribute name="MPN" value="ES1G-13-F" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="-55°C ~ 150°C" constant="no"/>
<attribute name="PART_STATUS" value="Active" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="400V" constant="no"/>
<attribute name="ROHS" value="Compliant" constant="no"/>
<attribute name="SERIES" value="ES1G" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="Fast Recovery Rectifiers" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
</technology>
<technology name="MRA4003T3G">
<attribute name="DATASHEET" value="https://www.onsemi.com/download/data-sheet/pdf/mra4003t3-d.pdf" constant="no"/>
<attribute name="DESCRIPTION" value="Diode 300 V 1A Surface Mount DO-214AC (SMA)" constant="no"/>
<attribute name="FORWARD_CURRENT" value="1A" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="1.1V" constant="no"/>
<attribute name="MANUFACTURER" value="onsemi" constant="no"/>
<attribute name="MPN" value="MRA4003T3G" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="-55°C ~ 150°C" constant="no"/>
<attribute name="PART_STATUS" value="Active" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="300V" constant="no"/>
<attribute name="ROHS" value="Compliant" constant="no"/>
<attribute name="SERIES" value="MRA4003T3" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="Standard Recovery Rectifier" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
</technology>
<technology name="MRA4007T3G">
<attribute name="DATASHEET" value="https://www.onsemi.com/download/data-sheet/pdf/mra4003t3-d.pdf" constant="no"/>
<attribute name="DESCRIPTION" value="Diode 1000 V 1A Surface Mount DO-214AC (SMA)" constant="no"/>
<attribute name="FORWARD_CURRENT" value="1A" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="1.1V" constant="no"/>
<attribute name="MANUFACTURER" value="onsemi" constant="no"/>
<attribute name="MPN" value="MRA4007T3G" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="-55°C ~ 150°C" constant="no"/>
<attribute name="PART_STATUS" value="Active" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="1000V" constant="no"/>
<attribute name="ROHS" value="Compliant" constant="no"/>
<attribute name="SERIES" value="MRA4007" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="Standard Recovery Rectifier" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
</technology>
<technology name="RS1G-13-F">
<attribute name="DATASHEET" value="https://www.diodes.com/datasheet/download/RS1G.pdf" constant="no"/>
<attribute name="DESCRIPTION" value="Diode 400 V 1A Surface Mount DO-214AC (SMA)" constant="no"/>
<attribute name="FORWARD_CURRENT" value="1A" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="1.3V" constant="no"/>
<attribute name="MANUFACTURER" value="Diodes Incorporated" constant="no"/>
<attribute name="MPN" value="RS1G-13-F" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="-65°C ~ 150°C" constant="no"/>
<attribute name="PART_STATUS" value="Active" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="400V" constant="no"/>
<attribute name="ROHS" value="Compliant" constant="no"/>
<attribute name="SERIES" value="RS1G" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="Fast Recovery Rectifiers" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
</technology>
<technology name="RS1M">
<attribute name="DATASHEET" value="https://www.onsemi.com/download/data-sheet/pdf/rs1m-d.pdf" constant="no"/>
<attribute name="DESCRIPTION" value="Diode 1000 V 1A Surface Mount DO-214AC (SMA)" constant="no"/>
<attribute name="FORWARD_CURRENT" value="1A" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="1.3V" constant="no"/>
<attribute name="MANUFACTURER" value="onsemi" constant="no"/>
<attribute name="MPN" value="RS1M" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="-55°C ~ 150°C" constant="no"/>
<attribute name="PART_STATUS" value="Active" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="1000V" constant="no"/>
<attribute name="ROHS" value="Compliant" constant="no"/>
<attribute name="SERIES" value="RS1" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="Fast Recovery Rectifiers" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
</technology>
<technology name="SS16">
<attribute name="DATASHEET" value="https://www.onsemi.com/download/data-sheet/pdf/ss16-d.pdf" constant="no"/>
<attribute name="DESCRIPTION" value="Diode 60 V 1A Surface Mount DO-214AC (SMA)" constant="no"/>
<attribute name="FORWARD_CURRENT" value="1A" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="700mV" constant="no"/>
<attribute name="MANUFACTURER" value="onsemi" constant="no"/>
<attribute name="MPN" value="SS16" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="-65°C ~ 125°C" constant="no"/>
<attribute name="PART_STATUS" value="Obsolete" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="60V" constant="no"/>
<attribute name="ROHS" value="Compliant" constant="no"/>
<attribute name="SERIES" value="SS16" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="Schottky Rectifiers" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
</technology>
<technology name="US1G-13-F">
<attribute name="DATASHEET" value="https://www.diodes.com/datasheet/download/US1G.pdf" constant="no"/>
<attribute name="DESCRIPTION" value="Diode 400 V 1A Surface Mount DO-214AC (SMA)" constant="no"/>
<attribute name="FORWARD_CURRENT" value="1A" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="1.3V" constant="no"/>
<attribute name="MANUFACTURER" value="Diodes Incorporated " constant="no"/>
<attribute name="MPN" value="US1G-13-F" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="-65°C ~ 150°C" constant="no"/>
<attribute name="PART_STATUS" value="Active" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="400V" constant="no"/>
<attribute name="ROHS" value="Compliant" constant="no"/>
<attribute name="SERIES" value="US1G" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="Fast Recovery Rectifiers" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
</technology>
<technology name="US1G-E3/61T">
<attribute name="DATASHEET" value="https://www.vishay.com/docs/88768/us1_test_dcicons.pdf" constant="no"/>
<attribute name="DESCRIPTION" value="Diode 400 V 1A Surface Mount DO-214AC (SMA)" constant="no"/>
<attribute name="FORWARD_CURRENT" value="1A" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="1V" constant="no"/>
<attribute name="MANUFACTURER" value="Vishay General Semiconductor - Diodes Division" constant="no"/>
<attribute name="MPN" value="US1G-E3/61T" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="-55°C ~ 150°C" constant="no"/>
<attribute name="PART_STATUS" value="Active" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="400V" constant="no"/>
<attribute name="ROHS" value="Compliant" constant="no"/>
<attribute name="SERIES" value="US1" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="Fast Recovery Rectifiers" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
</technology>
</technologies>
</device>
<device name="_DO41-10" package="DO41-10">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:49025819/2"/>
</package3dinstances>
<technologies>
<technology name="1N4004">
<attribute name="DATASHEET" value="https://www.onsemi.com/pdf/datasheet/1n4001-d.pdfv" constant="no"/>
<attribute name="DESCRIPTION" value="Diode 400 V 1A Through Hole DO-41" constant="no"/>
<attribute name="FORWARD_CURRENT" value="1 A" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="1.1 V" constant="no"/>
<attribute name="MANUFACTURER" value="onsemi" constant="no"/>
<attribute name="MPN" value="1N4004" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="-55°C ~ 175°C" constant="no"/>
<attribute name="PART_STATUS" value="Obsolete" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="NA" constant="no"/>
<attribute name="ROHS" value="Compliant" constant="no"/>
<attribute name="SERIES" value="1N4004" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="Single Diodes" constant="no"/>
<attribute name="PACKAGE" value="Through Hole" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="DIODE" urn="urn:adsk.eagle:component:16378193/12" prefix="D" library_version="22">
<description>Diode Rectifier - Generic</description>
<gates>
<gate name="G$1" symbol="DIODE" x="0" y="0"/>
</gates>
<devices>
<device name="DO-213AA(SOD-80)" package="DIOMELF3516">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378190/7"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Generic diode Surface Mount DO-213AA(SOD-80)" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="ZENER_VOLTAGE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-213AB(5025-METRIC)" package="DIOMELF5024">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378191/5"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Generic diode Surface Mount DO-213AB(5025-METRIC MELF)" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="ZENER_VOLTAGE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-215-AD" package="SOD3715X135">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:48498329/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Generic diode Surface Mount DO-215-AD" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="ZENER_VOLTAGE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-215-AC" package="SOD6126X290">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:48498328/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Generic diode Surface Mount DO-215-AC" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="ZENER_VOLTAGE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-215-BA" package="SOD6126X350">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:48498327/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Generic diode Surface Mount DO-215-BA" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="ZENER_VOLTAGE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-215-AA" package="SOD6236X265">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:48498334/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Generic diode Surface Mount DO-215-AA" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="ZENER_VOLTAGE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-215-AB" package="SOD9959X265">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:48498324/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Generic diode Surface Mount DO-215-AB" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="ZENER_VOLTAGE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-219-AC(SOD323F)" package="SODFL2513X70">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:48498332/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Generic diode Surface Mount DO-219-AC(SOD323F)" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="ZENER_VOLTAGE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-219-AD" package="SODFL2513X75">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:48498330/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Generic diode Surface Mount DO-219-AD" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="ZENER_VOLTAGE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-219-AB(SOD123F)" package="SODFL3718X115">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:48498333/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Generic diode Surface Mount DO-219-AB(SOD123F)" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="ZENER_VOLTAGE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-219-AA" package="SODFL3718X140">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:48498315/3"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Generic diode Surface Mount DO-219-AA" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="ZENER_VOLTAGE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-221-AA" package="SODFL5336X110">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:48498325/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Generic diode Surface Mount DO-221-AA" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="ZENER_VOLTAGE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-221-AB" package="SODFL7959X110">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:48498331/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Generic diode Surface Mount DO-221-AB" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="ZENER_VOLTAGE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-221-AC" package="SODFL5226X110">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:48498320/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Generic diode Surface Mount DO-221-AC" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="ZENER_VOLTAGE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-221-AD" package="SODFL4725X110">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:48498326/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Generic diode Surface Mount DO-221-AD" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="ZENER_VOLTAGE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="SODFL(1608-METRIC)" package="SODFL1608X70">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378187/5"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Generic diode Surface Mount SODFL(1608-METRIC)" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="ZENER_VOLTAGE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-214AC(SMA)" package="DIOM5226X290N">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378188/5"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Generic diode Surface Mount DO-214AC(SMA)" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="ZENER_VOLTAGE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-214AA(SMB)" package="DIOM5336X265N">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378189/6"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Generic diode Surface Mount DO-214AA(SMB)" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="ZENER_VOLTAGE" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-214AB(SMC)" package="DIOM7959X625N">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378186/5"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Generic diode Surface Mount DO-214AB(SMC)" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="FORWARD_VOLTAGE" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="CATEGORY_L2" value="Rectifiers" constant="no"/>
<attribute name="CATEGORY_L1" value="Diodes" constant="no"/>
<attribute name="CATEGORY_L3" value="" constant="no"/>
<attribute name="PACKAGE" value="Surface Mount" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="ZENER_VOLTAGE" value="" constant="no"/>
</technology>
</technologies>
</device>
</devices>
<spice>
<pinmapping spiceprefix="D">
<pinmap gate="G$1" pin="A" pinorder="1"/>
<pinmap gate="G$1" pin="C" pinorder="2"/>
</pinmapping>
<model name="DMOD">
**********************
* Autodesk EAGLE - Spice Model File
* Date: 9/17/17
* basic diode intrinsic model
**********************
.MODEL DMOD D</model>
</spice>
</deviceset>
</devicesets>
</library>
<library name="2026-07-04_06-14-31_Library" urn="urn:adsk.wipprod:fs.file:vf.1TXCxOWRTNqve3v8EGVzjg">
<packages>
<package name="CONN_SD-5566-002_02_MOL" library_version="3">
<pad name="1" x="0" y="0" drill="1.4478" diameter="1.9558"/>
<pad name="2" x="0" y="-5.5" drill="1.4478" diameter="1.9558"/>
<wire x1="0" y1="0" x2="0" y2="7.33" width="0.1524" layer="48"/>
<wire x1="4.2" y1="0" x2="4.2" y2="7.33" width="0.1524" layer="48"/>
<wire x1="0" y1="6.949" x2="4.2" y2="6.949" width="0.1524" layer="48"/>
<wire x1="0" y1="6.949" x2="0.254" y2="7.076" width="0.1524" layer="48"/>
<wire x1="0" y1="6.949" x2="0.254" y2="6.822" width="0.1524" layer="48"/>
<wire x1="0.254" y1="7.076" x2="0.254" y2="6.822" width="0.1524" layer="48"/>
<wire x1="4.2" y1="6.949" x2="3.946" y2="7.076" width="0.1524" layer="48"/>
<wire x1="4.2" y1="6.949" x2="3.946" y2="6.822" width="0.1524" layer="48"/>
<wire x1="3.946" y1="7.076" x2="3.946" y2="6.822" width="0.1524" layer="48"/>
<wire x1="-3.0988" y1="2.25" x2="-3.0988" y2="13.045" width="0.1524" layer="48"/>
<wire x1="3.0988" y1="2.25" x2="3.0988" y2="13.045" width="0.1524" layer="48"/>
<wire x1="-3.0988" y1="12.664" x2="3.0988" y2="12.664" width="0.1524" layer="48"/>
<wire x1="-3.0988" y1="12.664" x2="-2.8448" y2="12.791" width="0.1524" layer="48"/>
<wire x1="-3.0988" y1="12.664" x2="-2.8448" y2="12.537" width="0.1524" layer="48"/>
<wire x1="-2.8448" y1="12.791" x2="-2.8448" y2="12.537" width="0.1524" layer="48"/>
<wire x1="3.0988" y1="12.664" x2="2.8448" y2="12.791" width="0.1524" layer="48"/>
<wire x1="3.0988" y1="12.664" x2="2.8448" y2="12.537" width="0.1524" layer="48"/>
<wire x1="2.8448" y1="12.791" x2="2.8448" y2="12.537" width="0.1524" layer="48"/>
<wire x1="0" y1="0" x2="6.0198" y2="0" width="0.1524" layer="48"/>
<wire x1="0" y1="-5.5" x2="6.0198" y2="-5.5" width="0.1524" layer="48"/>
<wire x1="5.6388" y1="0" x2="5.6388" y2="-5.5" width="0.1524" layer="48"/>
<wire x1="5.6388" y1="0" x2="5.5118" y2="-0.254" width="0.1524" layer="48"/>
<wire x1="5.6388" y1="0" x2="5.7658" y2="-0.254" width="0.1524" layer="48"/>
<wire x1="5.5118" y1="-0.254" x2="5.7658" y2="-0.254" width="0.1524" layer="48"/>
<wire x1="5.6388" y1="-5.5" x2="5.5118" y2="-5.246" width="0.1524" layer="48"/>
<wire x1="5.6388" y1="-5.5" x2="5.7658" y2="-5.246" width="0.1524" layer="48"/>
<wire x1="5.5118" y1="-5.246" x2="5.7658" y2="-5.246" width="0.1524" layer="48"/>
<wire x1="-3.0988" y1="2.25" x2="-13.8938" y2="2.25" width="0.1524" layer="48"/>
<wire x1="0" y1="-2.75" x2="-13.8938" y2="-2.75" width="0.1524" layer="48"/>
<wire x1="-13.5128" y1="2.25" x2="-13.5128" y2="-2.75" width="0.1524" layer="48"/>
<wire x1="-13.5128" y1="2.25" x2="-13.6398" y2="1.996" width="0.1524" layer="48"/>
<wire x1="-13.5128" y1="2.25" x2="-13.3858" y2="1.996" width="0.1524" layer="48"/>
<wire x1="-13.6398" y1="1.996" x2="-13.3858" y2="1.996" width="0.1524" layer="48"/>
<wire x1="-13.5128" y1="-2.75" x2="-13.6398" y2="-2.496" width="0.1524" layer="48"/>
<wire x1="-13.5128" y1="-2.75" x2="-13.3858" y2="-2.496" width="0.1524" layer="48"/>
<wire x1="-13.6398" y1="-2.496" x2="-13.3858" y2="-2.496" width="0.1524" layer="48"/>
<wire x1="-3.0988" y1="2.25" x2="-12.6238" y2="2.25" width="0.1524" layer="48"/>
<wire x1="-3.0988" y1="-8.7482" x2="-12.6238" y2="-8.7482" width="0.1524" layer="48"/>
<wire x1="-12.2428" y1="2.25" x2="-12.2428" y2="-8.7482" width="0.1524" layer="48"/>
<wire x1="-12.2428" y1="2.25" x2="-12.3698" y2="1.996" width="0.1524" layer="48"/>
<wire x1="-12.2428" y1="2.25" x2="-12.1158" y2="1.996" width="0.1524" layer="48"/>
<wire x1="-12.3698" y1="1.996" x2="-12.1158" y2="1.996" width="0.1524" layer="48"/>
<wire x1="-12.2428" y1="-8.7482" x2="-12.3698" y2="-8.4942" width="0.1524" layer="48"/>
<wire x1="-12.2428" y1="-8.7482" x2="-12.1158" y2="-8.4942" width="0.1524" layer="48"/>
<wire x1="-12.3698" y1="-8.4942" x2="-12.1158" y2="-8.4942" width="0.1524" layer="48"/>
<text x="-15.7797" y="-12.8122" size="1.27" layer="48" ratio="6">Default Padstyle: EX77Y77D57P</text>
<text x="-16.5424" y="-14.7172" size="1.27" layer="48" ratio="6">1st Mtg Padstyle: RX80Y110D50P</text>
<text x="-16.7288" y="-16.6222" size="1.27" layer="48" ratio="6">2nd Mtg Padstyle: RX50Y100D40P</text>
<text x="-16.7288" y="-18.5272" size="1.27" layer="48" ratio="6">3rd Mtg Padstyle: RX100Y50D40P</text>
<text x="-16.9323" y="-20.4322" size="1.27" layer="48" ratio="6">Left Mtg Padstyle: RX50Y100D30P</text>
<text x="-17.5085" y="-22.3372" size="1.27" layer="48" ratio="6">Right Mtg Padstyle: RX50Y100D30P</text>
<text x="-14.8136" y="-24.2422" size="1.27" layer="48" ratio="6">Alt Padstyle 1: OX60Y90D30P</text>
<text x="-14.8136" y="-26.1472" size="1.27" layer="48" ratio="6">Alt Padstyle 2: OX90Y60D30P</text>
<text x="-1.3661" y="7.457" size="0.635" layer="48" ratio="4">0.165in/4.2mm</text>
<text x="-4.0424" y="13.172" size="0.635" layer="48" ratio="4">0.244in/6.198mm</text>
<text x="6.1468" y="-3.0675" size="0.635" layer="48" ratio="4">0.217in/5.5mm</text>
<text x="-19.9869" y="-0.5675" size="0.635" layer="48" ratio="4">0.197in/5mm</text>
<text x="-21.4119" y="-3.5666" size="0.635" layer="48" ratio="4">0.433in/10.998mm</text>
<wire x1="-3.2258" y1="-8.8752" x2="3.2258" y2="-8.8752" width="0.1524" layer="21"/>
<wire x1="3.2258" y1="-8.8752" x2="3.2258" y2="2.377" width="0.1524" layer="21"/>
<wire x1="3.2258" y1="2.377" x2="-3.2258" y2="2.377" width="0.1524" layer="21"/>
<wire x1="-3.2258" y1="2.377" x2="-3.2258" y2="-8.8752" width="0.1524" layer="21"/>
<wire x1="-4.8768" y1="0" x2="-5.6388" y2="0" width="0.508" layer="21" curve="-180"/>
<wire x1="-5.6388" y1="0" x2="-4.8768" y2="0" width="0.508" layer="21" curve="-180"/>
<wire x1="-3.0988" y1="-8.7482" x2="3.0988" y2="-8.7482" width="0.1524" layer="51"/>
<wire x1="3.0988" y1="-8.7482" x2="3.0988" y2="2.25" width="0.1524" layer="51"/>
<wire x1="3.0988" y1="2.25" x2="-3.0988" y2="2.25" width="0.1524" layer="51"/>
<wire x1="-3.0988" y1="2.25" x2="-3.0988" y2="-8.7482" width="0.1524" layer="51"/>
<wire x1="0.381" y1="0" x2="-0.381" y2="0" width="0.508" layer="51" curve="-180"/>
<wire x1="-0.381" y1="0" x2="0.381" y2="0" width="0.508" layer="51" curve="-180"/>
<wire x1="-4.8768" y1="0" x2="-5.6388" y2="0" width="0.508" layer="22" curve="-180"/>
<wire x1="-5.6388" y1="0" x2="-4.8768" y2="0" width="0.508" layer="22" curve="-180"/>
<text x="-3.2712" y="-3.385" size="1.27" layer="27" ratio="6">&gt;Name</text>
<text x="-1.7288" y="-3.385" size="1.27" layer="27" ratio="6">&gt;Value</text>
</package>
</packages>
<symbols>
<symbol name="CONN_002P_000C_1" library_version="3">
<pin name="1" x="0" y="0" visible="pad" length="middle" direction="pas"/>
<pin name="2" x="0" y="-2.54" visible="pad" length="middle" direction="pas"/>
<wire x1="10.16" y1="0" x2="5.08" y2="0" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-2.54" x2="5.08" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="10.16" y1="0" x2="8.89" y2="0.8467" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-2.54" x2="8.89" y2="-1.6933" width="0.1524" layer="94"/>
<wire x1="10.16" y1="0" x2="8.89" y2="-0.8467" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-2.54" x2="8.89" y2="-3.3867" width="0.1524" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-5.08" width="0.1524" layer="94"/>
<wire x1="5.08" y1="-5.08" x2="12.7" y2="-5.08" width="0.1524" layer="94"/>
<wire x1="12.7" y1="-5.08" x2="12.7" y2="2.54" width="0.1524" layer="94"/>
<wire x1="12.7" y1="2.54" x2="5.08" y2="2.54" width="0.1524" layer="94"/>
<text x="4.1646" y="5.3086" size="2.083" layer="95" ratio="6">&gt;Name</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="39288020" prefix="J" library_version="3">
<gates>
<gate name="A" symbol="CONN_002P_000C_1" x="0" y="0"/>
</gates>
<devices>
<device name="CONN_SD-5566-002_02_MOL" package="CONN_SD-5566-002_02_MOL">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="https://www.molex.com/en-us/products/part-detail-pdf/39288020?display=pdf" constant="no"/>
<attribute name="COPYRIGHT" value="Copyright (C) 2026 Ultra Librarian. All rights reserved." constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Molex" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="39288020" constant="no"/>
<attribute name="DESCRIPTION" value="Mini-Fit Jr. Vertical Header, 4.20mm Pitch, Dual Row, 2 Circuits, without Snap-in Plastic Peg PCB Lock, Tin, Natural" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="molex 0039293066" urn="urn:adsk.wipprod:fs.file:vf.Ou0LArH8TIKCkPIh9_2_hw">
<packages>
<package name="CONN_SD-5566-002_06_MOL" library_version="2">
<pad name="1" x="0" y="0" drill="1.4478" diameter="1.9558"/>
<pad name="2" x="4.2" y="0" drill="1.4478" diameter="1.9558"/>
<pad name="3" x="8.4" y="0" drill="1.4478" diameter="1.9558"/>
<pad name="4" x="0" y="-5.5" drill="1.4478" diameter="1.9558"/>
<pad name="5" x="4.2" y="-5.5" drill="1.4478" diameter="1.9558"/>
<pad name="6" x="8.4" y="-5.5" drill="1.4478" diameter="1.9558"/>
<wire x1="0" y1="0" x2="0" y2="7.33" width="0.1524" layer="48"/>
<wire x1="4.2" y1="0" x2="4.2" y2="7.33" width="0.1524" layer="48"/>
<wire x1="0" y1="6.949" x2="4.2" y2="6.949" width="0.1524" layer="48"/>
<wire x1="0" y1="6.949" x2="0.254" y2="7.076" width="0.1524" layer="48"/>
<wire x1="0" y1="6.949" x2="0.254" y2="6.822" width="0.1524" layer="48"/>
<wire x1="0.254" y1="7.076" x2="0.254" y2="6.822" width="0.1524" layer="48"/>
<wire x1="4.2" y1="6.949" x2="3.946" y2="7.076" width="0.1524" layer="48"/>
<wire x1="4.2" y1="6.949" x2="3.946" y2="6.822" width="0.1524" layer="48"/>
<wire x1="3.946" y1="7.076" x2="3.946" y2="6.822" width="0.1524" layer="48"/>
<wire x1="-3.1025" y1="2.25" x2="-3.1025" y2="13.045" width="0.1524" layer="48"/>
<wire x1="11.5025" y1="2.25" x2="11.5025" y2="13.045" width="0.1524" layer="48"/>
<wire x1="-3.1025" y1="12.664" x2="11.5025" y2="12.664" width="0.1524" layer="48"/>
<wire x1="-3.1025" y1="12.664" x2="-2.8485" y2="12.791" width="0.1524" layer="48"/>
<wire x1="-3.1025" y1="12.664" x2="-2.8485" y2="12.537" width="0.1524" layer="48"/>
<wire x1="-2.8485" y1="12.791" x2="-2.8485" y2="12.537" width="0.1524" layer="48"/>
<wire x1="11.5025" y1="12.664" x2="11.2485" y2="12.791" width="0.1524" layer="48"/>
<wire x1="11.5025" y1="12.664" x2="11.2485" y2="12.537" width="0.1524" layer="48"/>
<wire x1="11.2485" y1="12.791" x2="11.2485" y2="12.537" width="0.1524" layer="48"/>
<wire x1="0" y1="0" x2="14.4235" y2="0" width="0.1524" layer="48"/>
<wire x1="0" y1="-5.5" x2="14.4235" y2="-5.5" width="0.1524" layer="48"/>
<wire x1="14.0425" y1="0" x2="14.0425" y2="-5.5" width="0.1524" layer="48"/>
<wire x1="14.0425" y1="0" x2="13.9155" y2="-0.254" width="0.1524" layer="48"/>
<wire x1="14.0425" y1="0" x2="14.1695" y2="-0.254" width="0.1524" layer="48"/>
<wire x1="13.9155" y1="-0.254" x2="14.1695" y2="-0.254" width="0.1524" layer="48"/>
<wire x1="14.0425" y1="-5.5" x2="13.9155" y2="-5.246" width="0.1524" layer="48"/>
<wire x1="14.0425" y1="-5.5" x2="14.1695" y2="-5.246" width="0.1524" layer="48"/>
<wire x1="13.9155" y1="-5.246" x2="14.1695" y2="-5.246" width="0.1524" layer="48"/>
<wire x1="-3.1025" y1="2.25" x2="-13.8975" y2="2.25" width="0.1524" layer="48"/>
<wire x1="4.2" y1="-2.75" x2="-13.8975" y2="-2.75" width="0.1524" layer="48"/>
<wire x1="-13.5165" y1="2.25" x2="-13.5165" y2="-2.75" width="0.1524" layer="48"/>
<wire x1="-13.5165" y1="2.25" x2="-13.6435" y2="1.996" width="0.1524" layer="48"/>
<wire x1="-13.5165" y1="2.25" x2="-13.3895" y2="1.996" width="0.1524" layer="48"/>
<wire x1="-13.6435" y1="1.996" x2="-13.3895" y2="1.996" width="0.1524" layer="48"/>
<wire x1="-13.5165" y1="-2.75" x2="-13.6435" y2="-2.496" width="0.1524" layer="48"/>
<wire x1="-13.5165" y1="-2.75" x2="-13.3895" y2="-2.496" width="0.1524" layer="48"/>
<wire x1="-13.6435" y1="-2.496" x2="-13.3895" y2="-2.496" width="0.1524" layer="48"/>
<wire x1="-3.1025" y1="2.25" x2="-12.6275" y2="2.25" width="0.1524" layer="48"/>
<wire x1="-3.1025" y1="-8.7482" x2="-12.6275" y2="-8.7482" width="0.1524" layer="48"/>
<wire x1="-12.2465" y1="2.25" x2="-12.2465" y2="-8.7482" width="0.1524" layer="48"/>
<wire x1="-12.2465" y1="2.25" x2="-12.3735" y2="1.996" width="0.1524" layer="48"/>
<wire x1="-12.2465" y1="2.25" x2="-12.1195" y2="1.996" width="0.1524" layer="48"/>
<wire x1="-12.3735" y1="1.996" x2="-12.1195" y2="1.996" width="0.1524" layer="48"/>
<wire x1="-12.2465" y1="-8.7482" x2="-12.3735" y2="-8.4942" width="0.1524" layer="48"/>
<wire x1="-12.2465" y1="-8.7482" x2="-12.1195" y2="-8.4942" width="0.1524" layer="48"/>
<wire x1="-12.3735" y1="-8.4942" x2="-12.1195" y2="-8.4942" width="0.1524" layer="48"/>
<text x="-11.5798" y="-12.8122" size="1.27" layer="48" ratio="6">Default Padstyle: EX77Y77D57P</text>
<text x="-12.3424" y="-14.7172" size="1.27" layer="48" ratio="6">1st Mtg Padstyle: RX80Y110D50P</text>
<text x="-12.5288" y="-16.6222" size="1.27" layer="48" ratio="6">2nd Mtg Padstyle: RX50Y100D40P</text>
<text x="-12.5288" y="-18.5272" size="1.27" layer="48" ratio="6">3rd Mtg Padstyle: RX100Y50D40P</text>
<text x="-12.7323" y="-20.4322" size="1.27" layer="48" ratio="6">Left Mtg Padstyle: RX50Y100D30P</text>
<text x="-13.3085" y="-22.3372" size="1.27" layer="48" ratio="6">Right Mtg Padstyle: RX50Y100D30P</text>
<text x="-10.6136" y="-24.2422" size="1.27" layer="48" ratio="6">Alt Padstyle 1: OX60Y90D30P</text>
<text x="-10.6136" y="-26.1472" size="1.27" layer="48" ratio="6">Alt Padstyle 2: OX90Y60D30P</text>
<text x="-1.3661" y="7.457" size="0.635" layer="48" ratio="4">0.165in/4.2mm</text>
<text x="-0.1305" y="13.172" size="0.635" layer="48" ratio="4">0.575in/14.605mm</text>
<text x="14.5505" y="-3.0675" size="0.635" layer="48" ratio="4">0.217in/5.5mm</text>
<text x="-19.9906" y="-0.5675" size="0.635" layer="48" ratio="4">0.197in/5mm</text>
<text x="-21.4156" y="-3.5666" size="0.635" layer="48" ratio="4">0.433in/10.998mm</text>
<wire x1="-3.2295" y1="-8.8752" x2="11.6295" y2="-8.8752" width="0.1524" layer="21"/>
<wire x1="11.6295" y1="-8.8752" x2="11.6295" y2="2.377" width="0.1524" layer="21"/>
<wire x1="11.6295" y1="2.377" x2="-3.2295" y2="2.377" width="0.1524" layer="21"/>
<wire x1="-3.2295" y1="2.377" x2="-3.2295" y2="-8.8752" width="0.1524" layer="21"/>
<wire x1="-4.8805" y1="0" x2="-5.6425" y2="0" width="0.508" layer="21" curve="-180"/>
<wire x1="-5.6425" y1="0" x2="-4.8805" y2="0" width="0.508" layer="21" curve="-180"/>
<wire x1="-3.1025" y1="-8.7482" x2="11.5025" y2="-8.7482" width="0.1524" layer="51"/>
<wire x1="11.5025" y1="-8.7482" x2="11.5025" y2="2.25" width="0.1524" layer="51"/>
<wire x1="11.5025" y1="2.25" x2="-3.1025" y2="2.25" width="0.1524" layer="51"/>
<wire x1="-3.1025" y1="2.25" x2="-3.1025" y2="-8.7482" width="0.1524" layer="51"/>
<wire x1="0.381" y1="0" x2="-0.381" y2="0" width="0.508" layer="51" curve="-180"/>
<wire x1="-0.381" y1="0" x2="0.381" y2="0" width="0.508" layer="51" curve="-180"/>
<wire x1="-4.8805" y1="0" x2="-5.6425" y2="0" width="0.508" layer="22" curve="-180"/>
<wire x1="-5.6425" y1="0" x2="-4.8805" y2="0" width="0.508" layer="22" curve="-180"/>
<text x="0.9288" y="-3.385" size="1.27" layer="27" ratio="6">&gt;Name</text>
<text x="2.4712" y="-3.385" size="1.27" layer="27" ratio="6">&gt;Value</text>
</package>
</packages>
<symbols>
<symbol name="CONN_006P_000C_1" library_version="2">
<pin name="1" x="0" y="0" visible="pad" length="middle" direction="pas"/>
<pin name="2" x="0" y="-2.54" visible="pad" length="middle" direction="pas"/>
<pin name="3" x="0" y="-5.08" visible="pad" length="middle" direction="pas"/>
<pin name="4" x="0" y="-7.62" visible="pad" length="middle" direction="pas"/>
<pin name="5" x="0" y="-10.16" visible="pad" length="middle" direction="pas"/>
<pin name="6" x="0" y="-12.7" visible="pad" length="middle" direction="pas"/>
<wire x1="10.16" y1="0" x2="5.08" y2="0" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-2.54" x2="5.08" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-5.08" x2="5.08" y2="-5.08" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-7.62" x2="5.08" y2="-7.62" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-10.16" x2="5.08" y2="-10.16" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-12.7" x2="5.08" y2="-12.7" width="0.1524" layer="94"/>
<wire x1="10.16" y1="0" x2="8.89" y2="0.8467" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-2.54" x2="8.89" y2="-1.6933" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-5.08" x2="8.89" y2="-4.2333" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-7.62" x2="8.89" y2="-6.7733" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-10.16" x2="8.89" y2="-9.3133" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-12.7" x2="8.89" y2="-11.8533" width="0.1524" layer="94"/>
<wire x1="10.16" y1="0" x2="8.89" y2="-0.8467" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-2.54" x2="8.89" y2="-3.3867" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-5.08" x2="8.89" y2="-5.9267" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-7.62" x2="8.89" y2="-8.4667" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-10.16" x2="8.89" y2="-11.0067" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-12.7" x2="8.89" y2="-13.5467" width="0.1524" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-15.24" width="0.1524" layer="94"/>
<wire x1="5.08" y1="-15.24" x2="12.7" y2="-15.24" width="0.1524" layer="94"/>
<wire x1="12.7" y1="-15.24" x2="12.7" y2="2.54" width="0.1524" layer="94"/>
<wire x1="12.7" y1="2.54" x2="5.08" y2="2.54" width="0.1524" layer="94"/>
<text x="4.1646" y="5.3086" size="2.083" layer="95" ratio="6">&gt;Name</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="39293066" prefix="J" library_version="2">
<gates>
<gate name="A" symbol="CONN_006P_000C_1" x="0" y="0"/>
</gates>
<devices>
<device name="CONN_SD-5566-002_06_MOL" package="CONN_SD-5566-002_06_MOL">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
</connects>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="https://www.molex.com/en-us/products/part-detail-pdf/39293066?display=pdf" constant="no"/>
<attribute name="COPYRIGHT" value="Copyright (C) 2025 Ultra Librarian. All rights reserved." constant="no"/>
<attribute name="DESCRIPTION" value="Mini-Fit Jr. Vertical Header, 4.20mm Pitch, Dual Row, 6 Circuits, without Snap-in Plastic Peg PCB Lock, Tin, Natural" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Molex Connector Corporation" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="39293066" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="2026-07-04_05-50-15_Library" urn="urn:adsk.wipprod:fs.file:vf.W5yNMnp4TBO4qhKgoN13yg">
<packages>
<package name="CONN_55660330-SD_MOL" library_version="2">
<pad name="1" x="0" y="0" drill="1.4478" diameter="1.9558"/>
<pad name="2" x="-4.2" y="0" drill="1.4478" diameter="1.9558"/>
<pad name="3" x="-8.4" y="0" drill="1.4478" diameter="1.9558"/>
<pad name="4" x="-8.4" y="3.85" drill="3.048" diameter="3.048"/>
<pad name="5" x="-2.1" y="-5.55" drill="3.048" diameter="3.048"/>
<wire x1="-4.2" y1="0" x2="-4.2" y2="10.454" width="0.1524" layer="48"/>
<wire x1="0" y1="0" x2="0" y2="10.454" width="0.1524" layer="48"/>
<wire x1="-4.2" y1="10.073" x2="0" y2="10.073" width="0.1524" layer="48"/>
<wire x1="-4.2" y1="10.073" x2="-3.946" y2="10.2" width="0.1524" layer="48"/>
<wire x1="-4.2" y1="10.073" x2="-3.946" y2="9.946" width="0.1524" layer="48"/>
<wire x1="-3.946" y1="10.2" x2="-3.946" y2="9.946" width="0.1524" layer="48"/>
<wire x1="0" y1="10.073" x2="-0.254" y2="10.2" width="0.1524" layer="48"/>
<wire x1="0" y1="10.073" x2="-0.254" y2="9.946" width="0.1524" layer="48"/>
<wire x1="-0.254" y1="10.2" x2="-0.254" y2="9.946" width="0.1524" layer="48"/>
<wire x1="-11.0961" y1="4.85" x2="-11.0961" y2="16.169" width="0.1524" layer="48"/>
<wire x1="2.6961" y1="4.85" x2="2.6961" y2="16.169" width="0.1524" layer="48"/>
<wire x1="-11.0961" y1="15.788" x2="2.6961" y2="15.788" width="0.1524" layer="48"/>
<wire x1="-11.0961" y1="15.788" x2="-10.8421" y2="15.915" width="0.1524" layer="48"/>
<wire x1="-11.0961" y1="15.788" x2="-10.8421" y2="15.661" width="0.1524" layer="48"/>
<wire x1="-10.8421" y1="15.915" x2="-10.8421" y2="15.661" width="0.1524" layer="48"/>
<wire x1="2.6961" y1="15.788" x2="2.4421" y2="15.915" width="0.1524" layer="48"/>
<wire x1="2.6961" y1="15.788" x2="2.4421" y2="15.661" width="0.1524" layer="48"/>
<wire x1="2.4421" y1="15.915" x2="2.4421" y2="15.661" width="0.1524" layer="48"/>
<wire x1="0" y1="0" x2="5.6171" y2="0" width="0.1524" layer="48"/>
<wire x1="0" y1="0" x2="5.6171" y2="0" width="0.1524" layer="48"/>
<wire x1="5.2361" y1="0" x2="5.2361" y2="1.27" width="0.1524" layer="48"/>
<wire x1="5.2361" y1="0" x2="5.2361" y2="-1.27" width="0.1524" layer="48"/>
<wire x1="5.2361" y1="0" x2="5.1091" y2="0.254" width="0.1524" layer="48"/>
<wire x1="5.2361" y1="0" x2="5.3631" y2="0.254" width="0.1524" layer="48"/>
<wire x1="5.1091" y1="0.254" x2="5.3631" y2="0.254" width="0.1524" layer="48"/>
<wire x1="5.2361" y1="0" x2="5.1091" y2="-0.254" width="0.1524" layer="48"/>
<wire x1="5.2361" y1="0" x2="5.3631" y2="-0.254" width="0.1524" layer="48"/>
<wire x1="5.1091" y1="-0.254" x2="5.3631" y2="-0.254" width="0.1524" layer="48"/>
<wire x1="-11.0961" y1="4.85" x2="-21.8911" y2="4.85" width="0.1524" layer="48"/>
<wire x1="-4.2" y1="0" x2="-21.8911" y2="0" width="0.1524" layer="48"/>
<wire x1="-21.5101" y1="4.85" x2="-21.5101" y2="0" width="0.1524" layer="48"/>
<wire x1="-21.5101" y1="4.85" x2="-21.6371" y2="4.596" width="0.1524" layer="48"/>
<wire x1="-21.5101" y1="4.85" x2="-21.3831" y2="4.596" width="0.1524" layer="48"/>
<wire x1="-21.6371" y1="4.596" x2="-21.3831" y2="4.596" width="0.1524" layer="48"/>
<wire x1="-21.5101" y1="0" x2="-21.6371" y2="0.254" width="0.1524" layer="48"/>
<wire x1="-21.5101" y1="0" x2="-21.3831" y2="0.254" width="0.1524" layer="48"/>
<wire x1="-21.6371" y1="0.254" x2="-21.3831" y2="0.254" width="0.1524" layer="48"/>
<wire x1="-11.0961" y1="4.85" x2="-20.6211" y2="4.85" width="0.1524" layer="48"/>
<wire x1="-11.0961" y1="-6.5546" x2="-20.6211" y2="-6.5546" width="0.1524" layer="48"/>
<wire x1="-20.2401" y1="4.85" x2="-20.2401" y2="-6.5546" width="0.1524" layer="48"/>
<wire x1="-20.2401" y1="4.85" x2="-20.3671" y2="4.596" width="0.1524" layer="48"/>
<wire x1="-20.2401" y1="4.85" x2="-20.1131" y2="4.596" width="0.1524" layer="48"/>
<wire x1="-20.3671" y1="4.596" x2="-20.1131" y2="4.596" width="0.1524" layer="48"/>
<wire x1="-20.2401" y1="-6.5546" x2="-20.3671" y2="-6.3006" width="0.1524" layer="48"/>
<wire x1="-20.2401" y1="-6.5546" x2="-20.1131" y2="-6.3006" width="0.1524" layer="48"/>
<wire x1="-20.3671" y1="-6.3006" x2="-20.1131" y2="-6.3006" width="0.1524" layer="48"/>
<wire x1="-8.4" y1="3.85" x2="-8.4" y2="10.311" width="0.1524" layer="48"/>
<wire x1="-4.2" y1="0" x2="-4.2" y2="10.311" width="0.1524" layer="48"/>
<wire x1="-8.4" y1="9.93" x2="-4.2" y2="9.93" width="0.1524" layer="48"/>
<wire x1="-8.4" y1="9.93" x2="-8.146" y2="10.057" width="0.1524" layer="48"/>
<wire x1="-8.4" y1="9.93" x2="-8.146" y2="9.803" width="0.1524" layer="48"/>
<wire x1="-8.146" y1="10.057" x2="-8.146" y2="9.803" width="0.1524" layer="48"/>
<wire x1="-4.2" y1="9.93" x2="-4.454" y2="10.057" width="0.1524" layer="48"/>
<wire x1="-4.2" y1="9.93" x2="-4.454" y2="9.803" width="0.1524" layer="48"/>
<wire x1="-4.454" y1="10.057" x2="-4.454" y2="9.803" width="0.1524" layer="48"/>
<wire x1="-4.2" y1="0" x2="-4.2" y2="10.311" width="0.1524" layer="48"/>
<wire x1="-2.1" y1="-5.55" x2="-2.1" y2="10.311" width="0.1524" layer="48"/>
<wire x1="-4.2" y1="9.93" x2="-5.47" y2="9.93" width="0.1524" layer="48"/>
<wire x1="-2.1" y1="9.93" x2="-0.83" y2="9.93" width="0.1524" layer="48"/>
<wire x1="-4.2" y1="9.93" x2="-4.454" y2="10.057" width="0.1524" layer="48"/>
<wire x1="-4.2" y1="9.93" x2="-4.454" y2="9.803" width="0.1524" layer="48"/>
<wire x1="-4.454" y1="10.057" x2="-4.454" y2="9.803" width="0.1524" layer="48"/>
<wire x1="-2.1" y1="9.93" x2="-1.846" y2="10.057" width="0.1524" layer="48"/>
<wire x1="-2.1" y1="9.93" x2="-1.846" y2="9.803" width="0.1524" layer="48"/>
<wire x1="-1.846" y1="10.057" x2="-1.846" y2="9.803" width="0.1524" layer="48"/>
<text x="-19.9797" y="-11.138" size="1.27" layer="48" ratio="6">Default Padstyle: EX77Y77D57P</text>
<text x="-20.7424" y="-13.043" size="1.27" layer="48" ratio="6">1st Mtg Padstyle: RX80Y110D50P</text>
<text x="-20.9288" y="-14.948" size="1.27" layer="48" ratio="6">2nd Mtg Padstyle: RX50Y100D40P</text>
<text x="-20.9288" y="-16.853" size="1.27" layer="48" ratio="6">3rd Mtg Padstyle: RX100Y50D40P</text>
<text x="-22.2848" y="-18.758" size="1.27" layer="48" ratio="6">Left Mtg Padstyle: EX120Y120D120P</text>
<text x="-22.8611" y="-20.663" size="1.27" layer="48" ratio="6">Right Mtg Padstyle: EX120Y120D120P</text>
<text x="-19.0136" y="-22.568" size="1.27" layer="48" ratio="6">Alt Padstyle 1: OX60Y90D30P</text>
<text x="-19.0136" y="-24.473" size="1.27" layer="48" ratio="6">Alt Padstyle 2: OX90Y60D30P</text>
<text x="-5.5661" y="10.581" size="0.635" layer="48" ratio="4">0.165in/4.2mm</text>
<text x="-8.5305" y="16.296" size="0.635" layer="48" ratio="4">0.543in/13.792mm</text>
<text x="5.7441" y="-0.3175" size="0.635" layer="48" ratio="4">0in/0mm</text>
<text x="-29.5267" y="2.1075" size="0.635" layer="48" ratio="4">0.191in/4.85mm</text>
<text x="-29.4092" y="-1.1698" size="0.635" layer="48" ratio="4">0.449in/11.405mm</text>
<text x="-10.3424" y="10.438" size="0.635" layer="48" ratio="4">-0.165in/-4.2mm</text>
<text x="-6.6161" y="10.438" size="0.635" layer="48" ratio="4">0.083in/2.1mm</text>
<wire x1="-11.2231" y1="-6.6816" x2="-3.5721" y2="-6.6816" width="0.1524" layer="21"/>
<wire x1="2.8231" y1="-6.6816" x2="2.8231" y2="4.977" width="0.1524" layer="21"/>
<wire x1="2.8231" y1="4.977" x2="-6.9244" y2="4.977" width="0.1524" layer="21"/>
<wire x1="-11.2231" y1="4.977" x2="-11.2231" y2="-6.6816" width="0.1524" layer="21"/>
<wire x1="-9.8756" y1="4.977" x2="-11.2231" y2="4.977" width="0.1524" layer="21"/>
<wire x1="-0.6279" y1="-6.6816" x2="2.8231" y2="-6.6816" width="0.1524" layer="21"/>
<wire x1="4.0931" y1="0" x2="3.3311" y2="0" width="0.508" layer="21" curve="-180"/>
<wire x1="3.3311" y1="0" x2="4.0931" y2="0" width="0.508" layer="21" curve="-180"/>
<wire x1="-11.0961" y1="-6.5546" x2="2.6961" y2="-6.5546" width="0.1524" layer="51"/>
<wire x1="2.6961" y1="-6.5546" x2="2.6961" y2="4.85" width="0.1524" layer="51"/>
<wire x1="2.6961" y1="4.85" x2="-11.0961" y2="4.85" width="0.1524" layer="51"/>
<wire x1="-11.0961" y1="4.85" x2="-11.0961" y2="-6.5546" width="0.1524" layer="51"/>
<wire x1="0.381" y1="0" x2="-0.381" y2="0" width="0.508" layer="51" curve="-180"/>
<wire x1="-0.381" y1="0" x2="0.381" y2="0" width="0.508" layer="51" curve="-180"/>
<wire x1="4.0931" y1="0" x2="3.3311" y2="0" width="0.508" layer="22" curve="-180"/>
<wire x1="3.3311" y1="0" x2="4.0931" y2="0" width="0.508" layer="22" curve="-180"/>
<text x="-7.4712" y="-0.635" size="1.27" layer="27" ratio="6">&gt;Name</text>
<text x="-5.9288" y="-0.635" size="1.27" layer="27" ratio="6">&gt;Value</text>
</package>
</packages>
<symbols>
<symbol name="CONN_003P_000C_1" library_version="2">
<pin name="1" x="0" y="0" visible="pad" length="middle" direction="pas"/>
<pin name="2" x="0" y="-2.54" visible="pad" length="middle" direction="pas"/>
<pin name="3" x="0" y="-5.08" visible="pad" length="middle" direction="pas"/>
<wire x1="10.16" y1="0" x2="5.08" y2="0" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-2.54" x2="5.08" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-5.08" x2="5.08" y2="-5.08" width="0.1524" layer="94"/>
<wire x1="10.16" y1="0" x2="8.89" y2="0.8467" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-2.54" x2="8.89" y2="-1.6933" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-5.08" x2="8.89" y2="-4.2333" width="0.1524" layer="94"/>
<wire x1="10.16" y1="0" x2="8.89" y2="-0.8467" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-2.54" x2="8.89" y2="-3.3867" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-5.08" x2="8.89" y2="-5.9267" width="0.1524" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-7.62" width="0.1524" layer="94"/>
<wire x1="5.08" y1="-7.62" x2="12.7" y2="-7.62" width="0.1524" layer="94"/>
<wire x1="12.7" y1="-7.62" x2="12.7" y2="2.54" width="0.1524" layer="94"/>
<wire x1="12.7" y1="2.54" x2="5.08" y2="2.54" width="0.1524" layer="94"/>
<text x="4.1646" y="5.3086" size="2.083" layer="95" ratio="6">&gt;Name</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="39302031" prefix="J" library_version="2">
<gates>
<gate name="A" symbol="CONN_003P_000C_1" x="0" y="0"/>
</gates>
<devices>
<device name="CONN_55660330-SD_MOL" package="CONN_55660330-SD_MOL">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
</connects>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="https://www.molex.com/en-us/products/part-detail-pdf/39302031?display=pdf" constant="no"/>
<attribute name="COPYRIGHT" value="Copyright (C) 2026 Ultra Librarian. All rights reserved." constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Molex" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="39302031" constant="no"/>
<attribute name="DESCRIPTION" value="Mini-Fit Jr. Vertical Header, 4.20mm Pitch, Single Row, 3 Circuits, with  Snap-in Plastic Peg PCB Lock, Gold, Natural" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="2026-07-23_20-22-02_Library" urn="urn:adsk.wipprod:fs.file:vf.OJ38JIMhQ2mI8b7IQ-Zj-A">
<packages>
<package name="CONN_SD-172647-0000_05_MOL" library_version="4">
<pad name="1" x="0" y="0" drill="1.4478" diameter="1.9558"/>
<pad name="2" x="4.2" y="0" drill="1.4478" diameter="1.9558"/>
<pad name="3" x="8.4" y="0" drill="1.4478" diameter="1.9558"/>
<pad name="4" x="12.6" y="0" drill="1.4478" diameter="1.9558"/>
<pad name="5" x="16.8" y="0" drill="1.4478" diameter="1.9558"/>
<pad name="6" x="2.1" y="5.55" drill="3.048" diameter="3.048"/>
<pad name="7" x="16.8" y="-3.85" drill="3.048" diameter="3.048"/>
<wire x1="0" y1="0" x2="0" y2="12.154" width="0.1524" layer="48"/>
<wire x1="4.2" y1="0" x2="4.2" y2="12.154" width="0.1524" layer="48"/>
<wire x1="0" y1="11.773" x2="4.2" y2="11.773" width="0.1524" layer="48"/>
<wire x1="0" y1="11.773" x2="0.254" y2="11.9" width="0.1524" layer="48"/>
<wire x1="0" y1="11.773" x2="0.254" y2="11.646" width="0.1524" layer="48"/>
<wire x1="0.254" y1="11.9" x2="0.254" y2="11.646" width="0.1524" layer="48"/>
<wire x1="4.2" y1="11.773" x2="3.946" y2="11.9" width="0.1524" layer="48"/>
<wire x1="4.2" y1="11.773" x2="3.946" y2="11.646" width="0.1524" layer="48"/>
<wire x1="3.946" y1="11.9" x2="3.946" y2="11.646" width="0.1524" layer="48"/>
<wire x1="-2.6998" y1="6.55" x2="-2.6998" y2="17.869" width="0.1524" layer="48"/>
<wire x1="19.4998" y1="6.55" x2="19.4998" y2="17.869" width="0.1524" layer="48"/>
<wire x1="-2.6998" y1="17.488" x2="19.4998" y2="17.488" width="0.1524" layer="48"/>
<wire x1="-2.6998" y1="17.488" x2="-2.4458" y2="17.615" width="0.1524" layer="48"/>
<wire x1="-2.6998" y1="17.488" x2="-2.4458" y2="17.361" width="0.1524" layer="48"/>
<wire x1="-2.4458" y1="17.615" x2="-2.4458" y2="17.361" width="0.1524" layer="48"/>
<wire x1="19.4998" y1="17.488" x2="19.2458" y2="17.615" width="0.1524" layer="48"/>
<wire x1="19.4998" y1="17.488" x2="19.2458" y2="17.361" width="0.1524" layer="48"/>
<wire x1="19.2458" y1="17.615" x2="19.2458" y2="17.361" width="0.1524" layer="48"/>
<wire x1="0" y1="0" x2="22.4208" y2="0" width="0.1524" layer="48"/>
<wire x1="0" y1="0" x2="22.4208" y2="0" width="0.1524" layer="48"/>
<wire x1="22.0398" y1="0" x2="22.0398" y2="1.27" width="0.1524" layer="48"/>
<wire x1="22.0398" y1="0" x2="22.0398" y2="-1.27" width="0.1524" layer="48"/>
<wire x1="22.0398" y1="0" x2="21.9128" y2="0.254" width="0.1524" layer="48"/>
<wire x1="22.0398" y1="0" x2="22.1668" y2="0.254" width="0.1524" layer="48"/>
<wire x1="21.9128" y1="0.254" x2="22.1668" y2="0.254" width="0.1524" layer="48"/>
<wire x1="22.0398" y1="0" x2="21.9128" y2="-0.254" width="0.1524" layer="48"/>
<wire x1="22.0398" y1="0" x2="22.1668" y2="-0.254" width="0.1524" layer="48"/>
<wire x1="21.9128" y1="-0.254" x2="22.1668" y2="-0.254" width="0.1524" layer="48"/>
<wire x1="-2.6998" y1="6.55" x2="-13.4948" y2="6.55" width="0.1524" layer="48"/>
<wire x1="8.4" y1="0" x2="-13.4948" y2="0" width="0.1524" layer="48"/>
<wire x1="-13.1138" y1="6.55" x2="-13.1138" y2="0" width="0.1524" layer="48"/>
<wire x1="-13.1138" y1="6.55" x2="-13.2408" y2="6.296" width="0.1524" layer="48"/>
<wire x1="-13.1138" y1="6.55" x2="-12.9868" y2="6.296" width="0.1524" layer="48"/>
<wire x1="-13.2408" y1="6.296" x2="-12.9868" y2="6.296" width="0.1524" layer="48"/>
<wire x1="-13.1138" y1="0" x2="-13.2408" y2="0.254" width="0.1524" layer="48"/>
<wire x1="-13.1138" y1="0" x2="-12.9868" y2="0.254" width="0.1524" layer="48"/>
<wire x1="-13.2408" y1="0.254" x2="-12.9868" y2="0.254" width="0.1524" layer="48"/>
<wire x1="-2.6998" y1="6.55" x2="-12.2248" y2="6.55" width="0.1524" layer="48"/>
<wire x1="-2.6998" y1="-4.8546" x2="-12.2248" y2="-4.8546" width="0.1524" layer="48"/>
<wire x1="-11.8438" y1="6.55" x2="-11.8438" y2="-4.8546" width="0.1524" layer="48"/>
<wire x1="-11.8438" y1="6.55" x2="-11.9708" y2="6.296" width="0.1524" layer="48"/>
<wire x1="-11.8438" y1="6.55" x2="-11.7168" y2="6.296" width="0.1524" layer="48"/>
<wire x1="-11.9708" y1="6.296" x2="-11.7168" y2="6.296" width="0.1524" layer="48"/>
<wire x1="-11.8438" y1="-4.8546" x2="-11.9708" y2="-4.6006" width="0.1524" layer="48"/>
<wire x1="-11.8438" y1="-4.8546" x2="-11.7168" y2="-4.6006" width="0.1524" layer="48"/>
<wire x1="-11.9708" y1="-4.6006" x2="-11.7168" y2="-4.6006" width="0.1524" layer="48"/>
<wire x1="2.1" y1="5.55" x2="2.1" y2="12.011" width="0.1524" layer="48"/>
<wire x1="8.4" y1="0" x2="8.4" y2="12.011" width="0.1524" layer="48"/>
<wire x1="2.1" y1="11.63" x2="8.4" y2="11.63" width="0.1524" layer="48"/>
<wire x1="2.1" y1="11.63" x2="2.354" y2="11.757" width="0.1524" layer="48"/>
<wire x1="2.1" y1="11.63" x2="2.354" y2="11.503" width="0.1524" layer="48"/>
<wire x1="2.354" y1="11.757" x2="2.354" y2="11.503" width="0.1524" layer="48"/>
<wire x1="8.4" y1="11.63" x2="8.146" y2="11.757" width="0.1524" layer="48"/>
<wire x1="8.4" y1="11.63" x2="8.146" y2="11.503" width="0.1524" layer="48"/>
<wire x1="8.146" y1="11.757" x2="8.146" y2="11.503" width="0.1524" layer="48"/>
<wire x1="8.4" y1="0" x2="8.4" y2="12.011" width="0.1524" layer="48"/>
<wire x1="16.8" y1="-3.85" x2="16.8" y2="12.011" width="0.1524" layer="48"/>
<wire x1="8.4" y1="11.63" x2="16.8" y2="11.63" width="0.1524" layer="48"/>
<wire x1="8.4" y1="11.63" x2="8.654" y2="11.757" width="0.1524" layer="48"/>
<wire x1="8.4" y1="11.63" x2="8.654" y2="11.503" width="0.1524" layer="48"/>
<wire x1="8.654" y1="11.757" x2="8.654" y2="11.503" width="0.1524" layer="48"/>
<wire x1="16.8" y1="11.63" x2="16.546" y2="11.757" width="0.1524" layer="48"/>
<wire x1="16.8" y1="11.63" x2="16.546" y2="11.503" width="0.1524" layer="48"/>
<wire x1="16.546" y1="11.757" x2="16.546" y2="11.503" width="0.1524" layer="48"/>
<text x="-7.3798" y="-9.438" size="1.27" layer="48" ratio="6">Default Padstyle: EX77Y77D57P</text>
<text x="-8.1424" y="-11.343" size="1.27" layer="48" ratio="6">1st Mtg Padstyle: RX80Y110D50P</text>
<text x="-8.3288" y="-13.248" size="1.27" layer="48" ratio="6">2nd Mtg Padstyle: RX50Y100D40P</text>
<text x="-8.3288" y="-15.153" size="1.27" layer="48" ratio="6">3rd Mtg Padstyle: RX100Y50D40P</text>
<text x="-9.6848" y="-17.058" size="1.27" layer="48" ratio="6">Left Mtg Padstyle: EX120Y120D120P</text>
<text x="-10.2611" y="-18.963" size="1.27" layer="48" ratio="6">Right Mtg Padstyle: EX120Y120D120P</text>
<text x="-6.4136" y="-20.868" size="1.27" layer="48" ratio="6">Alt Padstyle 1: OX60Y90D30P</text>
<text x="-6.4136" y="-22.773" size="1.27" layer="48" ratio="6">Alt Padstyle 2: OX90Y60D30P</text>
<text x="-1.3661" y="12.281" size="0.635" layer="48" ratio="4">0.165in/4.2mm</text>
<text x="4.6457" y="17.996" size="0.635" layer="48" ratio="4">0.874in/22.2mm</text>
<text x="22.5478" y="-0.3175" size="0.635" layer="48" ratio="4">0in/0mm</text>
<text x="-21.1304" y="2.9575" size="0.635" layer="48" ratio="4">0.258in/6.55mm</text>
<text x="-21.0129" y="0.5302" size="0.635" layer="48" ratio="4">0.449in/11.405mm</text>
<text x="1.2076" y="12.138" size="0.635" layer="48" ratio="4">-0.248in/-6.3mm</text>
<text x="9.1338" y="12.138" size="0.635" layer="48" ratio="4">0.331in/8.4mm</text>
<wire x1="-2.8268" y1="-4.9816" x2="15.3279" y2="-4.9816" width="0.1524" layer="21"/>
<wire x1="19.6268" y1="-4.9816" x2="19.6268" y2="6.677" width="0.1524" layer="21"/>
<wire x1="19.6268" y1="6.677" x2="3.5756" y2="6.677" width="0.1524" layer="21"/>
<wire x1="-2.8268" y1="6.677" x2="-2.8268" y2="-4.9816" width="0.1524" layer="21"/>
<wire x1="0.6244" y1="6.677" x2="-2.8268" y2="6.677" width="0.1524" layer="21"/>
<wire x1="18.2721" y1="-4.9816" x2="19.6268" y2="-4.9816" width="0.1524" layer="21"/>
<wire x1="-4.4778" y1="0" x2="-5.2398" y2="0" width="0.508" layer="21" curve="-180"/>
<wire x1="-5.2398" y1="0" x2="-4.4778" y2="0" width="0.508" layer="21" curve="-180"/>
<wire x1="-2.6998" y1="-4.8546" x2="19.4998" y2="-4.8546" width="0.1524" layer="51"/>
<wire x1="19.4998" y1="-4.8546" x2="19.4998" y2="6.55" width="0.1524" layer="51"/>
<wire x1="19.4998" y1="6.55" x2="-2.6998" y2="6.55" width="0.1524" layer="51"/>
<wire x1="-2.6998" y1="6.55" x2="-2.6998" y2="-4.8546" width="0.1524" layer="51"/>
<wire x1="0.381" y1="0" x2="-0.381" y2="0" width="0.508" layer="51" curve="-180"/>
<wire x1="-0.381" y1="0" x2="0.381" y2="0" width="0.508" layer="51" curve="-180"/>
<wire x1="-4.4778" y1="0" x2="-5.2398" y2="0" width="0.508" layer="22" curve="-180"/>
<wire x1="-5.2398" y1="0" x2="-4.4778" y2="0" width="0.508" layer="22" curve="-180"/>
<text x="5.1288" y="-0.635" size="1.27" layer="27" ratio="6">&gt;Name</text>
<text x="6.6712" y="-0.635" size="1.27" layer="27" ratio="6">&gt;Value</text>
</package>
</packages>
<symbols>
<symbol name="CONN_005P_000C_1" library_version="3">
<pin name="1" x="0" y="0" visible="pad" length="middle" direction="pas"/>
<pin name="2" x="0" y="-2.54" visible="pad" length="middle" direction="pas"/>
<pin name="3" x="0" y="-5.08" visible="pad" length="middle" direction="pas"/>
<pin name="4" x="0" y="-7.62" visible="pad" length="middle" direction="pas"/>
<pin name="5" x="0" y="-10.16" visible="pad" length="middle" direction="pas"/>
<wire x1="10.16" y1="0" x2="5.08" y2="0" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-2.54" x2="5.08" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-5.08" x2="5.08" y2="-5.08" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-7.62" x2="5.08" y2="-7.62" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-10.16" x2="5.08" y2="-10.16" width="0.1524" layer="94"/>
<wire x1="10.16" y1="0" x2="8.89" y2="0.8467" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-2.54" x2="8.89" y2="-1.6933" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-5.08" x2="8.89" y2="-4.2333" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-7.62" x2="8.89" y2="-6.7733" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-10.16" x2="8.89" y2="-9.3133" width="0.1524" layer="94"/>
<wire x1="10.16" y1="0" x2="8.89" y2="-0.8467" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-2.54" x2="8.89" y2="-3.3867" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-5.08" x2="8.89" y2="-5.9267" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-7.62" x2="8.89" y2="-8.4667" width="0.1524" layer="94"/>
<wire x1="10.16" y1="-10.16" x2="8.89" y2="-11.0067" width="0.1524" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-12.7" width="0.1524" layer="94"/>
<wire x1="5.08" y1="-12.7" x2="12.7" y2="-12.7" width="0.1524" layer="94"/>
<wire x1="12.7" y1="-12.7" x2="12.7" y2="2.54" width="0.1524" layer="94"/>
<wire x1="12.7" y1="2.54" x2="5.08" y2="2.54" width="0.1524" layer="94"/>
<text x="4.1646" y="5.3086" size="2.083" layer="95" ratio="6">&gt;Name</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="1726470105" prefix="J" library_version="4">
<gates>
<gate name="A" symbol="CONN_005P_000C_1" x="0" y="0"/>
</gates>
<devices>
<device name="CONN_SD-172647-0000_05_MOL" package="CONN_SD-172647-0000_05_MOL">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="5" pad="5"/>
</connects>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="https://www.molex.com/en-us/products/part-detail-pdf/1726470105?display=pdf" constant="no"/>
<attribute name="COPYRIGHT" value="Copyright (C) 2026 Ultra Librarian. All rights reserved." constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Molex" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="1726470105" constant="no"/>
<attribute name="DESCRIPTION" value="Mini-Fit Jr. Header, Single Row, Vertical, 5 Circuits, Nylon, 94V-2, Matte Tin (Sn) Plating, Glow-Wire Capable, Black" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
</libraries>
<attributes>
</attributes>
<variantdefs>
</variantdefs>
<classes>
<class number="0" name="default" width="0" drill="0">
</class>
</classes>
<parts>
<part name="X-AXIS" library="molex 0039290083" library_urn="urn:adsk.wipprod:fs.file:vf.LM2bSIezQECa3ZpQ7Zadyg" deviceset="39290083" device="CONN_SD-5566-002_08_MOL"/>
<part name="Y-AXIS" library="molex 0039290083" library_urn="urn:adsk.wipprod:fs.file:vf.LM2bSIezQECa3ZpQ7Zadyg" deviceset="39290083" device="CONN_SD-5566-002_08_MOL"/>
<part name="Z-AXIS" library="molex 0039290083" library_urn="urn:adsk.wipprod:fs.file:vf.LM2bSIezQECa3ZpQ7Zadyg" deviceset="39290083" device="CONN_SD-5566-002_08_MOL"/>
<part name="A-AXIS" library="molex 0039290083" library_urn="urn:adsk.wipprod:fs.file:vf.LM2bSIezQECa3ZpQ7Zadyg" deviceset="39290083" device="CONN_SD-5566-002_08_MOL"/>
<part name="R1" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0805(2012-METRIC)" package3d_urn="urn:adsk.eagle:package:16378559/7" technology="_" value="4k7"/>
<part name="R2" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0805(2012-METRIC)" package3d_urn="urn:adsk.eagle:package:16378559/7" technology="_" value="4k7"/>
<part name="R3" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0805(2012-METRIC)" package3d_urn="urn:adsk.eagle:package:16378559/7" technology="_" value="4k7"/>
<part name="R4" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0805(2012-METRIC)" package3d_urn="urn:adsk.eagle:package:16378559/7" technology="_" value="4k7"/>
<part name="R5" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0805(2012-METRIC)" package3d_urn="urn:adsk.eagle:package:16378559/7" technology="_" value="4k7"/>
<part name="R6" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0805(2012-METRIC)" package3d_urn="urn:adsk.eagle:package:16378559/7" technology="_" value="4k7"/>
<part name="R7" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0805(2012-METRIC)" package3d_urn="urn:adsk.eagle:package:16378559/7" technology="_" value="4k7"/>
<part name="R8" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0805(2012-METRIC)" package3d_urn="urn:adsk.eagle:package:16378559/7" technology="_" value="4k7"/>
<part name="R9" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0805(2012-METRIC)" package3d_urn="urn:adsk.eagle:package:16378559/7" technology="_" value="4k7"/>
<part name="R10" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0805(2012-METRIC)" package3d_urn="urn:adsk.eagle:package:16378559/7" technology="_" value="4k7"/>
<part name="R11" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0805(2012-METRIC)" package3d_urn="urn:adsk.eagle:package:16378559/7" technology="_" value="4k7"/>
<part name="P+2" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="+24V" device=""/>
<part name="R12" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0805(2012-METRIC)" package3d_urn="urn:adsk.eagle:package:16378559/7" technology="_" value="4k7"/>
<part name="P+4" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="+24V" device=""/>
<part name="GND7" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="0V" device=""/>
<part name="J2" library="Wurth_Signal &amp; Communications_WE-D-SUB" library_urn="urn:adsk.eagle:library:14284102" deviceset="WE-D-SUB_THT_UNC4/40_210111023" device="" package3d_urn="urn:adsk.eagle:package:13184429/2"/>
<part name="J3" library="Wurth_Signal &amp; Communications_WE-D-SUB" library_urn="urn:adsk.eagle:library:14284102" deviceset="WE-D-SUB_THT_UNC4/40_214111023" device="" package3d_urn="urn:adsk.eagle:package:13184422/2"/>
<part name="P+5" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="+24V" device=""/>
<part name="VSS3" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="VSS" device=""/>
<part name="J5" library="Wurth_Signal &amp; Communications_WE-D-SUB" library_urn="urn:adsk.eagle:library:14284102" deviceset="WE-D-SUB_THT_UNC4/40_214111023" device="" package3d_urn="urn:adsk.eagle:package:13184422/2"/>
<part name="GND12" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="0V" device=""/>
<part name="VSS1" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="VSS" device=""/>
<part name="GND1" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="0V" device=""/>
<part name="C1" library="rcl" library_urn="urn:adsk.eagle:library:334" deviceset="C-US" device="C1206" package3d_urn="urn:adsk.eagle:package:23618/2" value="100nF"/>
<part name="C2" library="rcl" library_urn="urn:adsk.eagle:library:334" deviceset="C-US" device="C1206" package3d_urn="urn:adsk.eagle:package:23618/2" value="10uF"/>
<part name="P+6" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="+24V" device=""/>
<part name="GND10" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="0V" device=""/>
<part name="GND4" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="0V" device=""/>
<part name="GND8" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="0V" device=""/>
<part name="F1" library="belfuse" library_urn="urn:adsk.wipprod:fs.file:vf.KZ5jnwlsSbOFGirIR93spw" deviceset="0ZCG0050AF2C" device="0ZCG_BEL"/>
<part name="GND6" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="0V" device=""/>
<part name="C13" library="rcl" library_urn="urn:adsk.eagle:library:334" deviceset="C-US" device="C1206" package3d_urn="urn:adsk.eagle:package:23618/2" value="1uF"/>
<part name="C14" library="rcl" library_urn="urn:adsk.eagle:library:334" deviceset="C-US" device="C1206" package3d_urn="urn:adsk.eagle:package:23618/2" value="1uF"/>
<part name="P+3" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="+24V" device=""/>
<part name="U2" library="OPA2192ID" library_urn="urn:adsk.wipprod:fs.file:vf.TJj7-PTeQnuMcJFsNH9qDw" deviceset="OPA2192ID" device=""/>
<part name="VSS4" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="VSS" device=""/>
<part name="GND9" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="0V" device=""/>
<part name="C5" library="rcl" library_urn="urn:adsk.eagle:library:334" deviceset="C-US" device="C1206" package3d_urn="urn:adsk.eagle:package:23618/2" value="0.1uF"/>
<part name="R14" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0805(2012-METRIC)" package3d_urn="urn:adsk.eagle:package:16378559/7" technology="_" value="3k09"/>
<part name="R17" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0805(2012-METRIC)" package3d_urn="urn:adsk.eagle:package:16378559/7" technology="_" value="3k09"/>
<part name="R18" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0805(2012-METRIC)" package3d_urn="urn:adsk.eagle:package:16378559/7" technology="_" value="3k09"/>
<part name="C6" library="rcl" library_urn="urn:adsk.eagle:library:334" deviceset="C-US" device="C1206" package3d_urn="urn:adsk.eagle:package:23618/2" value="0.1uF"/>
<part name="GND11" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="0V" device=""/>
<part name="C7" library="rcl" library_urn="urn:adsk.eagle:library:334" deviceset="C-US" device="C1206" package3d_urn="urn:adsk.eagle:package:23618/2" value="0.1uF"/>
<part name="C8" library="rcl" library_urn="urn:adsk.eagle:library:334" deviceset="C-US" device="C1206" package3d_urn="urn:adsk.eagle:package:23618/2" value="0.1uF"/>
<part name="GND13" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="0V" device=""/>
<part name="GND18" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="0V" device=""/>
<part name="R19" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0805(2012-METRIC)" package3d_urn="urn:adsk.eagle:package:16378559/7" technology="_" value="470"/>
<part name="C15" library="rcl" library_urn="urn:adsk.eagle:library:334" deviceset="C-US" device="C1206" package3d_urn="urn:adsk.eagle:package:23618/2" value="0.1uF"/>
<part name="GND16" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="0V" device=""/>
<part name="R24" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0805(2012-METRIC)" package3d_urn="urn:adsk.eagle:package:16378559/7" technology="_" value="470"/>
<part name="C16" library="rcl" library_urn="urn:adsk.eagle:library:334" deviceset="C-US" device="C1206" package3d_urn="urn:adsk.eagle:package:23618/2" value="0.1uF"/>
<part name="R25" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0805(2012-METRIC)" package3d_urn="urn:adsk.eagle:package:16378559/7" technology="_" value="2k41"/>
<part name="C17" library="rcl" library_urn="urn:adsk.eagle:library:334" deviceset="C-US" device="C1206" package3d_urn="urn:adsk.eagle:package:23618/2" value="0.1uF"/>
<part name="GND17" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="0V" device=""/>
<part name="C18" library="rcl" library_urn="urn:adsk.eagle:library:334" deviceset="C-US" device="C1206" package3d_urn="urn:adsk.eagle:package:23618/2" value="0.1uF"/>
<part name="R26" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0805(2012-METRIC)" package3d_urn="urn:adsk.eagle:package:16378559/7" technology="_" value="2k41"/>
<part name="R23" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0805(2012-METRIC)" package3d_urn="urn:adsk.eagle:package:16378559/7" technology="_" value="3k09"/>
<part name="GND19" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="0V" device=""/>
<part name="C19" library="rcl" library_urn="urn:adsk.eagle:library:334" deviceset="C-US" device="C0805" package3d_urn="urn:adsk.eagle:package:23617/2" value="100nF"/>
<part name="C20" library="rcl" library_urn="urn:adsk.eagle:library:334" deviceset="C-US" device="C0805" package3d_urn="urn:adsk.eagle:package:23617/2" value="10uF"/>
<part name="P+8" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="+24V" device=""/>
<part name="GND20" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="0V" device=""/>
<part name="R30" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0805(2012-METRIC)" package3d_urn="urn:adsk.eagle:package:16378559/7" technology="_" value="1k"/>
<part name="U$1" library="diodes" library_urn="urn:adsk.eagle:library:10801186" deviceset="LED" device="" package3d_urn="urn:adsk.eagle:package:16125211/2"/>
<part name="P+9" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="+24V" device=""/>
<part name="GND21" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="0V" device=""/>
<part name="D1" library="Circuit-Protection" library_urn="urn:adsk.eagle:library:16378135" deviceset="TVS" device="DO-214AC(SMA)" package3d_urn="urn:adsk.eagle:package:16378158/3" technology="_"/>
<part name="GND22" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="0V" device=""/>
<part name="P+10" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="+24V" device=""/>
<part name="J4" library="2025-10-28_16-15-34_Library" library_urn="urn:adsk.wipprod:fs.file:vf.AYd5E19VTza6wI4NEddNEA" deviceset="5499206-1" device="CON10_2X5_SHM_TEC"/>
<part name="P+11" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="+24V" device=""/>
<part name="P+13" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="+24V" device=""/>
<part name="F2" library="belfuse" library_urn="urn:adsk.wipprod:fs.file:vf.KZ5jnwlsSbOFGirIR93spw" deviceset="0ZCJ0010FF2E" device=""/>
<part name="F4" library="belfuse" library_urn="urn:adsk.wipprod:fs.file:vf.KZ5jnwlsSbOFGirIR93spw" deviceset="0ZCJ0010FF2E" device=""/>
<part name="F5" library="belfuse" library_urn="urn:adsk.wipprod:fs.file:vf.KZ5jnwlsSbOFGirIR93spw" deviceset="0ZCJ0010FF2E" device=""/>
<part name="F9" library="belfuse" library_urn="urn:adsk.wipprod:fs.file:vf.KZ5jnwlsSbOFGirIR93spw" deviceset="0ZCJ0010FF2E" device=""/>
<part name="CONTACTORS" library="molex 0039290083" library_urn="urn:adsk.wipprod:fs.file:vf.LM2bSIezQECa3ZpQ7Zadyg" deviceset="39290083" device="CONN_SD-5566-002_08_MOL"/>
<part name="D3" library="Diode" library_urn="urn:adsk.eagle:library:16378169" deviceset="DIODE_" device="_SOD123G" package3d_urn="urn:adsk.eagle:package:48498329/2" technology="1N4148W-7-F" value="1N4007"/>
<part name="R16" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0805(2012-METRIC)" package3d_urn="urn:adsk.eagle:package:16378559/7" technology="_" value="0"/>
<part name="R20" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0805(2012-METRIC)" package3d_urn="urn:adsk.eagle:package:16378559/7" technology="_" value="0"/>
<part name="GND5" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="0V" device=""/>
<part name="GND14" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="0V" device=""/>
<part name="D2" library="Diode" library_urn="urn:adsk.eagle:library:16378169" deviceset="DIODE_" device="_SOD123G" package3d_urn="urn:adsk.eagle:package:48498329/2" technology="1N4148W-7-F" value="1N4007"/>
<part name="D4" library="Diode" library_urn="urn:adsk.eagle:library:16378169" deviceset="DIODE_" device="_SOD123G" package3d_urn="urn:adsk.eagle:package:48498329/2" technology="1N4148W-7-F" value="1N4007"/>
<part name="D5" library="Diode" library_urn="urn:adsk.eagle:library:16378169" deviceset="DIODE_" device="_SOD123G" package3d_urn="urn:adsk.eagle:package:48498329/2" technology="1N4148W-7-F" value="1N4007"/>
<part name="R13" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0603(1608-METRIC)" package3d_urn="urn:adsk.eagle:package:16378565/7" technology="_"/>
<part name="R15" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0603(1608-METRIC)" package3d_urn="urn:adsk.eagle:package:16378565/7" technology="_"/>
<part name="R21" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0603(1608-METRIC)" package3d_urn="urn:adsk.eagle:package:16378565/7" technology="_"/>
<part name="R22" library="Resistor" library_urn="urn:adsk.eagle:library:16378527" deviceset="R" device="CHIP-0603(1608-METRIC)" package3d_urn="urn:adsk.eagle:package:16378565/7" technology="_"/>
<part name="GND2" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="D8" library="Diode" library_urn="urn:adsk.eagle:library:16378169" deviceset="DIODE" device="DO-219-AB(SOD123F)" package3d_urn="urn:adsk.eagle:package:48498333/2" technology="_" value="1N4007"/>
<part name="D9" library="Diode" library_urn="urn:adsk.eagle:library:16378169" deviceset="DIODE" device="DO-219-AB(SOD123F)" package3d_urn="urn:adsk.eagle:package:48498333/2" technology="_" value="1N4007"/>
<part name="CONN_THC" library="2026-07-04_06-14-31_Library" library_urn="urn:adsk.wipprod:fs.file:vf.1TXCxOWRTNqve3v8EGVzjg" deviceset="39288020" device="CONN_SD-5566-002_02_MOL"/>
<part name="CONN_PWR" library="2026-07-04_05-50-15_Library" library_urn="urn:adsk.wipprod:fs.file:vf.W5yNMnp4TBO4qhKgoN13yg" deviceset="39302031" device="CONN_55660330-SD_MOL"/>
<part name="CONN-MCU" library="molex 0039293066" library_urn="urn:adsk.wipprod:fs.file:vf.Ou0LArH8TIKCkPIh9_2_hw" deviceset="39293066" device="CONN_SD-5566-002_06_MOL"/>
<part name="GND3" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="0V" device=""/>
<part name="J1" library="2026-07-23_20-22-02_Library" library_urn="urn:adsk.wipprod:fs.file:vf.OJ38JIMhQ2mI8b7IQ-Zj-A" deviceset="1726470105" device="CONN_SD-172647-0000_05_MOL"/>
</parts>
<sheets>
<sheet>
<plain>
<text x="-83.82" y="116.84" size="1.778" layer="97">pull down</text>
<text x="-22.86" y="71.12" size="1.778" layer="97">output 0 - plasma start
output 2 - stepper enable
input 7 - ark OK</text>
<text x="81.28" y="185.42" size="1.778" layer="97">3rd Order Sallen-Key Low Pass filter with Bessel response</text>
<text x="175.26" y="185.42" size="1.778" layer="97">2nd Order Low-Pass Sallen-Key filter with Bessel response</text>
<text x="124.46" y="116.84" size="1.778" layer="97">http://sim.okawa-denshi.jp/en/OPstool.php</text>
<text x="132.08" y="175.26" size="1.778" layer="97">RC low pass final stage</text>
<text x="187.96" y="175.26" size="1.778" layer="97">RC low pass final stage</text>
<text x="-99.06" y="160.02" size="1.778" layer="97">optional, populate when used</text>
<text x="-53.34" y="129.54" size="1.778" layer="97">if Z-Axis is unused, jumper P1 to P2, 
so Arc voltage in is accessible to ANIN1</text>
</plain>
<instances>
<instance part="X-AXIS" gate="A" x="-167.64" y="101.6" smashed="yes">
<attribute name="NAME" x="-153.3154" y="101.8286" size="2.083" layer="95" ratio="6"/>
</instance>
<instance part="Y-AXIS" gate="A" x="-167.64" y="73.66" smashed="yes">
<attribute name="NAME" x="-153.3154" y="73.8886" size="2.083" layer="95" ratio="6"/>
</instance>
<instance part="Z-AXIS" gate="A" x="-167.64" y="45.72" smashed="yes">
<attribute name="NAME" x="-153.3154" y="45.9486" size="2.083" layer="95" ratio="6"/>
</instance>
<instance part="A-AXIS" gate="A" x="-167.64" y="17.78" smashed="yes">
<attribute name="NAME" x="-153.3154" y="18.0086" size="2.083" layer="95" ratio="6"/>
</instance>
<instance part="R1" gate="G$1" x="5.08" y="-5.08" smashed="yes" rot="R90">
<attribute name="NAME" x="5.08" y="0" size="1.778" layer="95" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="7.62" y="-5.08" size="1.778" layer="96" rot="R90" align="top-center"/>
</instance>
<instance part="R2" gate="G$1" x="10.16" y="-5.08" smashed="yes" rot="R90">
<attribute name="NAME" x="10.16" y="0" size="1.778" layer="95" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="12.7" y="-5.08" size="1.778" layer="96" rot="R90" align="top-center"/>
</instance>
<instance part="R3" gate="G$1" x="15.24" y="-5.08" smashed="yes" rot="R90">
<attribute name="NAME" x="15.24" y="0" size="1.778" layer="95" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="17.78" y="-5.08" size="1.778" layer="96" rot="R90" align="top-center"/>
</instance>
<instance part="R4" gate="G$1" x="20.32" y="-5.08" smashed="yes" rot="R90">
<attribute name="NAME" x="20.32" y="0" size="1.778" layer="95" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="22.86" y="-5.08" size="1.778" layer="96" rot="R90" align="top-center"/>
</instance>
<instance part="R5" gate="G$1" x="25.4" y="-5.08" smashed="yes" rot="R90">
<attribute name="NAME" x="25.4" y="0" size="1.778" layer="95" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="27.94" y="-5.08" size="1.778" layer="96" rot="R90" align="top-center"/>
</instance>
<instance part="R6" gate="G$1" x="30.48" y="-5.08" smashed="yes" rot="R90">
<attribute name="NAME" x="30.48" y="0" size="1.778" layer="95" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="33.02" y="-5.08" size="1.778" layer="96" rot="R90" align="top-center"/>
</instance>
<instance part="R7" gate="G$1" x="35.56" y="-5.08" smashed="yes" rot="R90">
<attribute name="NAME" x="35.56" y="0" size="1.778" layer="95" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="38.1" y="-5.08" size="1.778" layer="96" rot="R90" align="top-center"/>
</instance>
<instance part="R8" gate="G$1" x="40.64" y="-5.08" smashed="yes" rot="R90">
<attribute name="NAME" x="40.64" y="0" size="1.778" layer="95" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="43.18" y="-5.08" size="1.778" layer="96" rot="R90" align="top-center"/>
</instance>
<instance part="R9" gate="G$1" x="45.72" y="-5.08" smashed="yes" rot="R90">
<attribute name="NAME" x="45.72" y="0" size="1.778" layer="95" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="48.26" y="-5.08" size="1.778" layer="96" rot="R90" align="top-center"/>
</instance>
<instance part="R10" gate="G$1" x="50.8" y="-5.08" smashed="yes" rot="R90">
<attribute name="NAME" x="50.8" y="0" size="1.778" layer="95" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="53.34" y="-5.08" size="1.778" layer="96" rot="R90" align="top-center"/>
</instance>
<instance part="R11" gate="G$1" x="55.88" y="-5.08" smashed="yes" rot="R90">
<attribute name="NAME" x="55.88" y="0" size="1.778" layer="95" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="58.42" y="-5.08" size="1.778" layer="96" rot="R90" align="top-center"/>
</instance>
<instance part="P+2" gate="1" x="17.78" y="10.16" smashed="yes">
<attribute name="VALUE" x="15.24" y="5.08" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="R12" gate="G$1" x="60.96" y="-5.08" smashed="yes" rot="R90">
<attribute name="NAME" x="60.96" y="0" size="1.778" layer="95" rot="R90" align="bottom-center"/>
<attribute name="VALUE" x="63.5" y="-5.08" size="1.778" layer="96" rot="R90" align="top-center"/>
</instance>
<instance part="P+4" gate="1" x="-116.84" y="33.02" smashed="yes">
<attribute name="VALUE" x="-119.38" y="27.94" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="GND7" gate="1" x="-116.84" y="2.54" smashed="yes">
<attribute name="VALUE" x="-118.745" y="0" size="1.778" layer="96"/>
</instance>
<instance part="J2" gate="G$1" x="109.22" y="30.48" smashed="yes">
<attribute name="NAME" x="84.182" y="31.118" size="1.778" layer="95"/>
<attribute name="VALUE" x="83.828" y="28.016" size="1.778" layer="96"/>
</instance>
<instance part="J3" gate="G$1" x="-48.26" y="30.48" smashed="yes">
<attribute name="NAME" x="-49.83" y="45" size="1.27" layer="95"/>
<attribute name="VALUE" x="-51.81" y="14.3" size="1.27" layer="96"/>
</instance>
<instance part="P+5" gate="1" x="-38.1" y="53.34" smashed="yes">
<attribute name="VALUE" x="-40.64" y="48.26" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="VSS3" gate="G$1" x="119.38" y="50.8" smashed="yes" rot="R180">
<attribute name="VALUE" x="121.92" y="55.88" size="1.778" layer="96" rot="R270"/>
</instance>
<instance part="J5" gate="G$1" x="30.48" y="30.48" smashed="yes">
<attribute name="NAME" x="28.91" y="45" size="1.27" layer="95"/>
<attribute name="VALUE" x="26.93" y="14.3" size="1.27" layer="96"/>
</instance>
<instance part="GND12" gate="1" x="-5.08" y="0" smashed="yes">
<attribute name="VALUE" x="-6.985" y="-2.54" size="1.778" layer="96"/>
</instance>
<instance part="VSS1" gate="G$1" x="147.32" y="213.36" smashed="yes" rot="R180">
<attribute name="VALUE" x="149.86" y="218.44" size="1.778" layer="96" rot="R270"/>
</instance>
<instance part="GND1" gate="1" x="147.32" y="190.5" smashed="yes">
<attribute name="VALUE" x="145.415" y="187.96" size="1.778" layer="96"/>
</instance>
<instance part="C1" gate="G$1" x="142.24" y="203.2" smashed="yes">
<attribute name="NAME" x="143.256" y="203.835" size="1.778" layer="95"/>
<attribute name="VALUE" x="143.256" y="199.009" size="1.778" layer="96"/>
</instance>
<instance part="C2" gate="G$1" x="152.4" y="203.2" smashed="yes">
<attribute name="NAME" x="153.416" y="203.835" size="1.778" layer="95"/>
<attribute name="VALUE" x="153.416" y="199.009" size="1.778" layer="96"/>
</instance>
<instance part="P+6" gate="1" x="-182.88" y="109.22" smashed="yes">
<attribute name="VALUE" x="-185.42" y="104.14" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="GND10" gate="1" x="175.26" y="60.96" smashed="yes">
<attribute name="VALUE" x="173.355" y="58.42" size="1.778" layer="96"/>
</instance>
<instance part="GND4" gate="1" x="71.12" y="0" smashed="yes">
<attribute name="VALUE" x="69.215" y="-2.54" size="1.778" layer="96"/>
</instance>
<instance part="GND8" gate="1" x="134.62" y="0" smashed="yes">
<attribute name="VALUE" x="132.715" y="-2.54" size="1.778" layer="96"/>
</instance>
<instance part="F1" gate="A" x="-116.84" y="17.78" smashed="yes" rot="R90">
<attribute name="NAME" x="-118.2751" y="14.9652" size="3.48" layer="95" ratio="10" rot="R90"/>
</instance>
<instance part="GND6" gate="1" x="-134.62" y="-33.02" smashed="yes">
<attribute name="VALUE" x="-136.525" y="-35.56" size="1.778" layer="96"/>
</instance>
<instance part="C13" gate="G$1" x="-139.7" y="-20.32" smashed="yes">
<attribute name="NAME" x="-138.684" y="-19.685" size="1.778" layer="95"/>
<attribute name="VALUE" x="-138.684" y="-24.511" size="1.778" layer="96"/>
</instance>
<instance part="C14" gate="G$1" x="-129.54" y="-20.32" smashed="yes">
<attribute name="NAME" x="-128.524" y="-19.685" size="1.778" layer="95"/>
<attribute name="VALUE" x="-128.524" y="-24.511" size="1.778" layer="96"/>
</instance>
<instance part="P+3" gate="1" x="-134.62" y="-10.16" smashed="yes">
<attribute name="VALUE" x="-137.16" y="-15.24" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="U2" gate="G$1" x="147.32" y="149.86" smashed="yes">
<attribute name="VALUE" x="134.62" y="133.16" size="2.0828" layer="96" ratio="10" rot="SR0"/>
<attribute name="NAME" x="134.62" y="163.56" size="2.0828" layer="95" ratio="10" rot="SR0"/>
</instance>
<instance part="VSS4" gate="G$1" x="167.64" y="165.1" smashed="yes" rot="R180">
<attribute name="VALUE" x="160.02" y="165.1" size="1.778" layer="96"/>
</instance>
<instance part="GND9" gate="1" x="127" y="137.16" smashed="yes"/>
<instance part="C5" gate="G$1" x="170.18" y="134.62" smashed="yes">
<attribute name="NAME" x="171.196" y="135.255" size="1.778" layer="95"/>
<attribute name="VALUE" x="171.196" y="130.429" size="1.778" layer="96"/>
</instance>
<instance part="R14" gate="G$1" x="177.8" y="142.24" smashed="yes" rot="R180">
<attribute name="NAME" x="177.8" y="139.7" size="1.778" layer="95" rot="R180" align="bottom-center"/>
<attribute name="VALUE" x="177.8" y="144.78" size="1.778" layer="96" rot="R180" align="top-center"/>
</instance>
<instance part="R17" gate="G$1" x="114.3" y="147.32" smashed="yes" rot="R180">
<attribute name="NAME" x="114.3" y="144.78" size="1.778" layer="95" rot="R180" align="bottom-center"/>
<attribute name="VALUE" x="114.3" y="149.86" size="1.778" layer="96" rot="R180" align="top-center"/>
</instance>
<instance part="R18" gate="G$1" x="101.6" y="147.32" smashed="yes" rot="R180">
<attribute name="NAME" x="101.6" y="144.78" size="1.778" layer="95" rot="R180" align="bottom-center"/>
<attribute name="VALUE" x="101.6" y="149.86" size="1.778" layer="96" rot="R180" align="top-center"/>
</instance>
<instance part="C6" gate="G$1" x="185.42" y="152.4" smashed="yes">
<attribute name="NAME" x="186.436" y="153.035" size="1.778" layer="95"/>
<attribute name="VALUE" x="186.436" y="148.209" size="1.778" layer="96"/>
</instance>
<instance part="GND11" gate="1" x="170.18" y="121.92" smashed="yes">
<attribute name="VALUE" x="168.275" y="119.38" size="1.778" layer="96"/>
</instance>
<instance part="C7" gate="G$1" x="121.92" y="134.62" smashed="yes">
<attribute name="NAME" x="122.936" y="135.255" size="1.778" layer="95"/>
<attribute name="VALUE" x="122.936" y="130.429" size="1.778" layer="96"/>
</instance>
<instance part="C8" gate="G$1" x="106.68" y="154.94" smashed="yes">
<attribute name="NAME" x="107.696" y="155.575" size="1.778" layer="95"/>
<attribute name="VALUE" x="107.696" y="150.749" size="1.778" layer="96"/>
</instance>
<instance part="GND13" gate="1" x="121.92" y="121.92" smashed="yes">
<attribute name="VALUE" x="120.015" y="119.38" size="1.778" layer="96"/>
</instance>
<instance part="GND18" gate="1" x="114.3" y="162.56" smashed="yes">
<attribute name="VALUE" x="112.395" y="160.02" size="1.778" layer="96"/>
</instance>
<instance part="R19" gate="G$1" x="129.54" y="167.64" smashed="yes" rot="R270">
<attribute name="NAME" x="132.08" y="167.64" size="1.778" layer="95" rot="R270" align="bottom-center"/>
<attribute name="VALUE" x="127" y="167.64" size="1.778" layer="96" rot="R270" align="top-center"/>
</instance>
<instance part="C15" gate="G$1" x="114.3" y="172.72" smashed="yes">
<attribute name="NAME" x="115.316" y="173.355" size="1.778" layer="95"/>
<attribute name="VALUE" x="115.316" y="168.529" size="1.778" layer="96"/>
</instance>
<instance part="GND16" gate="1" x="172.72" y="162.56" smashed="yes">
<attribute name="VALUE" x="170.815" y="160.02" size="1.778" layer="96"/>
</instance>
<instance part="R24" gate="G$1" x="185.42" y="167.64" smashed="yes" rot="R270">
<attribute name="NAME" x="187.96" y="167.64" size="1.778" layer="95" rot="R270" align="bottom-center"/>
<attribute name="VALUE" x="182.88" y="167.64" size="1.778" layer="96" rot="R270" align="top-center"/>
</instance>
<instance part="C16" gate="G$1" x="172.72" y="172.72" smashed="yes">
<attribute name="NAME" x="173.736" y="173.355" size="1.778" layer="95"/>
<attribute name="VALUE" x="173.736" y="168.529" size="1.778" layer="96"/>
</instance>
<instance part="R25" gate="G$1" x="86.36" y="147.32" smashed="yes" rot="R180">
<attribute name="NAME" x="86.36" y="144.78" size="1.778" layer="95" rot="R180" align="bottom-center"/>
<attribute name="VALUE" x="86.36" y="149.86" size="1.778" layer="96" rot="R180" align="top-center"/>
</instance>
<instance part="C17" gate="G$1" x="93.98" y="134.62" smashed="yes">
<attribute name="NAME" x="94.996" y="135.255" size="1.778" layer="95"/>
<attribute name="VALUE" x="94.996" y="130.429" size="1.778" layer="96"/>
</instance>
<instance part="GND17" gate="1" x="93.98" y="121.92" smashed="yes">
<attribute name="VALUE" x="92.075" y="119.38" size="1.778" layer="96"/>
</instance>
<instance part="C18" gate="G$1" x="203.2" y="134.62" smashed="yes">
<attribute name="NAME" x="204.216" y="135.255" size="1.778" layer="95"/>
<attribute name="VALUE" x="204.216" y="130.429" size="1.778" layer="96"/>
</instance>
<instance part="R26" gate="G$1" x="215.9" y="142.24" smashed="yes" rot="R180">
<attribute name="NAME" x="215.9" y="139.7" size="1.778" layer="95" rot="R180" align="bottom-center"/>
<attribute name="VALUE" x="215.9" y="144.78" size="1.778" layer="96" rot="R180" align="top-center"/>
</instance>
<instance part="R23" gate="G$1" x="195.58" y="142.24" smashed="yes" rot="R180">
<attribute name="NAME" x="195.58" y="139.7" size="1.778" layer="95" rot="R180" align="bottom-center"/>
<attribute name="VALUE" x="195.58" y="144.78" size="1.778" layer="96" rot="R180" align="top-center"/>
</instance>
<instance part="GND19" gate="1" x="-167.64" y="119.38" smashed="yes">
<attribute name="VALUE" x="-169.545" y="116.84" size="1.778" layer="96"/>
</instance>
<instance part="C19" gate="G$1" x="-172.72" y="132.08" smashed="yes">
<attribute name="NAME" x="-171.704" y="132.715" size="1.778" layer="95"/>
<attribute name="VALUE" x="-171.704" y="127.889" size="1.778" layer="96"/>
</instance>
<instance part="C20" gate="G$1" x="-162.56" y="132.08" smashed="yes">
<attribute name="NAME" x="-161.544" y="132.715" size="1.778" layer="95"/>
<attribute name="VALUE" x="-161.544" y="127.889" size="1.778" layer="96"/>
</instance>
<instance part="P+8" gate="1" x="-167.64" y="142.24" smashed="yes">
<attribute name="VALUE" x="-170.18" y="137.16" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="GND20" gate="1" x="203.2" y="121.92" smashed="yes">
<attribute name="VALUE" x="201.295" y="119.38" size="1.778" layer="96"/>
</instance>
<instance part="R30" gate="G$1" x="-78.74" y="99.06" smashed="yes" rot="R270">
<attribute name="NAME" x="-78.74" y="93.98" size="1.778" layer="95" rot="R270" align="bottom-center"/>
<attribute name="VALUE" x="-78.74" y="104.14" size="1.778" layer="96" rot="R270" align="top-center"/>
</instance>
<instance part="U$1" gate="G$1" x="-78.74" y="83.82" smashed="yes">
<attribute name="NAME" x="-82.169" y="79.248" size="1.778" layer="95" font="vector" rot="R90"/>
<attribute name="VALUE" x="-76.835" y="79.248" size="1.778" layer="96" font="vector" rot="R90" align="top-left"/>
</instance>
<instance part="P+9" gate="1" x="-78.74" y="111.76" smashed="yes">
<attribute name="VALUE" x="-81.28" y="106.68" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="GND21" gate="1" x="-78.74" y="71.12" smashed="yes">
<attribute name="VALUE" x="-80.645" y="68.58" size="1.778" layer="96"/>
</instance>
<instance part="D1" gate="G$1" x="-106.68" y="-22.86" smashed="yes" rot="R90">
<attribute name="NAME" x="-109.22" y="-22.86" size="1.778" layer="95" rot="R90" align="center"/>
<attribute name="VALUE" x="-104.14" y="-22.86" size="1.778" layer="96" rot="R90" align="center"/>
</instance>
<instance part="GND22" gate="1" x="-106.68" y="-38.1" smashed="yes">
<attribute name="VALUE" x="-108.585" y="-40.64" size="1.778" layer="96"/>
</instance>
<instance part="P+10" gate="1" x="-106.68" y="-7.62" smashed="yes">
<attribute name="VALUE" x="-109.22" y="-12.7" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="J4" gate="A" x="177.8" y="96.52" smashed="yes">
<attribute name="NAME" x="181.9646" y="101.8286" size="2.083" layer="95" ratio="6"/>
</instance>
<instance part="P+11" gate="1" x="172.72" y="106.68" smashed="yes">
<attribute name="VALUE" x="170.18" y="101.6" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="P+13" gate="1" x="-12.7" y="40.64" smashed="yes">
<attribute name="VALUE" x="-15.24" y="35.56" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="F2" gate="A" x="-66.04" y="180.34" smashed="yes">
<attribute name="NAME" x="-68.8548" y="181.7751" size="3.48" layer="95" ratio="10"/>
</instance>
<instance part="F4" gate="A" x="-66.04" y="182.88" smashed="yes">
<attribute name="NAME" x="-68.8548" y="184.3151" size="3.48" layer="95" ratio="10"/>
</instance>
<instance part="F5" gate="A" x="-66.04" y="185.42" smashed="yes">
<attribute name="NAME" x="-68.8548" y="186.8551" size="3.48" layer="95" ratio="10"/>
</instance>
<instance part="F9" gate="A" x="-66.04" y="187.96" smashed="yes">
<attribute name="NAME" x="-68.8548" y="189.3951" size="3.48" layer="95" ratio="10"/>
</instance>
<instance part="CONTACTORS" gate="A" x="-38.1" y="187.96" smashed="yes">
<attribute name="NAME" x="-23.7754" y="188.1886" size="2.083" layer="95" ratio="6"/>
</instance>
<instance part="D3" gate="G$1" x="-71.12" y="172.72" smashed="yes" rot="R90">
<attribute name="NAME" x="-73.66" y="172.72" size="1.778" layer="95" rot="R90" align="center"/>
<attribute name="VALUE" x="-68.58" y="172.72" size="1.778" layer="96" rot="R90" align="center"/>
</instance>
<instance part="R16" gate="G$1" x="-208.28" y="96.52" smashed="yes">
<attribute name="NAME" x="-208.28" y="99.06" size="1.778" layer="95" align="bottom-center"/>
<attribute name="VALUE" x="-208.28" y="93.98" size="1.778" layer="96" align="top-center"/>
</instance>
<instance part="R20" gate="G$1" x="-208.28" y="83.82" smashed="yes">
<attribute name="NAME" x="-208.28" y="86.36" size="1.778" layer="95" align="bottom-center"/>
<attribute name="VALUE" x="-208.28" y="81.28" size="1.778" layer="96" align="top-center"/>
</instance>
<instance part="GND5" gate="1" x="-63.5" y="157.48" smashed="yes">
<attribute name="VALUE" x="-65.405" y="154.94" size="1.778" layer="96"/>
</instance>
<instance part="GND14" gate="1" x="-218.44" y="91.44" smashed="yes">
<attribute name="VALUE" x="-220.345" y="88.9" size="1.778" layer="96"/>
</instance>
<instance part="D2" gate="G$1" x="-76.2" y="172.72" smashed="yes" rot="R90">
<attribute name="NAME" x="-78.74" y="172.72" size="1.778" layer="95" rot="R90" align="center"/>
<attribute name="VALUE" x="-73.66" y="172.72" size="1.778" layer="96" rot="R90" align="center"/>
</instance>
<instance part="D4" gate="G$1" x="-81.28" y="172.72" smashed="yes" rot="R90">
<attribute name="NAME" x="-83.82" y="172.72" size="1.778" layer="95" rot="R90" align="center"/>
<attribute name="VALUE" x="-78.74" y="172.72" size="1.778" layer="96" rot="R90" align="center"/>
</instance>
<instance part="D5" gate="G$1" x="-86.36" y="172.72" smashed="yes" rot="R90">
<attribute name="NAME" x="-88.9" y="172.72" size="1.778" layer="95" rot="R90" align="center"/>
<attribute name="VALUE" x="-83.82" y="172.72" size="1.778" layer="96" rot="R90" align="center"/>
</instance>
<instance part="R13" gate="G$1" x="-48.26" y="187.96" smashed="yes">
<attribute name="NAME" x="-48.26" y="190.5" size="1.778" layer="95" align="bottom-center"/>
<attribute name="VALUE" x="-48.26" y="185.42" size="1.778" layer="96" align="top-center"/>
</instance>
<instance part="R15" gate="G$1" x="-48.26" y="182.88" smashed="yes">
<attribute name="NAME" x="-48.26" y="185.42" size="1.778" layer="95" align="bottom-center"/>
<attribute name="VALUE" x="-48.26" y="180.34" size="1.778" layer="96" align="top-center"/>
</instance>
<instance part="R21" gate="G$1" x="-48.26" y="185.42" smashed="yes">
<attribute name="NAME" x="-48.26" y="187.96" size="1.778" layer="95" align="bottom-center"/>
<attribute name="VALUE" x="-48.26" y="182.88" size="1.778" layer="96" align="top-center"/>
</instance>
<instance part="R22" gate="G$1" x="-48.26" y="180.34" smashed="yes">
<attribute name="NAME" x="-48.26" y="182.88" size="1.778" layer="95" align="bottom-center"/>
<attribute name="VALUE" x="-48.26" y="177.8" size="1.778" layer="96" align="top-center"/>
</instance>
<instance part="GND2" gate="1" x="-109.22" y="0" smashed="yes">
<attribute name="VALUE" x="-111.76" y="-2.54" size="1.778" layer="96"/>
</instance>
<instance part="D8" gate="G$1" x="-142.24" y="177.8" smashed="yes">
<attribute name="NAME" x="-142.24" y="180.34" size="1.778" layer="95" align="center"/>
<attribute name="VALUE" x="-142.24" y="175.26" size="1.778" layer="96" align="center"/>
</instance>
<instance part="D9" gate="G$1" x="-119.38" y="177.8" smashed="yes" rot="R180">
<attribute name="NAME" x="-119.38" y="175.26" size="1.778" layer="95" rot="R180" align="center"/>
<attribute name="VALUE" x="-119.38" y="180.34" size="1.778" layer="96" rot="R180" align="center"/>
</instance>
<instance part="CONN_THC" gate="A" x="-132.08" y="198.12" smashed="yes">
<attribute name="NAME" x="-127.9154" y="203.4286" size="2.083" layer="95" ratio="6"/>
</instance>
<instance part="CONN_PWR" gate="A" x="-106.68" y="17.78" smashed="yes">
<attribute name="NAME" x="-102.5154" y="23.0886" size="2.083" layer="95" ratio="6"/>
</instance>
<instance part="CONN-MCU" gate="A" x="215.9" y="93.98" smashed="yes">
<attribute name="NAME" x="220.0646" y="99.2886" size="2.083" layer="95" ratio="6"/>
</instance>
<instance part="GND3" gate="1" x="210.82" y="71.12" smashed="yes">
<attribute name="VALUE" x="208.915" y="68.58" size="1.778" layer="96"/>
</instance>
<instance part="J1" gate="A" x="-104.14" y="73.66" smashed="yes">
<attribute name="NAME" x="-99.9754" y="78.9686" size="2.083" layer="95" ratio="6"/>
</instance>
</instances>
<busses>
</busses>
<nets>
<net name="DIR[0]_P" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="1"/>
<wire x1="-78.74" y1="40.64" x2="-78.74" y2="45.72" width="0.1524" layer="91"/>
<label x="-78.74" y="45.72" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="-167.64" y1="91.44" x2="-172.72" y2="91.44" width="0.1524" layer="91"/>
<label x="-180.34" y="91.44" size="1.778" layer="95"/>
<pinref part="X-AXIS" gate="A" pin="5"/>
</segment>
</net>
<net name="STEP[0]_P" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="2"/>
<wire x1="-73.66" y1="40.64" x2="-73.66" y2="48.26" width="0.1524" layer="91"/>
<label x="-73.66" y="45.72" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="-172.72" y1="88.9" x2="-167.64" y2="88.9" width="0.1524" layer="91"/>
<label x="-180.34" y="88.9" size="1.778" layer="95"/>
<pinref part="X-AXIS" gate="A" pin="6"/>
</segment>
</net>
<net name="DIR[1]_P" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="3"/>
<wire x1="-68.58" y1="40.64" x2="-68.58" y2="48.26" width="0.1524" layer="91"/>
<label x="-68.58" y="45.72" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="-167.64" y1="71.12" x2="-172.72" y2="71.12" width="0.1524" layer="91"/>
<label x="-180.34" y="71.12" size="1.778" layer="95"/>
<pinref part="Y-AXIS" gate="A" pin="2"/>
</segment>
</net>
<net name="STEP[1]_P" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="4"/>
<wire x1="-63.5" y1="40.64" x2="-63.5" y2="48.26" width="0.1524" layer="91"/>
<label x="-63.5" y="45.72" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="-172.72" y1="73.66" x2="-167.64" y2="73.66" width="0.1524" layer="91"/>
<label x="-180.34" y="73.66" size="1.778" layer="95"/>
<pinref part="Y-AXIS" gate="A" pin="1"/>
</segment>
</net>
<net name="DIR[2]_P" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="5"/>
<wire x1="-58.42" y1="40.64" x2="-58.42" y2="48.26" width="0.1524" layer="91"/>
<label x="-58.42" y="45.72" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="-167.64" y1="33.02" x2="-172.72" y2="33.02" width="0.1524" layer="91"/>
<label x="-180.34" y="33.02" size="1.778" layer="95"/>
<pinref part="Z-AXIS" gate="A" pin="6"/>
</segment>
</net>
<net name="STEP[2]_P" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="6"/>
<wire x1="-53.34" y1="40.64" x2="-53.34" y2="48.26" width="0.1524" layer="91"/>
<label x="-53.34" y="45.72" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="-172.72" y1="30.48" x2="-167.64" y2="30.48" width="0.1524" layer="91"/>
<label x="-180.34" y="30.48" size="1.778" layer="95"/>
<pinref part="Z-AXIS" gate="A" pin="7"/>
</segment>
</net>
<net name="DIR[3]_P" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="7"/>
<wire x1="-48.26" y1="40.64" x2="-48.26" y2="48.26" width="0.1524" layer="91"/>
<label x="-48.26" y="45.72" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="-167.64" y1="5.08" x2="-172.72" y2="5.08" width="0.1524" layer="91"/>
<label x="-177.8" y="5.08" size="1.778" layer="95"/>
<pinref part="A-AXIS" gate="A" pin="6"/>
</segment>
</net>
<net name="STEP[3]_P" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="8"/>
<wire x1="-43.18" y1="40.64" x2="-43.18" y2="48.26" width="0.1524" layer="91"/>
<label x="-43.18" y="45.72" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="-167.64" y1="7.62" x2="-172.72" y2="7.62" width="0.1524" layer="91"/>
<label x="-180.34" y="7.62" size="1.778" layer="95"/>
<pinref part="A-AXIS" gate="A" pin="5"/>
</segment>
</net>
<net name="OUTPUT2" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="11"/>
<wire x1="-27.94" y1="40.64" x2="-27.94" y2="48.26" width="0.1524" layer="91"/>
<label x="-27.94" y="45.72" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="-223.52" y1="83.82" x2="-213.36" y2="83.82" width="0.1524" layer="91"/>
<pinref part="R20" gate="G$1" pin="1"/>
<label x="-228.6" y="83.82" size="1.778" layer="95"/>
</segment>
</net>
<net name="OUTPUT4" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="12"/>
<wire x1="-22.86" y1="40.64" x2="-22.86" y2="48.26" width="0.1524" layer="91"/>
<label x="-22.86" y="45.72" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<label x="-86.36" y="185.42" size="1.778" layer="95"/>
<wire x1="-91.44" y1="185.42" x2="-81.28" y2="185.42" width="0.1524" layer="91"/>
<pinref part="F5" gate="A" pin="1"/>
<wire x1="-81.28" y1="185.42" x2="-66.04" y2="185.42" width="0.1524" layer="91"/>
<wire x1="-81.28" y1="175.26" x2="-81.28" y2="185.42" width="0.1524" layer="91"/>
<junction x="-81.28" y="185.42"/>
<pinref part="D4" gate="G$1" pin="C"/>
</segment>
</net>
<net name="OUTPUT5" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="13"/>
<wire x1="-17.78" y1="40.64" x2="-17.78" y2="48.26" width="0.1524" layer="91"/>
<label x="-17.78" y="45.72" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<label x="-86.36" y="187.96" size="1.778" layer="95"/>
<wire x1="-91.44" y1="187.96" x2="-86.36" y2="187.96" width="0.1524" layer="91"/>
<pinref part="F9" gate="A" pin="1"/>
<wire x1="-86.36" y1="187.96" x2="-66.04" y2="187.96" width="0.1524" layer="91"/>
<wire x1="-86.36" y1="175.26" x2="-86.36" y2="187.96" width="0.1524" layer="91"/>
<junction x="-86.36" y="187.96"/>
<pinref part="D5" gate="G$1" pin="C"/>
</segment>
</net>
<net name="DIR[0]_N" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="14"/>
<wire x1="-76.2" y1="20.32" x2="-76.2" y2="15.24" width="0.1524" layer="91"/>
<label x="-76.2" y="5.08" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="-167.64" y1="101.6" x2="-172.72" y2="101.6" width="0.1524" layer="91"/>
<label x="-180.34" y="101.6" size="1.778" layer="95"/>
<pinref part="X-AXIS" gate="A" pin="1"/>
</segment>
</net>
<net name="STEP[0]_N" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="15"/>
<wire x1="-71.12" y1="20.32" x2="-71.12" y2="15.24" width="0.1524" layer="91"/>
<label x="-71.12" y="5.08" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="-167.64" y1="99.06" x2="-172.72" y2="99.06" width="0.1524" layer="91"/>
<label x="-180.34" y="99.06" size="1.778" layer="95"/>
<pinref part="X-AXIS" gate="A" pin="2"/>
</segment>
</net>
<net name="DIR[1]_N" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="16"/>
<wire x1="-66.04" y1="20.32" x2="-66.04" y2="15.24" width="0.1524" layer="91"/>
<label x="-66.04" y="5.08" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="-172.72" y1="60.96" x2="-167.64" y2="60.96" width="0.1524" layer="91"/>
<label x="-180.34" y="60.96" size="1.778" layer="95"/>
<pinref part="Y-AXIS" gate="A" pin="6"/>
</segment>
</net>
<net name="DIR[2]_N" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="18"/>
<wire x1="-55.88" y1="20.32" x2="-55.88" y2="15.24" width="0.1524" layer="91"/>
<label x="-55.88" y="5.08" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="-167.64" y1="43.18" x2="-172.72" y2="43.18" width="0.1524" layer="91"/>
<label x="-180.34" y="43.18" size="1.778" layer="95"/>
<pinref part="Z-AXIS" gate="A" pin="2"/>
</segment>
</net>
<net name="STEP[2]_N" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="19"/>
<wire x1="-50.8" y1="20.32" x2="-50.8" y2="15.24" width="0.1524" layer="91"/>
<label x="-50.8" y="5.08" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="-172.72" y1="40.64" x2="-167.64" y2="40.64" width="0.1524" layer="91"/>
<label x="-180.34" y="40.64" size="1.778" layer="95"/>
<pinref part="Z-AXIS" gate="A" pin="3"/>
</segment>
</net>
<net name="DIR[3]_N" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="20"/>
<wire x1="-45.72" y1="20.32" x2="-45.72" y2="15.24" width="0.1524" layer="91"/>
<label x="-45.72" y="5.08" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="-167.64" y1="15.24" x2="-172.72" y2="15.24" width="0.1524" layer="91"/>
<label x="-180.34" y="15.24" size="1.778" layer="95"/>
<pinref part="A-AXIS" gate="A" pin="2"/>
</segment>
</net>
<net name="STEP[3]_N" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="21"/>
<wire x1="-40.64" y1="20.32" x2="-40.64" y2="15.24" width="0.1524" layer="91"/>
<label x="-40.64" y="5.08" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="-167.64" y1="17.78" x2="-172.72" y2="17.78" width="0.1524" layer="91"/>
<label x="-180.34" y="17.78" size="1.778" layer="95"/>
<pinref part="A-AXIS" gate="A" pin="1"/>
</segment>
</net>
<net name="OUTPUT1" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="23"/>
<wire x1="-30.48" y1="20.32" x2="-30.48" y2="15.24" width="0.1524" layer="91"/>
<label x="-30.48" y="7.62" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="-91.44" y1="182.88" x2="-76.2" y2="182.88" width="0.1524" layer="91"/>
<pinref part="F4" gate="A" pin="1"/>
<label x="-86.36" y="182.88" size="1.778" layer="95"/>
<wire x1="-76.2" y1="182.88" x2="-66.04" y2="182.88" width="0.1524" layer="91"/>
<wire x1="-76.2" y1="175.26" x2="-76.2" y2="182.88" width="0.1524" layer="91"/>
<junction x="-76.2" y="182.88"/>
<pinref part="D2" gate="G$1" pin="C"/>
</segment>
</net>
<net name="OUTPUT3" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="24"/>
<wire x1="-25.4" y1="20.32" x2="-25.4" y2="15.24" width="0.1524" layer="91"/>
<label x="-25.4" y="7.62" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="-91.44" y1="180.34" x2="-71.12" y2="180.34" width="0.1524" layer="91"/>
<pinref part="F2" gate="A" pin="1"/>
<label x="-86.36" y="180.34" size="1.778" layer="95"/>
<wire x1="-71.12" y1="180.34" x2="-66.04" y2="180.34" width="0.1524" layer="91"/>
<wire x1="-71.12" y1="175.26" x2="-71.12" y2="180.34" width="0.1524" layer="91"/>
<junction x="-71.12" y="180.34"/>
<pinref part="D3" gate="G$1" pin="C"/>
</segment>
</net>
<net name="INPUT[0]+" class="0">
<segment>
<label x="0" y="43.18" size="1.778" layer="95" rot="R90"/>
<wire x1="0" y1="50.8" x2="0" y2="40.64" width="0.1524" layer="91"/>
<pinref part="J5" gate="G$1" pin="1"/>
</segment>
<segment>
<pinref part="R12" gate="G$1" pin="1"/>
<wire x1="60.96" y1="-10.16" x2="60.96" y2="-15.24" width="0.1524" layer="91"/>
<label x="60.96" y="-22.86" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<label x="-137.16" y="73.66" size="1.778" layer="95"/>
<wire x1="-127" y1="73.66" x2="-104.14" y2="73.66" width="0.1524" layer="91"/>
<pinref part="J1" gate="A" pin="1"/>
</segment>
</net>
<net name="INPUT[1]+" class="0">
<segment>
<label x="5.08" y="43.18" size="1.778" layer="95" rot="R90"/>
<pinref part="J5" gate="G$1" pin="2"/>
<wire x1="5.08" y1="40.64" x2="5.08" y2="48.26" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="R1" gate="G$1" pin="1"/>
<wire x1="5.08" y1="-10.16" x2="5.08" y2="-15.24" width="0.1524" layer="91"/>
<label x="5.08" y="-22.86" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<label x="-137.16" y="71.12" size="1.778" layer="95"/>
<wire x1="-104.14" y1="71.12" x2="-127" y2="71.12" width="0.1524" layer="91"/>
<pinref part="J1" gate="A" pin="2"/>
</segment>
</net>
<net name="INPUT[2]+" class="0">
<segment>
<label x="10.16" y="43.18" size="1.778" layer="95" rot="R90"/>
<pinref part="J5" gate="G$1" pin="3"/>
<wire x1="10.16" y1="40.64" x2="10.16" y2="45.72" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="R2" gate="G$1" pin="1"/>
<wire x1="10.16" y1="-10.16" x2="10.16" y2="-15.24" width="0.1524" layer="91"/>
<label x="10.16" y="-22.86" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<label x="-137.16" y="68.58" size="1.778" layer="95"/>
<wire x1="-127" y1="68.58" x2="-104.14" y2="68.58" width="0.1524" layer="91"/>
<pinref part="J1" gate="A" pin="3"/>
</segment>
</net>
<net name="INPUT[3]+" class="0">
<segment>
<label x="15.24" y="43.18" size="1.778" layer="95" rot="R90"/>
<pinref part="J5" gate="G$1" pin="4"/>
<wire x1="15.24" y1="40.64" x2="15.24" y2="45.72" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="R3" gate="G$1" pin="1"/>
<wire x1="15.24" y1="-10.16" x2="15.24" y2="-15.24" width="0.1524" layer="91"/>
<label x="15.24" y="-22.86" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<label x="-137.16" y="66.04" size="1.778" layer="95"/>
<wire x1="-104.14" y1="66.04" x2="-137.16" y2="66.04" width="0.1524" layer="91"/>
<pinref part="J1" gate="A" pin="4"/>
</segment>
</net>
<net name="INPUT[4]+" class="0">
<segment>
<label x="20.32" y="43.18" size="1.778" layer="95" rot="R90"/>
<pinref part="J5" gate="G$1" pin="5"/>
<wire x1="20.32" y1="40.64" x2="20.32" y2="45.72" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="R4" gate="G$1" pin="1"/>
<wire x1="20.32" y1="-10.16" x2="20.32" y2="-15.24" width="0.1524" layer="91"/>
<label x="20.32" y="-22.86" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<label x="-137.16" y="63.5" size="1.778" layer="95"/>
<wire x1="-127" y1="63.5" x2="-104.14" y2="63.5" width="0.1524" layer="91"/>
<pinref part="J1" gate="A" pin="5"/>
</segment>
</net>
<net name="INPUT[8]+" class="0">
<segment>
<label x="40.64" y="43.18" size="1.778" layer="95" rot="R90"/>
<pinref part="J5" gate="G$1" pin="9"/>
<wire x1="40.64" y1="40.64" x2="40.64" y2="53.34" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="R8" gate="G$1" pin="1"/>
<wire x1="40.64" y1="-10.16" x2="40.64" y2="-15.24" width="0.1524" layer="91"/>
<label x="40.64" y="-22.86" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="-172.72" y1="45.72" x2="-167.64" y2="45.72" width="0.1524" layer="91"/>
<label x="-180.34" y="45.72" size="1.778" layer="95"/>
<pinref part="Z-AXIS" gate="A" pin="1"/>
</segment>
</net>
<net name="INPUT[9]+" class="0">
<segment>
<label x="45.72" y="43.18" size="1.778" layer="95" rot="R90"/>
<pinref part="J5" gate="G$1" pin="10"/>
<wire x1="45.72" y1="40.64" x2="45.72" y2="50.8" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="R9" gate="G$1" pin="1"/>
<wire x1="45.72" y1="-10.16" x2="45.72" y2="-15.24" width="0.1524" layer="91"/>
<label x="45.72" y="-22.86" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="-167.64" y1="10.16" x2="-172.72" y2="10.16" width="0.1524" layer="91"/>
<label x="-180.34" y="10.16" size="1.778" layer="95"/>
<pinref part="A-AXIS" gate="A" pin="4"/>
</segment>
</net>
<net name="INPUT[10]+" class="0">
<segment>
<label x="50.8" y="43.18" size="1.778" layer="95" rot="R90"/>
<pinref part="J5" gate="G$1" pin="11"/>
<wire x1="50.8" y1="40.64" x2="50.8" y2="48.26" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="R10" gate="G$1" pin="1"/>
<wire x1="50.8" y1="-10.16" x2="50.8" y2="-15.24" width="0.1524" layer="91"/>
<label x="50.8" y="-22.86" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="-167.64" y1="66.04" x2="-172.72" y2="66.04" width="0.1524" layer="91"/>
<label x="-180.34" y="66.04" size="1.778" layer="95"/>
<pinref part="Y-AXIS" gate="A" pin="4"/>
</segment>
</net>
<net name="INPUT[11]+" class="0">
<segment>
<label x="55.88" y="43.18" size="1.778" layer="95" rot="R90"/>
<pinref part="J5" gate="G$1" pin="12"/>
<wire x1="55.88" y1="40.64" x2="55.88" y2="45.72" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="R11" gate="G$1" pin="1"/>
<wire x1="55.88" y1="-10.16" x2="55.88" y2="-15.24" width="0.1524" layer="91"/>
<label x="55.88" y="-22.86" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="-167.64" y1="83.82" x2="-172.72" y2="83.82" width="0.1524" layer="91"/>
<label x="-180.34" y="83.82" size="1.778" layer="95"/>
<pinref part="X-AXIS" gate="A" pin="8"/>
</segment>
</net>
<net name="+24V" class="0">
<segment>
<pinref part="P+2" gate="1" pin="+24V"/>
<wire x1="17.78" y1="7.62" x2="17.78" y2="2.54" width="0.1524" layer="91"/>
<pinref part="R1" gate="G$1" pin="2"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="0" width="0.1524" layer="91"/>
<wire x1="5.08" y1="2.54" x2="10.16" y2="2.54" width="0.1524" layer="91"/>
<wire x1="10.16" y1="2.54" x2="15.24" y2="2.54" width="0.1524" layer="91"/>
<wire x1="10.16" y1="2.54" x2="10.16" y2="0" width="0.1524" layer="91"/>
<pinref part="R2" gate="G$1" pin="2"/>
<wire x1="15.24" y1="2.54" x2="17.78" y2="2.54" width="0.1524" layer="91"/>
<wire x1="17.78" y1="2.54" x2="20.32" y2="2.54" width="0.1524" layer="91"/>
<wire x1="20.32" y1="2.54" x2="25.4" y2="2.54" width="0.1524" layer="91"/>
<wire x1="15.24" y1="2.54" x2="15.24" y2="0" width="0.1524" layer="91"/>
<pinref part="R3" gate="G$1" pin="2"/>
<wire x1="20.32" y1="2.54" x2="20.32" y2="0" width="0.1524" layer="91"/>
<pinref part="R4" gate="G$1" pin="2"/>
<wire x1="25.4" y1="2.54" x2="25.4" y2="0" width="0.1524" layer="91"/>
<pinref part="R5" gate="G$1" pin="2"/>
<wire x1="30.48" y1="2.54" x2="30.48" y2="0" width="0.1524" layer="91"/>
<pinref part="R6" gate="G$1" pin="2"/>
<wire x1="35.56" y1="2.54" x2="35.56" y2="0" width="0.1524" layer="91"/>
<pinref part="R7" gate="G$1" pin="2"/>
<wire x1="40.64" y1="2.54" x2="40.64" y2="0" width="0.1524" layer="91"/>
<pinref part="R8" gate="G$1" pin="2"/>
<wire x1="45.72" y1="2.54" x2="45.72" y2="0" width="0.1524" layer="91"/>
<pinref part="R9" gate="G$1" pin="2"/>
<wire x1="50.8" y1="2.54" x2="50.8" y2="0" width="0.1524" layer="91"/>
<pinref part="R10" gate="G$1" pin="2"/>
<wire x1="55.88" y1="2.54" x2="55.88" y2="0" width="0.1524" layer="91"/>
<pinref part="R11" gate="G$1" pin="2"/>
<wire x1="25.4" y1="2.54" x2="30.48" y2="2.54" width="0.1524" layer="91"/>
<wire x1="30.48" y1="2.54" x2="35.56" y2="2.54" width="0.1524" layer="91"/>
<wire x1="35.56" y1="2.54" x2="40.64" y2="2.54" width="0.1524" layer="91"/>
<wire x1="40.64" y1="2.54" x2="45.72" y2="2.54" width="0.1524" layer="91"/>
<wire x1="45.72" y1="2.54" x2="50.8" y2="2.54" width="0.1524" layer="91"/>
<wire x1="50.8" y1="2.54" x2="55.88" y2="2.54" width="0.1524" layer="91"/>
<wire x1="55.88" y1="2.54" x2="60.96" y2="2.54" width="0.1524" layer="91"/>
<wire x1="60.96" y1="2.54" x2="60.96" y2="0" width="0.1524" layer="91"/>
<pinref part="R12" gate="G$1" pin="2"/>
<junction x="17.78" y="2.54"/>
<junction x="10.16" y="2.54"/>
<junction x="15.24" y="2.54"/>
<junction x="20.32" y="2.54"/>
<junction x="25.4" y="2.54"/>
<junction x="30.48" y="2.54"/>
<junction x="35.56" y="2.54"/>
<junction x="40.64" y="2.54"/>
<junction x="45.72" y="2.54"/>
<junction x="50.8" y="2.54"/>
<junction x="55.88" y="2.54"/>
</segment>
<segment>
<pinref part="P+5" gate="1" pin="+24V"/>
<pinref part="J3" gate="G$1" pin="9"/>
<wire x1="-38.1" y1="40.64" x2="-38.1" y2="50.8" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="P+6" gate="1" pin="+24V"/>
<wire x1="-182.88" y1="106.68" x2="-182.88" y2="93.98" width="0.1524" layer="91"/>
<wire x1="-182.88" y1="93.98" x2="-167.64" y2="93.98" width="0.1524" layer="91"/>
<wire x1="-182.88" y1="93.98" x2="-182.88" y2="55.88" width="0.1524" layer="91"/>
<wire x1="-182.88" y1="55.88" x2="-167.64" y2="55.88" width="0.1524" layer="91"/>
<junction x="-182.88" y="93.98"/>
<junction x="-182.88" y="55.88"/>
<wire x1="-182.88" y1="55.88" x2="-182.88" y2="38.1" width="0.1524" layer="91"/>
<wire x1="-182.88" y1="38.1" x2="-182.88" y2="0" width="0.1524" layer="91"/>
<wire x1="-182.88" y1="0" x2="-167.64" y2="0" width="0.1524" layer="91"/>
<wire x1="-167.64" y1="38.1" x2="-182.88" y2="38.1" width="0.1524" layer="91"/>
<junction x="-182.88" y="38.1"/>
<pinref part="X-AXIS" gate="A" pin="4"/>
<pinref part="Y-AXIS" gate="A" pin="8"/>
<pinref part="Z-AXIS" gate="A" pin="4"/>
<pinref part="A-AXIS" gate="A" pin="8"/>
</segment>
<segment>
<pinref part="F1" gate="A" pin="2"/>
<wire x1="-116.84" y1="27.94" x2="-116.84" y2="30.48" width="0.1524" layer="91"/>
<pinref part="P+4" gate="1" pin="+24V"/>
</segment>
<segment>
<wire x1="-134.62" y1="-12.7" x2="-134.62" y2="-15.24" width="0.1524" layer="91"/>
<wire x1="-134.62" y1="-15.24" x2="-139.7" y2="-15.24" width="0.1524" layer="91"/>
<wire x1="-139.7" y1="-15.24" x2="-139.7" y2="-17.78" width="0.1524" layer="91"/>
<pinref part="C13" gate="G$1" pin="1"/>
<wire x1="-134.62" y1="-15.24" x2="-129.54" y2="-15.24" width="0.1524" layer="91"/>
<junction x="-134.62" y="-15.24"/>
<wire x1="-129.54" y1="-15.24" x2="-129.54" y2="-17.78" width="0.1524" layer="91"/>
<pinref part="C14" gate="G$1" pin="1"/>
<pinref part="P+3" gate="1" pin="+24V"/>
</segment>
<segment>
<wire x1="-167.64" y1="139.7" x2="-167.64" y2="137.16" width="0.1524" layer="91"/>
<wire x1="-167.64" y1="137.16" x2="-172.72" y2="137.16" width="0.1524" layer="91"/>
<wire x1="-172.72" y1="137.16" x2="-172.72" y2="134.62" width="0.1524" layer="91"/>
<pinref part="C19" gate="G$1" pin="1"/>
<wire x1="-167.64" y1="137.16" x2="-162.56" y2="137.16" width="0.1524" layer="91"/>
<wire x1="-162.56" y1="137.16" x2="-162.56" y2="134.62" width="0.1524" layer="91"/>
<pinref part="C20" gate="G$1" pin="1"/>
<junction x="-167.64" y="137.16"/>
<pinref part="P+8" gate="1" pin="+24V"/>
</segment>
<segment>
<pinref part="P+9" gate="1" pin="+24V"/>
<wire x1="-78.74" y1="109.22" x2="-78.74" y2="104.14" width="0.1524" layer="91"/>
<pinref part="R30" gate="G$1" pin="1"/>
</segment>
<segment>
<pinref part="P+10" gate="1" pin="+24V"/>
<wire x1="-106.68" y1="-10.16" x2="-106.68" y2="-17.78" width="0.1524" layer="91"/>
<pinref part="D1" gate="G$1" pin="2"/>
</segment>
<segment>
<pinref part="P+11" gate="1" pin="+24V"/>
<wire x1="172.72" y1="104.14" x2="172.72" y2="96.52" width="0.1524" layer="91"/>
<wire x1="172.72" y1="96.52" x2="177.8" y2="96.52" width="0.1524" layer="91"/>
<pinref part="J4" gate="A" pin="1"/>
</segment>
<segment>
<pinref part="J3" gate="G$1" pin="25"/>
<wire x1="-20.32" y1="20.32" x2="-20.32" y2="15.24" width="0.1524" layer="91"/>
<wire x1="-20.32" y1="15.24" x2="-12.7" y2="15.24" width="0.1524" layer="91"/>
<wire x1="-12.7" y1="15.24" x2="-12.7" y2="38.1" width="0.1524" layer="91"/>
<pinref part="P+13" gate="1" pin="+24V"/>
</segment>
</net>
<net name="ANIN1" class="0">
<segment>
<pinref part="J2" gate="G$1" pin="3"/>
<wire x1="109.22" y1="43.18" x2="109.22" y2="53.34" width="0.1524" layer="91"/>
<label x="109.22" y="48.26" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<pinref part="C15" gate="G$1" pin="1"/>
<wire x1="114.3" y1="175.26" x2="114.3" y2="177.8" width="0.1524" layer="91"/>
<wire x1="114.3" y1="177.8" x2="119.38" y2="177.8" width="0.1524" layer="91"/>
<wire x1="119.38" y1="177.8" x2="129.54" y2="177.8" width="0.1524" layer="91"/>
<wire x1="129.54" y1="177.8" x2="129.54" y2="172.72" width="0.1524" layer="91"/>
<pinref part="R19" gate="G$1" pin="1"/>
<wire x1="119.38" y1="177.8" x2="119.38" y2="180.34" width="0.1524" layer="91"/>
<label x="119.38" y="180.34" size="1.778" layer="95"/>
<junction x="119.38" y="177.8"/>
</segment>
</net>
<net name="ANOUT0" class="0">
<segment>
<pinref part="J2" gate="G$1" pin="1"/>
<wire x1="99.06" y1="43.18" x2="99.06" y2="53.34" width="0.1524" layer="91"/>
<label x="96.52" y="45.72" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="228.6" y1="142.24" x2="220.98" y2="142.24" width="0.1524" layer="91"/>
<pinref part="R26" gate="G$1" pin="1"/>
<label x="226.06" y="144.78" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="208.28" y1="81.28" x2="215.9" y2="81.28" width="0.1524" layer="91"/>
<pinref part="CONN-MCU" gate="A" pin="6"/>
<label x="198.12" y="81.28" size="1.778" layer="95"/>
</segment>
</net>
<net name="ANOUT1" class="0">
<segment>
<pinref part="J2" gate="G$1" pin="6"/>
<wire x1="101.6" y1="17.78" x2="101.6" y2="5.08" width="0.1524" layer="91"/>
<label x="99.06" y="12.7" size="1.778" layer="95" rot="R270"/>
</segment>
</net>
<net name="ANIN0" class="0">
<segment>
<pinref part="J2" gate="G$1" pin="7"/>
<wire x1="106.68" y1="17.78" x2="106.68" y2="2.54" width="0.1524" layer="91"/>
<label x="104.14" y="10.16" size="1.778" layer="95" rot="R270"/>
</segment>
<segment>
<pinref part="C16" gate="G$1" pin="1"/>
<wire x1="172.72" y1="175.26" x2="172.72" y2="177.8" width="0.1524" layer="91"/>
<wire x1="172.72" y1="177.8" x2="180.34" y2="177.8" width="0.1524" layer="91"/>
<wire x1="180.34" y1="177.8" x2="185.42" y2="177.8" width="0.1524" layer="91"/>
<wire x1="185.42" y1="177.8" x2="185.42" y2="172.72" width="0.1524" layer="91"/>
<pinref part="R24" gate="G$1" pin="1"/>
<wire x1="180.34" y1="177.8" x2="180.34" y2="180.34" width="0.1524" layer="91"/>
<label x="180.34" y="180.34" size="1.778" layer="95"/>
<junction x="180.34" y="177.8"/>
</segment>
</net>
<net name="VSS" class="0">
<segment>
<pinref part="J2" gate="G$1" pin="5"/>
<wire x1="119.38" y1="48.26" x2="119.38" y2="43.18" width="0.1524" layer="91"/>
<pinref part="VSS3" gate="G$1" pin="VSS"/>
</segment>
<segment>
<pinref part="VSS1" gate="G$1" pin="VSS"/>
<wire x1="147.32" y1="210.82" x2="147.32" y2="208.28" width="0.1524" layer="91"/>
<wire x1="147.32" y1="208.28" x2="142.24" y2="208.28" width="0.1524" layer="91"/>
<wire x1="142.24" y1="208.28" x2="142.24" y2="205.74" width="0.1524" layer="91"/>
<pinref part="C1" gate="G$1" pin="1"/>
<wire x1="147.32" y1="208.28" x2="152.4" y2="208.28" width="0.1524" layer="91"/>
<wire x1="152.4" y1="208.28" x2="152.4" y2="205.74" width="0.1524" layer="91"/>
<pinref part="C2" gate="G$1" pin="1"/>
<junction x="147.32" y="208.28"/>
</segment>
<segment>
<pinref part="VSS4" gate="G$1" pin="VSS"/>
<wire x1="167.64" y1="162.56" x2="167.64" y2="160.02" width="0.1524" layer="91"/>
<wire x1="167.64" y1="160.02" x2="165.1" y2="160.02" width="0.1524" layer="91"/>
<pinref part="U2" gate="G$1" pin="V+"/>
</segment>
</net>
<net name="ARCVIN_A" class="0">
<segment>
<pinref part="J4" gate="A" pin="4"/>
<wire x1="177.8" y1="88.9" x2="167.64" y2="88.9" width="0.1524" layer="91"/>
<label x="160.02" y="88.9" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="208.28" y1="93.98" x2="215.9" y2="93.98" width="0.1524" layer="91"/>
<label x="198.12" y="93.98" size="1.778" layer="95"/>
<pinref part="CONN-MCU" gate="A" pin="1"/>
</segment>
</net>
<net name="STEP[1]_N" class="0">
<segment>
<wire x1="-172.72" y1="63.5" x2="-167.64" y2="63.5" width="0.1524" layer="91"/>
<label x="-180.34" y="63.5" size="1.778" layer="95"/>
<pinref part="Y-AXIS" gate="A" pin="5"/>
</segment>
<segment>
<pinref part="J3" gate="G$1" pin="17"/>
<wire x1="-60.96" y1="20.32" x2="-60.96" y2="15.24" width="0.1524" layer="91"/>
<label x="-60.96" y="5.08" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="0V" class="0">
<segment>
<pinref part="GND7" gate="1" pin="0V"/>
<wire x1="-116.84" y1="5.08" x2="-116.84" y2="15.24" width="0.1524" layer="91"/>
<wire x1="-116.84" y1="15.24" x2="-106.68" y2="15.24" width="0.1524" layer="91"/>
<pinref part="CONN_PWR" gate="A" pin="2"/>
</segment>
<segment>
<pinref part="GND12" gate="1" pin="0V"/>
<pinref part="J3" gate="G$1" pin="22"/>
<wire x1="-35.56" y1="7.62" x2="-35.56" y2="20.32" width="0.1524" layer="91"/>
<wire x1="-35.56" y1="7.62" x2="-5.08" y2="7.62" width="0.1524" layer="91"/>
<wire x1="-5.08" y1="7.62" x2="-5.08" y2="2.54" width="0.1524" layer="91"/>
<junction x="-5.08" y="7.62"/>
<pinref part="J3" gate="G$1" pin="GND"/>
<wire x1="-7.62" y1="30.48" x2="-5.08" y2="30.48" width="0.1524" layer="91"/>
<wire x1="-5.08" y1="30.48" x2="-5.08" y2="7.62" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="C1" gate="G$1" pin="2"/>
<wire x1="142.24" y1="198.12" x2="142.24" y2="195.58" width="0.1524" layer="91"/>
<wire x1="142.24" y1="195.58" x2="147.32" y2="195.58" width="0.1524" layer="91"/>
<wire x1="147.32" y1="195.58" x2="147.32" y2="193.04" width="0.1524" layer="91"/>
<pinref part="GND1" gate="1" pin="0V"/>
<wire x1="147.32" y1="195.58" x2="152.4" y2="195.58" width="0.1524" layer="91"/>
<wire x1="152.4" y1="195.58" x2="152.4" y2="198.12" width="0.1524" layer="91"/>
<pinref part="C2" gate="G$1" pin="2"/>
<junction x="147.32" y="195.58"/>
</segment>
<segment>
<pinref part="J2" gate="G$1" pin="GND"/>
<wire x1="134.62" y1="30.48" x2="132.08" y2="30.48" width="0.1524" layer="91"/>
<pinref part="J2" gate="G$1" pin="2"/>
<wire x1="104.14" y1="43.18" x2="104.14" y2="58.42" width="0.1524" layer="91"/>
<wire x1="104.14" y1="58.42" x2="134.62" y2="58.42" width="0.1524" layer="91"/>
<wire x1="134.62" y1="58.42" x2="134.62" y2="30.48" width="0.1524" layer="91"/>
<junction x="134.62" y="30.48"/>
<pinref part="GND8" gate="1" pin="0V"/>
<wire x1="134.62" y1="2.54" x2="134.62" y2="15.24" width="0.1524" layer="91"/>
<wire x1="134.62" y1="15.24" x2="134.62" y2="30.48" width="0.1524" layer="91"/>
<junction x="134.62" y="15.24"/>
<pinref part="J2" gate="G$1" pin="8"/>
<wire x1="111.76" y1="17.78" x2="111.76" y2="15.24" width="0.1524" layer="91"/>
<wire x1="111.76" y1="15.24" x2="134.62" y2="15.24" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="J5" gate="G$1" pin="25"/>
<wire x1="58.42" y1="15.24" x2="58.42" y2="20.32" width="0.1524" layer="91"/>
<wire x1="58.42" y1="15.24" x2="53.34" y2="15.24" width="0.1524" layer="91"/>
<wire x1="53.34" y1="15.24" x2="48.26" y2="15.24" width="0.1524" layer="91"/>
<wire x1="48.26" y1="15.24" x2="43.18" y2="15.24" width="0.1524" layer="91"/>
<wire x1="43.18" y1="15.24" x2="38.1" y2="15.24" width="0.1524" layer="91"/>
<wire x1="38.1" y1="15.24" x2="33.02" y2="15.24" width="0.1524" layer="91"/>
<wire x1="33.02" y1="15.24" x2="27.94" y2="15.24" width="0.1524" layer="91"/>
<wire x1="27.94" y1="15.24" x2="22.86" y2="15.24" width="0.1524" layer="91"/>
<wire x1="22.86" y1="15.24" x2="17.78" y2="15.24" width="0.1524" layer="91"/>
<wire x1="17.78" y1="15.24" x2="12.7" y2="15.24" width="0.1524" layer="91"/>
<wire x1="12.7" y1="15.24" x2="7.62" y2="15.24" width="0.1524" layer="91"/>
<wire x1="7.62" y1="15.24" x2="2.54" y2="15.24" width="0.1524" layer="91"/>
<wire x1="2.54" y1="15.24" x2="2.54" y2="20.32" width="0.1524" layer="91"/>
<pinref part="J5" gate="G$1" pin="14"/>
<pinref part="J5" gate="G$1" pin="15"/>
<wire x1="7.62" y1="20.32" x2="7.62" y2="15.24" width="0.1524" layer="91"/>
<pinref part="J5" gate="G$1" pin="16"/>
<wire x1="12.7" y1="20.32" x2="12.7" y2="15.24" width="0.1524" layer="91"/>
<pinref part="J5" gate="G$1" pin="17"/>
<wire x1="17.78" y1="20.32" x2="17.78" y2="15.24" width="0.1524" layer="91"/>
<pinref part="J5" gate="G$1" pin="18"/>
<wire x1="22.86" y1="20.32" x2="22.86" y2="15.24" width="0.1524" layer="91"/>
<pinref part="J5" gate="G$1" pin="19"/>
<wire x1="27.94" y1="20.32" x2="27.94" y2="15.24" width="0.1524" layer="91"/>
<pinref part="J5" gate="G$1" pin="20"/>
<wire x1="33.02" y1="20.32" x2="33.02" y2="15.24" width="0.1524" layer="91"/>
<pinref part="J5" gate="G$1" pin="21"/>
<wire x1="38.1" y1="20.32" x2="38.1" y2="15.24" width="0.1524" layer="91"/>
<pinref part="J5" gate="G$1" pin="22"/>
<wire x1="43.18" y1="20.32" x2="43.18" y2="15.24" width="0.1524" layer="91"/>
<pinref part="J5" gate="G$1" pin="23"/>
<wire x1="48.26" y1="20.32" x2="48.26" y2="15.24" width="0.1524" layer="91"/>
<pinref part="J5" gate="G$1" pin="24"/>
<wire x1="53.34" y1="20.32" x2="53.34" y2="15.24" width="0.1524" layer="91"/>
<pinref part="J5" gate="G$1" pin="GND"/>
<wire x1="71.12" y1="30.48" x2="71.12" y2="15.24" width="0.1524" layer="91"/>
<wire x1="71.12" y1="15.24" x2="58.42" y2="15.24" width="0.1524" layer="91"/>
<junction x="58.42" y="15.24"/>
<junction x="53.34" y="15.24"/>
<junction x="48.26" y="15.24"/>
<junction x="43.18" y="15.24"/>
<junction x="38.1" y="15.24"/>
<junction x="33.02" y="15.24"/>
<junction x="27.94" y="15.24"/>
<junction x="22.86" y="15.24"/>
<junction x="17.78" y="15.24"/>
<junction x="12.7" y="15.24"/>
<junction x="7.62" y="15.24"/>
<junction x="71.12" y="15.24"/>
<wire x1="71.12" y1="15.24" x2="71.12" y2="2.54" width="0.1524" layer="91"/>
<pinref part="GND4" gate="1" pin="0V"/>
</segment>
<segment>
<pinref part="C13" gate="G$1" pin="2"/>
<wire x1="-139.7" y1="-25.4" x2="-139.7" y2="-27.94" width="0.1524" layer="91"/>
<wire x1="-139.7" y1="-27.94" x2="-134.62" y2="-27.94" width="0.1524" layer="91"/>
<wire x1="-134.62" y1="-27.94" x2="-134.62" y2="-30.48" width="0.1524" layer="91"/>
<pinref part="GND6" gate="1" pin="0V"/>
<wire x1="-134.62" y1="-27.94" x2="-129.54" y2="-27.94" width="0.1524" layer="91"/>
<junction x="-134.62" y="-27.94"/>
<wire x1="-129.54" y1="-27.94" x2="-129.54" y2="-25.4" width="0.1524" layer="91"/>
<pinref part="C14" gate="G$1" pin="2"/>
</segment>
<segment>
<pinref part="U2" gate="G$1" pin="V-"/>
<wire x1="129.54" y1="142.24" x2="127" y2="142.24" width="0.1524" layer="91"/>
<wire x1="127" y1="142.24" x2="127" y2="139.7" width="0.1524" layer="91"/>
<pinref part="GND9" gate="1" pin="0V"/>
</segment>
<segment>
<pinref part="C15" gate="G$1" pin="2"/>
<wire x1="114.3" y1="167.64" x2="114.3" y2="165.1" width="0.1524" layer="91"/>
<pinref part="GND18" gate="1" pin="0V"/>
</segment>
<segment>
<pinref part="C16" gate="G$1" pin="2"/>
<wire x1="172.72" y1="167.64" x2="172.72" y2="165.1" width="0.1524" layer="91"/>
<pinref part="GND16" gate="1" pin="0V"/>
</segment>
<segment>
<pinref part="C17" gate="G$1" pin="2"/>
<wire x1="93.98" y1="129.54" x2="93.98" y2="127" width="0.1524" layer="91"/>
<pinref part="GND17" gate="1" pin="0V"/>
<wire x1="93.98" y1="127" x2="93.98" y2="124.46" width="0.1524" layer="91"/>
<junction x="93.98" y="127"/>
<wire x1="93.98" y1="127" x2="121.92" y2="127" width="0.1524" layer="91"/>
<pinref part="C5" gate="G$1" pin="2"/>
<wire x1="170.18" y1="129.54" x2="170.18" y2="127" width="0.1524" layer="91"/>
<pinref part="GND11" gate="1" pin="0V"/>
<wire x1="170.18" y1="127" x2="170.18" y2="124.46" width="0.1524" layer="91"/>
<wire x1="170.18" y1="127" x2="121.92" y2="127" width="0.1524" layer="91"/>
<pinref part="C7" gate="G$1" pin="2"/>
<wire x1="121.92" y1="129.54" x2="121.92" y2="127" width="0.1524" layer="91"/>
<pinref part="GND13" gate="1" pin="0V"/>
<wire x1="121.92" y1="127" x2="121.92" y2="124.46" width="0.1524" layer="91"/>
<junction x="170.18" y="127"/>
<junction x="121.92" y="127"/>
<pinref part="C18" gate="G$1" pin="2"/>
<wire x1="203.2" y1="129.54" x2="203.2" y2="127" width="0.1524" layer="91"/>
<wire x1="203.2" y1="127" x2="170.18" y2="127" width="0.1524" layer="91"/>
<wire x1="203.2" y1="127" x2="203.2" y2="124.46" width="0.1524" layer="91"/>
<junction x="203.2" y="127"/>
<pinref part="GND20" gate="1" pin="0V"/>
</segment>
<segment>
<pinref part="C19" gate="G$1" pin="2"/>
<wire x1="-172.72" y1="127" x2="-172.72" y2="124.46" width="0.1524" layer="91"/>
<wire x1="-172.72" y1="124.46" x2="-167.64" y2="124.46" width="0.1524" layer="91"/>
<wire x1="-167.64" y1="124.46" x2="-167.64" y2="121.92" width="0.1524" layer="91"/>
<pinref part="GND19" gate="1" pin="0V"/>
<wire x1="-167.64" y1="124.46" x2="-162.56" y2="124.46" width="0.1524" layer="91"/>
<wire x1="-162.56" y1="124.46" x2="-162.56" y2="127" width="0.1524" layer="91"/>
<pinref part="C20" gate="G$1" pin="2"/>
<junction x="-167.64" y="124.46"/>
</segment>
<segment>
<pinref part="U$1" gate="G$1" pin="C"/>
<wire x1="-78.74" y1="78.74" x2="-78.74" y2="73.66" width="0.1524" layer="91"/>
<pinref part="GND21" gate="1" pin="0V"/>
</segment>
<segment>
<pinref part="D1" gate="G$1" pin="1"/>
<wire x1="-106.68" y1="-27.94" x2="-106.68" y2="-35.56" width="0.1524" layer="91"/>
<pinref part="GND22" gate="1" pin="0V"/>
</segment>
<segment>
<pinref part="GND10" gate="1" pin="0V"/>
<wire x1="175.26" y1="63.5" x2="175.26" y2="73.66" width="0.1524" layer="91"/>
<wire x1="175.26" y1="73.66" x2="175.26" y2="83.82" width="0.1524" layer="91"/>
<wire x1="175.26" y1="83.82" x2="177.8" y2="83.82" width="0.1524" layer="91"/>
<pinref part="J4" gate="A" pin="6"/>
<pinref part="J4" gate="A" pin="10"/>
<wire x1="177.8" y1="73.66" x2="175.26" y2="73.66" width="0.1524" layer="91"/>
<junction x="175.26" y="73.66"/>
</segment>
<segment>
<wire x1="-38.1" y1="170.18" x2="-63.5" y2="170.18" width="0.1524" layer="91"/>
<pinref part="CONTACTORS" gate="A" pin="8"/>
<wire x1="-63.5" y1="170.18" x2="-63.5" y2="167.64" width="0.1524" layer="91"/>
<pinref part="GND5" gate="1" pin="0V"/>
<wire x1="-63.5" y1="167.64" x2="-63.5" y2="160.02" width="0.1524" layer="91"/>
<wire x1="-63.5" y1="170.18" x2="-63.5" y2="172.72" width="0.1524" layer="91"/>
<pinref part="CONTACTORS" gate="A" pin="7"/>
<wire x1="-63.5" y1="172.72" x2="-38.1" y2="172.72" width="0.1524" layer="91"/>
<wire x1="-63.5" y1="172.72" x2="-63.5" y2="175.26" width="0.1524" layer="91"/>
<pinref part="CONTACTORS" gate="A" pin="6"/>
<wire x1="-63.5" y1="175.26" x2="-38.1" y2="175.26" width="0.1524" layer="91"/>
<wire x1="-63.5" y1="175.26" x2="-63.5" y2="177.8" width="0.1524" layer="91"/>
<pinref part="CONTACTORS" gate="A" pin="5"/>
<wire x1="-63.5" y1="177.8" x2="-38.1" y2="177.8" width="0.1524" layer="91"/>
<wire x1="-86.36" y1="170.18" x2="-86.36" y2="167.64" width="0.1524" layer="91"/>
<wire x1="-86.36" y1="167.64" x2="-81.28" y2="167.64" width="0.1524" layer="91"/>
<wire x1="-81.28" y1="167.64" x2="-76.2" y2="167.64" width="0.1524" layer="91"/>
<wire x1="-76.2" y1="167.64" x2="-71.12" y2="167.64" width="0.1524" layer="91"/>
<wire x1="-71.12" y1="167.64" x2="-63.5" y2="167.64" width="0.1524" layer="91"/>
<wire x1="-71.12" y1="170.18" x2="-71.12" y2="167.64" width="0.1524" layer="91"/>
<wire x1="-76.2" y1="170.18" x2="-76.2" y2="167.64" width="0.1524" layer="91"/>
<wire x1="-81.28" y1="170.18" x2="-81.28" y2="167.64" width="0.1524" layer="91"/>
<junction x="-63.5" y="170.18"/>
<junction x="-63.5" y="167.64"/>
<junction x="-63.5" y="172.72"/>
<junction x="-63.5" y="175.26"/>
<junction x="-81.28" y="167.64"/>
<junction x="-76.2" y="167.64"/>
<junction x="-71.12" y="167.64"/>
<pinref part="D3" gate="G$1" pin="A"/>
<pinref part="D2" gate="G$1" pin="A"/>
<pinref part="D4" gate="G$1" pin="A"/>
<pinref part="D5" gate="G$1" pin="A"/>
</segment>
<segment>
<pinref part="GND14" gate="1" pin="0V"/>
<wire x1="-218.44" y1="93.98" x2="-218.44" y2="96.52" width="0.1524" layer="91"/>
<wire x1="-218.44" y1="96.52" x2="-213.36" y2="96.52" width="0.1524" layer="91"/>
<pinref part="R16" gate="G$1" pin="1"/>
</segment>
<segment>
<wire x1="210.82" y1="73.66" x2="210.82" y2="83.82" width="0.1524" layer="91"/>
<pinref part="GND3" gate="1" pin="0V"/>
<wire x1="210.82" y1="83.82" x2="215.9" y2="83.82" width="0.1524" layer="91"/>
<pinref part="CONN-MCU" gate="A" pin="5"/>
</segment>
</net>
<net name="N$1" class="0">
<segment>
<pinref part="R14" gate="G$1" pin="1"/>
<wire x1="185.42" y1="142.24" x2="182.88" y2="142.24" width="0.1524" layer="91"/>
<wire x1="185.42" y1="142.24" x2="185.42" y2="147.32" width="0.1524" layer="91"/>
<pinref part="C6" gate="G$1" pin="2"/>
<junction x="185.42" y="142.24"/>
<pinref part="R23" gate="G$1" pin="2"/>
<wire x1="190.5" y1="142.24" x2="185.42" y2="142.24" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$3" class="0">
<segment>
<pinref part="R14" gate="G$1" pin="2"/>
<wire x1="172.72" y1="142.24" x2="170.18" y2="142.24" width="0.1524" layer="91"/>
<pinref part="U2" gate="G$1" pin="+INB"/>
<wire x1="170.18" y1="142.24" x2="165.1" y2="142.24" width="0.1524" layer="91"/>
<junction x="170.18" y="142.24"/>
<wire x1="170.18" y1="142.24" x2="170.18" y2="137.16" width="0.1524" layer="91"/>
<pinref part="C5" gate="G$1" pin="1"/>
</segment>
</net>
<net name="N$7" class="0">
<segment>
<pinref part="U2" gate="G$1" pin="+INA"/>
<wire x1="129.54" y1="147.32" x2="121.92" y2="147.32" width="0.1524" layer="91"/>
<pinref part="R17" gate="G$1" pin="1"/>
<pinref part="C7" gate="G$1" pin="1"/>
<wire x1="121.92" y1="147.32" x2="119.38" y2="147.32" width="0.1524" layer="91"/>
<wire x1="121.92" y1="137.16" x2="121.92" y2="147.32" width="0.1524" layer="91"/>
<junction x="121.92" y="147.32"/>
</segment>
</net>
<net name="N$19" class="0">
<segment>
<pinref part="R18" gate="G$1" pin="1"/>
<wire x1="106.68" y1="147.32" x2="109.22" y2="147.32" width="0.1524" layer="91"/>
<pinref part="R17" gate="G$1" pin="2"/>
<pinref part="C8" gate="G$1" pin="2"/>
<wire x1="106.68" y1="149.86" x2="106.68" y2="147.32" width="0.1524" layer="91"/>
<junction x="106.68" y="147.32"/>
</segment>
</net>
<net name="N$9" class="0">
<segment>
<pinref part="U2" gate="G$1" pin="OUTA"/>
<wire x1="129.54" y1="160.02" x2="129.54" y2="149.86" width="0.1524" layer="91"/>
<pinref part="U2" gate="G$1" pin="-INA"/>
<wire x1="129.54" y1="160.02" x2="106.68" y2="160.02" width="0.1524" layer="91"/>
<wire x1="106.68" y1="160.02" x2="106.68" y2="157.48" width="0.1524" layer="91"/>
<pinref part="C8" gate="G$1" pin="1"/>
<wire x1="129.54" y1="160.02" x2="129.54" y2="162.56" width="0.1524" layer="91"/>
<pinref part="R19" gate="G$1" pin="2"/>
<junction x="129.54" y="160.02"/>
</segment>
</net>
<net name="STAGE1" class="0">
<segment>
<pinref part="U2" gate="G$1" pin="OUTB"/>
<wire x1="165.1" y1="154.94" x2="165.1" y2="144.78" width="0.1524" layer="91"/>
<pinref part="U2" gate="G$1" pin="-INB"/>
<wire x1="165.1" y1="154.94" x2="185.42" y2="154.94" width="0.1524" layer="91"/>
<pinref part="C6" gate="G$1" pin="1"/>
<wire x1="185.42" y1="154.94" x2="185.42" y2="162.56" width="0.1524" layer="91"/>
<pinref part="R24" gate="G$1" pin="2"/>
<junction x="165.1" y="154.94"/>
<junction x="185.42" y="154.94"/>
<label x="175.26" y="154.94" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$10" class="0">
<segment>
<pinref part="R18" gate="G$1" pin="2"/>
<wire x1="96.52" y1="147.32" x2="93.98" y2="147.32" width="0.1524" layer="91"/>
<pinref part="R25" gate="G$1" pin="1"/>
<wire x1="93.98" y1="147.32" x2="91.44" y2="147.32" width="0.1524" layer="91"/>
<junction x="93.98" y="147.32"/>
<wire x1="93.98" y1="147.32" x2="93.98" y2="137.16" width="0.1524" layer="91"/>
<pinref part="C17" gate="G$1" pin="1"/>
</segment>
</net>
<net name="N$21" class="0">
<segment>
<pinref part="R26" gate="G$1" pin="2"/>
<wire x1="210.82" y1="142.24" x2="203.2" y2="142.24" width="0.1524" layer="91"/>
<pinref part="R23" gate="G$1" pin="1"/>
<wire x1="203.2" y1="142.24" x2="200.66" y2="142.24" width="0.1524" layer="91"/>
<junction x="203.2" y="142.24"/>
<wire x1="203.2" y1="142.24" x2="203.2" y2="137.16" width="0.1524" layer="91"/>
<pinref part="C18" gate="G$1" pin="1"/>
</segment>
</net>
<net name="N$15" class="0">
<segment>
<pinref part="R30" gate="G$1" pin="2"/>
<wire x1="-78.74" y1="93.98" x2="-78.74" y2="86.36" width="0.1524" layer="91"/>
<pinref part="U$1" gate="G$1" pin="A"/>
</segment>
</net>
<net name="N$14" class="0">
<segment>
<pinref part="F1" gate="A" pin="1"/>
<wire x1="-116.84" y1="17.78" x2="-106.68" y2="17.78" width="0.1524" layer="91"/>
<pinref part="CONN_PWR" gate="A" pin="1"/>
</segment>
</net>
<net name="ARKOK" class="0">
<segment>
<pinref part="J4" gate="A" pin="2"/>
<wire x1="177.8" y1="93.98" x2="167.64" y2="93.98" width="0.1524" layer="91"/>
<label x="162.56" y="93.98" size="1.778" layer="95"/>
</segment>
<segment>
<label x="35.56" y="43.18" size="1.778" layer="95" rot="R90"/>
<pinref part="J5" gate="G$1" pin="8"/>
<wire x1="35.56" y1="40.64" x2="35.56" y2="45.72" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="R7" gate="G$1" pin="1"/>
<wire x1="35.56" y1="-10.16" x2="35.56" y2="-15.24" width="0.1524" layer="91"/>
<label x="35.56" y="-22.86" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<wire x1="208.28" y1="88.9" x2="215.9" y2="88.9" width="0.1524" layer="91"/>
<label x="200.66" y="88.9" size="1.778" layer="95"/>
<pinref part="CONN-MCU" gate="A" pin="3"/>
</segment>
</net>
<net name="ARC_START" class="0">
<segment>
<pinref part="J4" gate="A" pin="9"/>
<wire x1="177.8" y1="76.2" x2="167.64" y2="76.2" width="0.1524" layer="91"/>
<label x="157.48" y="76.2" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="J3" gate="G$1" pin="10"/>
<wire x1="-33.02" y1="40.64" x2="-33.02" y2="48.26" width="0.1524" layer="91"/>
<label x="-33.02" y="45.72" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="ENA+" class="0">
<segment>
<wire x1="-172.72" y1="86.36" x2="-167.64" y2="86.36" width="0.1524" layer="91"/>
<label x="-180.34" y="86.36" size="1.778" layer="95"/>
<pinref part="X-AXIS" gate="A" pin="7"/>
</segment>
<segment>
<wire x1="-172.72" y1="68.58" x2="-167.64" y2="68.58" width="0.1524" layer="91"/>
<label x="-180.34" y="68.58" size="1.778" layer="95"/>
<pinref part="Y-AXIS" gate="A" pin="3"/>
</segment>
<segment>
<wire x1="-172.72" y1="27.94" x2="-167.64" y2="27.94" width="0.1524" layer="91"/>
<label x="-180.34" y="27.94" size="1.778" layer="95"/>
<pinref part="Z-AXIS" gate="A" pin="8"/>
</segment>
<segment>
<wire x1="-172.72" y1="12.7" x2="-167.64" y2="12.7" width="0.1524" layer="91"/>
<label x="-180.34" y="12.7" size="1.778" layer="95"/>
<pinref part="A-AXIS" gate="A" pin="3"/>
</segment>
<segment>
<pinref part="R20" gate="G$1" pin="2"/>
<wire x1="-203.2" y1="83.82" x2="-198.12" y2="83.82" width="0.1524" layer="91"/>
<label x="-200.66" y="83.82" size="1.778" layer="95"/>
</segment>
</net>
<net name="ENA-" class="0">
<segment>
<pinref part="R16" gate="G$1" pin="2"/>
<label x="-195.58" y="96.52" size="1.778" layer="95"/>
<wire x1="-203.2" y1="96.52" x2="-193.04" y2="96.52" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="-170.18" y1="96.52" x2="-167.64" y2="96.52" width="0.1524" layer="91"/>
<pinref part="X-AXIS" gate="A" pin="3"/>
<label x="-180.34" y="96.52" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="-170.18" y1="2.54" x2="-167.64" y2="2.54" width="0.1524" layer="91"/>
<label x="-180.34" y="2.54" size="1.778" layer="95"/>
<pinref part="A-AXIS" gate="A" pin="7"/>
</segment>
<segment>
<wire x1="-170.18" y1="35.56" x2="-167.64" y2="35.56" width="0.1524" layer="91"/>
<pinref part="Z-AXIS" gate="A" pin="5"/>
<label x="-180.34" y="35.56" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="-170.18" y1="58.42" x2="-167.64" y2="58.42" width="0.1524" layer="91"/>
<pinref part="Y-AXIS" gate="A" pin="7"/>
<label x="-180.34" y="58.42" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$2" class="0">
<segment>
<pinref part="CONTACTORS" gate="A" pin="1"/>
<wire x1="-38.1" y1="187.96" x2="-43.18" y2="187.96" width="0.1524" layer="91"/>
<pinref part="R13" gate="G$1" pin="2"/>
</segment>
</net>
<net name="N$5" class="0">
<segment>
<pinref part="CONTACTORS" gate="A" pin="3"/>
<wire x1="-38.1" y1="182.88" x2="-43.18" y2="182.88" width="0.1524" layer="91"/>
<pinref part="R15" gate="G$1" pin="2"/>
</segment>
</net>
<net name="N$6" class="0">
<segment>
<pinref part="CONTACTORS" gate="A" pin="4"/>
<wire x1="-38.1" y1="180.34" x2="-43.18" y2="180.34" width="0.1524" layer="91"/>
<pinref part="R22" gate="G$1" pin="2"/>
</segment>
</net>
<net name="N$8" class="0">
<segment>
<pinref part="R22" gate="G$1" pin="1"/>
<wire x1="-53.34" y1="180.34" x2="-55.88" y2="180.34" width="0.1524" layer="91"/>
<pinref part="F2" gate="A" pin="2"/>
</segment>
</net>
<net name="N$11" class="0">
<segment>
<pinref part="R15" gate="G$1" pin="1"/>
<wire x1="-53.34" y1="182.88" x2="-55.88" y2="182.88" width="0.1524" layer="91"/>
<pinref part="F4" gate="A" pin="2"/>
</segment>
</net>
<net name="N$12" class="0">
<segment>
<pinref part="R21" gate="G$1" pin="1"/>
<wire x1="-53.34" y1="185.42" x2="-55.88" y2="185.42" width="0.1524" layer="91"/>
<pinref part="F5" gate="A" pin="2"/>
</segment>
</net>
<net name="N$13" class="0">
<segment>
<pinref part="R13" gate="G$1" pin="1"/>
<wire x1="-53.34" y1="187.96" x2="-55.88" y2="187.96" width="0.1524" layer="91"/>
<pinref part="F9" gate="A" pin="2"/>
</segment>
</net>
<net name="GND" class="0">
<segment>
<wire x1="-106.68" y1="12.7" x2="-109.22" y2="12.7" width="0.1524" layer="91"/>
<wire x1="-109.22" y1="12.7" x2="-109.22" y2="2.54" width="0.1524" layer="91"/>
<pinref part="GND2" gate="1" pin="GND"/>
<pinref part="CONN_PWR" gate="A" pin="3"/>
</segment>
</net>
<net name="ARCVIN_A2" class="0">
<segment>
<wire x1="208.28" y1="91.44" x2="215.9" y2="91.44" width="0.1524" layer="91"/>
<label x="198.12" y="91.44" size="1.778" layer="95"/>
<pinref part="CONN-MCU" gate="A" pin="2"/>
</segment>
<segment>
<wire x1="76.2" y1="147.32" x2="81.28" y2="147.32" width="0.1524" layer="91"/>
<pinref part="R25" gate="G$1" pin="2"/>
<label x="68.58" y="144.78" size="1.778" layer="95"/>
</segment>
</net>
<net name="THC_ENA" class="0">
<segment>
<wire x1="208.28" y1="86.36" x2="215.9" y2="86.36" width="0.1524" layer="91"/>
<label x="198.12" y="86.36" size="1.778" layer="95"/>
<pinref part="CONN-MCU" gate="A" pin="4"/>
</segment>
<segment>
<pinref part="CONTACTORS" gate="A" pin="2"/>
<wire x1="-38.1" y1="185.42" x2="-43.18" y2="185.42" width="0.1524" layer="91"/>
<pinref part="R21" gate="G$1" pin="2"/>
<label x="-27.94" y="185.42" size="1.778" layer="95"/>
</segment>
</net>
<net name="THC_TOUCHOFF" class="0">
<segment>
<wire x1="-139.7" y1="177.8" x2="-129.54" y2="177.8" width="0.1524" layer="91"/>
<wire x1="-129.54" y1="177.8" x2="-121.92" y2="177.8" width="0.1524" layer="91"/>
<wire x1="-129.54" y1="167.64" x2="-129.54" y2="177.8" width="0.1524" layer="91"/>
<label x="-139.7" y="165.1" size="1.778" layer="95"/>
<pinref part="D8" gate="G$1" pin="C"/>
<pinref part="D9" gate="G$1" pin="C"/>
<junction x="-129.54" y="177.8"/>
</segment>
<segment>
<label x="30.48" y="43.18" size="1.778" layer="95" rot="R90"/>
<pinref part="J5" gate="G$1" pin="7"/>
<wire x1="30.48" y1="40.64" x2="30.48" y2="45.72" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="R6" gate="G$1" pin="1"/>
<wire x1="30.48" y1="-10.16" x2="30.48" y2="-15.24" width="0.1524" layer="91"/>
<label x="30.48" y="-33.02" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="THC_FLOAT" class="0">
<segment>
<wire x1="-116.84" y1="177.8" x2="-109.22" y2="177.8" width="0.1524" layer="91"/>
<wire x1="-109.22" y1="177.8" x2="-109.22" y2="182.88" width="0.1524" layer="91"/>
<label x="-114.3" y="182.88" size="1.778" layer="95"/>
<pinref part="D9" gate="G$1" pin="A"/>
</segment>
<segment>
<wire x1="-147.32" y1="195.58" x2="-132.08" y2="195.58" width="0.1524" layer="91"/>
<label x="-160.02" y="195.58" size="1.778" layer="95"/>
<pinref part="CONN_THC" gate="A" pin="2"/>
</segment>
</net>
<net name="THC_OHMIC" class="0">
<segment>
<wire x1="-144.78" y1="177.8" x2="-149.86" y2="177.8" width="0.1524" layer="91"/>
<wire x1="-149.86" y1="182.88" x2="-149.86" y2="177.8" width="0.1524" layer="91"/>
<label x="-157.48" y="182.88" size="1.778" layer="95"/>
<pinref part="D8" gate="G$1" pin="A"/>
</segment>
<segment>
<wire x1="-147.32" y1="198.12" x2="-132.08" y2="198.12" width="0.1524" layer="91"/>
<label x="-160.02" y="198.12" size="1.778" layer="95"/>
<pinref part="CONN_THC" gate="A" pin="1"/>
</segment>
<segment>
<label x="25.4" y="43.18" size="1.778" layer="95" rot="R90"/>
<pinref part="J5" gate="G$1" pin="6"/>
<wire x1="25.4" y1="40.64" x2="25.4" y2="45.72" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="R5" gate="G$1" pin="1"/>
<wire x1="25.4" y1="-10.16" x2="25.4" y2="-15.24" width="0.1524" layer="91"/>
<label x="25.4" y="-22.86" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
</nets>
</sheet>
</sheets>
</schematic>
</drawing>
<compatibility>
<note version="6.3" minversion="6.2.2" severity="warning">
Since Version 6.2.2 text objects can contain more than one line,
which will not be processed correctly with this version.
</note>
<note version="8.2" severity="warning">
Since Version 8.2, EAGLE supports online libraries. The ids
of those online libraries will not be understood (or retained)
with this version.
</note>
<note version="8.3" severity="warning">
Since Version 8.3, EAGLE supports URNs for individual library
assets (packages, symbols, and devices). The URNs of those assets
will not be understood (or retained) with this version.
</note>
<note version="8.3" severity="warning">
Since Version 8.3, EAGLE supports the association of 3D packages
with devices in libraries, schematics, and board files. Those 3D
packages will not be understood (or retained) with this version.
</note>
<note version="8.4" severity="warning">
Since Version 8.4, EAGLE supports properties for SPICE simulation. 
Probes in schematics and SPICE mapping objects found in parts and library devices
will not be understood with this version. Update EAGLE to the latest version
for full support of SPICE simulation. 
</note>
</compatibility>
</eagle>
